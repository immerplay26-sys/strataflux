import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { NewProjectModal } from './components/NewProjectModal';

// Public pages
import { Home } from './pages/Home';
import { Features } from './pages/Features';
import { Pricing } from './pages/Pricing';
import { HowItWorks } from './pages/HowItWorks';
import { Documentation } from './pages/Documentation';
import { AboutUs } from './pages/AboutUs';
import { ContactUs } from './pages/ContactUs';
import { Security } from './pages/Security';
import { Status } from './pages/Status';
import { FAQ } from './pages/FAQ';
import { PrivacyPolicy } from './pages/PrivacyPolicy';
import { TermsOfService } from './pages/TermsOfService';
import { CookiePolicy } from './pages/CookiePolicy';
import { AcceptableUse } from './pages/AcceptableUse';
import { Login } from './pages/Login';
import { Register } from './pages/Register';
import { ForgotPassword } from './pages/ForgotPassword';
import { ResetPassword } from './pages/ResetPassword';
import { AdminLogin } from './pages/AdminLogin';
import { NotFound } from './pages/NotFound';

// Dashboard layout and pages
import { DashboardLayout } from './pages/dashboard/DashboardLayout';
import { DashboardOverview } from './pages/dashboard/DashboardOverview';
import { ProjectsList } from './pages/dashboard/ProjectsList';
import { ProjectDetail } from './pages/dashboard/ProjectDetail';
import { DeploymentsList } from './pages/dashboard/DeploymentsList';
import { DomainsManager } from './pages/dashboard/DomainsManager';
import { AnalyticsView } from './pages/dashboard/AnalyticsView';
import { BillingView } from './pages/dashboard/BillingView';
import { SupportTickets } from './pages/dashboard/SupportTickets';
import { UserSettings } from './pages/dashboard/UserSettings';

// Admin dashboard
import { AdminDashboard } from './pages/admin/AdminDashboard';
import { Megaphone } from 'lucide-react';

function AppContent() {
  const { user, loading, config } = useAuth();
  const [currentPath, setCurrentPath] = useState(window.location.pathname || '/');
  const [newProjectModalOpen, setNewProjectModalOpen] = useState(false);

  // Sync with browser navigation
  useEffect(() => {
    const handlePopState = () => {
      setCurrentPath(window.location.pathname || '/');
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const navigate = (path: string) => {
    window.history.pushState({}, '', path);
    setCurrentPath(path);
    window.scrollTo(0, 0);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center text-cyan-400 font-mono text-sm">
        Initializing StrataFlux Cloud...
      </div>
    );
  }

  // Admin Portal Route: /admin
  if (currentPath === '/admin' || currentPath.startsWith('/admin/')) {
    if (!user || user.role !== 'admin') {
      return <AdminLogin onNavigate={navigate} />;
    }
    return <AdminDashboard onNavigate={navigate} />;
  }

  // Admin Dedicated Login URL
  if (currentPath === '/admin-login' || currentPath === '/admin-login.html') {
    return <AdminLogin onNavigate={navigate} />;
  }

  // User Dashboard Routes
  if (currentPath.startsWith('/dashboard')) {
    if (!user) {
      return (
        <div className="min-h-screen flex flex-col bg-slate-950">
          <Navbar currentPath={currentPath} onNavigate={navigate} />
          <Login onNavigate={navigate} />
          <Footer onNavigate={navigate} />
        </div>
      );
    }

    const renderDashboardPage = () => {
      if (currentPath === '/dashboard') {
        return (
          <DashboardOverview
            onNavigate={navigate}
            onOpenNewProject={() => setNewProjectModalOpen(true)}
          />
        );
      }
      if (currentPath === '/dashboard/projects') {
        return (
          <ProjectsList
            onNavigate={navigate}
            onOpenNewProject={() => setNewProjectModalOpen(true)}
          />
        );
      }
      if (currentPath.startsWith('/dashboard/projects/')) {
        const projectId = currentPath.replace('/dashboard/projects/', '').split('/')[0];
        return <ProjectDetail projectId={projectId} onNavigate={navigate} />;
      }
      if (currentPath === '/dashboard/deployments') {
        return <DeploymentsList onNavigate={navigate} />;
      }
      if (currentPath === '/dashboard/domains') {
        return <DomainsManager onNavigate={navigate} />;
      }
      if (currentPath === '/dashboard/analytics') {
        return <AnalyticsView onNavigate={navigate} />;
      }
      if (currentPath === '/dashboard/billing') {
        return <BillingView onNavigate={navigate} />;
      }
      if (currentPath === '/dashboard/support') {
        return <SupportTickets onNavigate={navigate} />;
      }
      if (currentPath === '/dashboard/settings') {
        return <UserSettings onNavigate={navigate} />;
      }
      return (
        <DashboardOverview
          onNavigate={navigate}
          onOpenNewProject={() => setNewProjectModalOpen(true)}
        />
      );
    };

    return (
      <>
        <DashboardLayout currentPath={currentPath} onNavigate={navigate}>
          {renderDashboardPage()}
        </DashboardLayout>

        <NewProjectModal
          isOpen={newProjectModalOpen}
          onClose={() => setNewProjectModalOpen(false)}
          onProjectCreated={(p) => {
            navigate(`/dashboard/projects/${p.id}`);
          }}
        />
      </>
    );
  }

  // Public Pages
  const renderPublicPage = () => {
    switch (currentPath) {
      case '/':
        return <Home onNavigate={navigate} />;
      case '/features':
        return <Features onNavigate={navigate} />;
      case '/pricing':
        return <Pricing onNavigate={navigate} />;
      case '/how-it-works':
        return <HowItWorks onNavigate={navigate} />;
      case '/documentation':
        return <Documentation onNavigate={navigate} />;
      case '/about-us':
        return <AboutUs onNavigate={navigate} />;
      case '/contact-us':
        return <ContactUs onNavigate={navigate} />;
      case '/security':
        return <Security onNavigate={navigate} />;
      case '/status':
        return <Status onNavigate={navigate} />;
      case '/faq':
        return <FAQ onNavigate={navigate} />;
      case '/privacy-policy':
        return <PrivacyPolicy onNavigate={navigate} />;
      case '/terms-of-service':
        return <TermsOfService onNavigate={navigate} />;
      case '/cookie-policy':
        return <CookiePolicy onNavigate={navigate} />;
      case '/acceptable-use':
        return <AcceptableUse onNavigate={navigate} />;
      case '/login':
        return <Login onNavigate={navigate} />;
      case '/register':
        return <Register onNavigate={navigate} />;
      case '/forgot-password':
        return <ForgotPassword onNavigate={navigate} />;
      case '/reset-password':
        return <ResetPassword onNavigate={navigate} />;
      default:
        return <NotFound onNavigate={navigate} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-950 text-slate-100">
      {/* Announcement banner if active */}
      {config?.announcement && (
        <div className="bg-gradient-to-r from-amber-600 via-orange-500 to-amber-700 text-slate-950 text-xs font-semibold py-2 px-4 text-center flex items-center justify-center gap-2">
          <Megaphone className="w-4 h-4 flex-shrink-0" />
          <span>{config.announcement}</span>
        </div>
      )}

      <Navbar currentPath={currentPath} onNavigate={navigate} />
      <main className="flex-1">{renderPublicPage()}</main>
      <Footer onNavigate={navigate} />

      <NewProjectModal
        isOpen={newProjectModalOpen}
        onClose={() => setNewProjectModalOpen(false)}
        onProjectCreated={(p) => {
          navigate(`/dashboard/projects/${p.id}`);
        }}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
