import React, { useState } from 'react';
import { Logo } from './Logo';
import { useAuth } from '../context/AuthContext';
import { Menu, X, Terminal, Shield, User as UserIcon, LogOut, LayoutDashboard } from 'lucide-react';

interface NavbarProps {
  currentPath: string;
  onNavigate: (path: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentPath, onNavigate }) => {
  const { user, logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { label: 'Features', path: '/features' },
    { label: 'How It Works', path: '/how-it-works' },
    { label: 'Pricing', path: '/pricing' },
    { label: 'Docs', path: '/documentation' },
    { label: 'Status', path: '/status' },
    { label: 'About', path: '/about-us' },
    { label: 'Contact', path: '/contact-us' },
  ];

  const handleLinkClick = (path: string) => {
    onNavigate(path);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b border-slate-800/80 bg-slate-950/85 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand */}
        <button
          onClick={() => handleLinkClick('/')}
          className="flex items-center text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-500 rounded"
        >
          <Logo size="md" />
        </button>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-6">
          {navLinks.map((item) => {
            const isActive = currentPath === item.path;
            return (
              <button
                key={item.path}
                onClick={() => handleLinkClick(item.path)}
                className={`text-sm font-medium transition-colors hover:text-cyan-400 ${
                  isActive ? 'text-cyan-400 font-semibold' : 'text-slate-300'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Desktop CTA / Auth buttons */}
        <div className="hidden md:flex items-center gap-3">
          {user ? (
            <div className="flex items-center gap-3">
              {user.role === 'admin' && (
                <button
                  onClick={() => handleLinkClick('/admin')}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-amber-300 bg-amber-950/40 border border-amber-800/60 rounded-md hover:bg-amber-900/50 transition-colors"
                >
                  <Shield className="w-3.5 h-3.5" />
                  Admin Console
                </button>
              )}
              <button
                onClick={() => handleLinkClick('/dashboard')}
                className="flex items-center gap-2 px-4 py-2 text-sm font-semibold text-white bg-cyan-600 hover:bg-cyan-500 rounded-lg shadow-sm shadow-cyan-950 transition-colors"
              >
                <LayoutDashboard className="w-4 h-4" />
                Dashboard
              </button>
              <button
                onClick={() => {
                  logout();
                  handleLinkClick('/');
                }}
                title="Sign out"
                className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800/60 transition-colors"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-3">
              <button
                onClick={() => handleLinkClick('/login')}
                className="px-3.5 py-1.5 text-sm font-medium text-slate-300 hover:text-white transition-colors"
              >
                Sign In
              </button>
              <button
                onClick={() => handleLinkClick('/register')}
                className="px-4 py-2 text-sm font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg shadow-sm transition-colors"
              >
                Deploy Now
              </button>
            </div>
          )}
        </div>

        {/* Mobile menu hamburger */}
        <div className="md:hidden flex items-center gap-2">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-md text-slate-400 hover:text-white hover:bg-slate-800 focus:outline-none"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-b border-slate-800 bg-slate-950 px-4 pt-2 pb-6 space-y-2">
          <div className="grid grid-cols-2 gap-2 py-2">
            {navLinks.map((item) => (
              <button
                key={item.path}
                onClick={() => handleLinkClick(item.path)}
                className={`text-left px-3 py-2 text-sm rounded-md ${
                  currentPath === item.path ? 'bg-slate-900 text-cyan-400 font-semibold' : 'text-slate-300 hover:bg-slate-900'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          <div className="pt-3 border-t border-slate-800/80 space-y-2">
            {user ? (
              <>
                <div className="px-3 py-1 text-xs text-slate-400 flex items-center justify-between">
                  <span>Signed in as <strong className="text-white">{user.name}</strong></span>
                  <span className="uppercase text-[10px] bg-slate-800 px-1.5 py-0.5 rounded text-cyan-300">{user.plan_tier}</span>
                </div>
                {user.role === 'admin' && (
                  <button
                    onClick={() => handleLinkClick('/admin')}
                    className="w-full flex items-center gap-2 px-3 py-2 text-sm text-amber-300 bg-amber-950/40 rounded-lg font-medium"
                  >
                    <Shield className="w-4 h-4" />
                    Admin Console
                  </button>
                )}
                <button
                  onClick={() => handleLinkClick('/dashboard')}
                  className="w-full flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-semibold text-white bg-cyan-600 rounded-lg"
                >
                  <LayoutDashboard className="w-4 h-4" />
                  Dashboard
                </button>
                <button
                  onClick={() => {
                    logout();
                    handleLinkClick('/');
                  }}
                  className="w-full flex items-center justify-center gap-2 px-4 py-2 text-sm text-slate-400 hover:text-white"
                >
                  <LogOut className="w-4 h-4" />
                  Sign Out
                </button>
              </>
            ) : (
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => handleLinkClick('/login')}
                  className="w-full px-3 py-2 text-sm font-medium text-center text-slate-200 bg-slate-900 rounded-lg"
                >
                  Sign In
                </button>
                <button
                  onClick={() => handleLinkClick('/register')}
                  className="w-full px-3 py-2 text-sm font-semibold text-center text-slate-950 bg-cyan-400 rounded-lg"
                >
                  Deploy Now
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
