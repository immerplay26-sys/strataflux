import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { Plus, X, Globe, Check, AlertCircle } from 'lucide-react';

interface NewProjectModalProps {
  isOpen: boolean;
  onClose: () => void;
  onProjectCreated: (project: any) => void;
}

export const NewProjectModal: React.FC<NewProjectModalProps> = ({ isOpen, onClose, onProjectCreated }) => {
  const { token } = useAuth();
  const [name, setName] = useState('');
  const [subdomain, setSubdomain] = useState('');
  const [framework, setFramework] = useState('static');
  const [loading, setLoading] = useState(false);
  const [subdomainStatus, setSubdomainStatus] = useState<'idle' | 'checking' | 'available' | 'taken'>('idle');
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleNameChange = (val: string) => {
    setName(val);
    if (!subdomain || subdomain === name.toLowerCase().replace(/[^a-z0-9-]/g, '').slice(0, 32)) {
      const generated = val.toLowerCase().replace(/[^a-z0-9-]/g, '').slice(0, 32);
      setSubdomain(generated);
      checkSubdomain(generated);
    }
  };

  const checkSubdomain = async (sub: string) => {
    if (sub.length < 3) {
      setSubdomainStatus('idle');
      return;
    }
    setSubdomainStatus('checking');
    try {
      const res = await fetch(`/api/projects/check-subdomain/${encodeURIComponent(sub)}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const d = await res.json();
        setSubdomainStatus(d.available ? 'available' : 'taken');
      }
    } catch (e) {
      setSubdomainStatus('idle');
    }
  };

  const handleSubdomainChange = (val: string) => {
    const clean = val.toLowerCase().replace(/[^a-z0-9-]/g, '').slice(0, 32);
    setSubdomain(clean);
    checkSubdomain(clean);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const res = await fetch('/api/projects', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ name, subdomain, framework })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed creating project');

      setName('');
      setSubdomain('');
      onProjectCreated(data.project);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Error creating project');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-4 sm:p-6 space-y-4 shadow-2xl max-h-[92vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h2 className="text-base font-bold text-white">Create New Project</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="p-3 bg-rose-950/50 border border-rose-800/60 rounded-lg text-rose-300 text-xs">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block text-slate-300 font-medium mb-1">Project Name</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => handleNameChange(e.target.value)}
              placeholder="e.g. My Portfolio Website"
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3.5 py-2.5 text-white placeholder-slate-600 focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-slate-300 font-medium">Edge Subdomain</label>
              {subdomainStatus === 'available' && (
                <span className="text-[10px] text-emerald-400 font-semibold flex items-center gap-1 font-mono">
                  <Check className="w-3 h-3" /> Available
                </span>
              )}
              {subdomainStatus === 'taken' && (
                <span className="text-[10px] text-rose-400 font-semibold flex items-center gap-1 font-mono">
                  <AlertCircle className="w-3 h-3" /> Already claimed
                </span>
              )}
            </div>
            <div className="flex items-center">
              <input
                type="text"
                required
                value={subdomain}
                onChange={(e) => handleSubdomainChange(e.target.value)}
                placeholder="my-portfolio"
                className="flex-1 bg-slate-950 border border-slate-800 rounded-l-lg px-3.5 py-2.5 text-white placeholder-slate-600 focus:outline-none focus:border-cyan-500 font-mono"
              />
              <span className="bg-slate-800 text-slate-400 px-3 py-2.5 rounded-r-lg border-y border-r border-slate-800 font-mono text-[11px]">
                .strataflux.app
              </span>
            </div>
          </div>

          <div>
            <label className="block text-slate-300 font-medium mb-1">Framework Preset</label>
            <select
              value={framework}
              onChange={(e) => setFramework(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3.5 py-2 text-white focus:outline-none focus:border-cyan-500"
            >
              <option value="static">Static HTML / CSS / JS</option>
              <option value="react">React / Vite</option>
              <option value="next">Next.js (Static Export)</option>
              <option value="astro">Astro</option>
              <option value="vue">Vue / Nuxt Static</option>
            </select>
          </div>

          <div className="pt-2">
            <button
              type="submit"
              disabled={loading || subdomainStatus === 'taken'}
              className="w-full py-2.5 bg-cyan-400 hover:bg-cyan-300 disabled:opacity-40 text-slate-950 font-semibold text-xs rounded-xl transition-colors"
            >
              {loading ? 'Creating Project...' : 'Initialize Project'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
