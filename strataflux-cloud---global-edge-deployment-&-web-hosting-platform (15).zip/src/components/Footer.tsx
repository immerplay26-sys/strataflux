import React from 'react';
import { Logo } from './Logo';
import { Mail, Phone, ExternalLink, Globe, ShieldCheck } from 'lucide-react';

interface FooterProps {
  onNavigate: (path: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const officialEmail = 'muhammadofficial356@gmail.com';
  const officialPhone = '+923199389323';
  const whatsappUrl = `https://wa.me/923199389323?text=${encodeURIComponent('Hello StrataFlux Cloud Support Team, I would like to inquire about website deployment and enterprise hosting services.')}`;

  return (
    <footer className="border-t border-slate-800/80 bg-slate-950 text-slate-400 text-sm mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 lg:gap-12">
          {/* Brand & Official Contact Column */}
          <div className="lg:col-span-2 space-y-4">
            <button onClick={() => onNavigate('/')} className="text-left focus:outline-none">
              <Logo size="md" />
            </button>
            <p className="text-slate-400 text-sm leading-relaxed max-w-sm">
              Global high-performance website deployment and edge hosting platform.
              Turn static packages into lightning-fast, secure edge websites in seconds.
            </p>

            <div className="pt-2 space-y-2.5">
              <div className="text-xs uppercase tracking-wider text-slate-500 font-semibold">Official Contact & Support</div>
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2.5 text-slate-300 hover:text-emerald-400 transition-colors"
              >
                <div className="w-7 h-7 rounded-md bg-emerald-950/60 border border-emerald-800/60 flex items-center justify-center text-emerald-400">
                  <Phone className="w-3.5 h-3.5" />
                </div>
                <span>WhatsApp: <strong className="text-emerald-400 font-mono">{officialPhone}</strong></span>
              </a>

              <a
                href={`mailto:${officialEmail}?subject=StrataFlux%20Enterprise%20Inquiry`}
                className="flex items-center gap-2.5 text-slate-300 hover:text-cyan-400 transition-colors"
              >
                <div className="w-7 h-7 rounded-md bg-cyan-950/60 border border-cyan-800/60 flex items-center justify-center text-cyan-400">
                  <Mail className="w-3.5 h-3.5" />
                </div>
                <span>Email: <strong className="text-cyan-400 font-mono">{officialEmail}</strong></span>
              </a>
            </div>

            <div className="pt-1 flex items-center gap-2 text-xs text-emerald-400">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span>All Global Edge POPs Operational (99.99% Uptime)</span>
            </div>
          </div>

          {/* Platform Column */}
          <div className="space-y-3">
            <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wider">Platform</h3>
            <ul className="space-y-2">
              <li>
                <button onClick={() => onNavigate('/features')} className="hover:text-cyan-400 transition-colors">
                  Features
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/how-it-works')} className="hover:text-cyan-400 transition-colors">
                  How It Works
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/pricing')} className="hover:text-cyan-400 transition-colors">
                  Plans & Pricing
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/documentation')} className="hover:text-cyan-400 transition-colors">
                  Documentation & CLI
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/status')} className="hover:text-cyan-400 transition-colors">
                  System Status
                </button>
              </li>
            </ul>
          </div>

          {/* Company Column */}
          <div className="space-y-3">
            <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wider">Company</h3>
            <ul className="space-y-2">
              <li>
                <button onClick={() => onNavigate('/about-us')} className="hover:text-cyan-400 transition-colors">
                  About StrataFlux
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/contact-us')} className="hover:text-cyan-400 transition-colors">
                  Contact & Escalation
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/security')} className="hover:text-cyan-400 transition-colors">
                  Security & Isolation
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/faq')} className="hover:text-cyan-400 transition-colors">
                  Developer FAQ
                </button>
              </li>
            </ul>
          </div>

          {/* Legal Column */}
          <div className="space-y-3">
            <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wider">Compliance & Legal</h3>
            <ul className="space-y-2">
              <li>
                <button onClick={() => onNavigate('/privacy-policy')} className="hover:text-cyan-400 transition-colors">
                  Privacy Policy
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/terms-of-service')} className="hover:text-cyan-400 transition-colors">
                  Terms of Service
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/cookie-policy')} className="hover:text-cyan-400 transition-colors">
                  Cookie Policy
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/acceptable-use')} className="hover:text-cyan-400 transition-colors">
                  Acceptable Use Policy
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/admin-login')} className="text-slate-600 hover:text-slate-400 transition-colors text-xs">
                  Administrative Access
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-8 mt-8 border-t border-slate-800/60 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div>
            &copy; {new Date().getFullYear()} StrataFlux Cloud Technologies. All rights reserved.
          </div>
          <div className="flex items-center gap-4">
            <span>Anycast Edge Architecture</span>
            <span aria-hidden="true">&middot;</span>
            <span>Zero-Config TLS</span>
            <span aria-hidden="true">&middot;</span>
            <span>High-Velocity Pipelines</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
