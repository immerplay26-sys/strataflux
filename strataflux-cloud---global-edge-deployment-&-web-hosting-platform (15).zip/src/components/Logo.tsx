import React from 'react';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  showText?: boolean;
}

export const Logo: React.FC<LogoProps> = ({ className = '', size = 'md', showText = true }) => {
  const sizeMap = {
    sm: { box: 'w-6 h-6', text: 'text-base font-bold' },
    md: { box: 'w-8 h-8', text: 'text-xl font-bold tracking-tight' },
    lg: { box: 'w-10 h-10', text: 'text-2xl font-extrabold tracking-tight' }
  };

  return (
    <div className={`flex items-center gap-2.5 ${className}`}>
      <div className={`relative ${sizeMap[size].box} flex items-center justify-center flex-shrink-0`}>
        <svg viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full drop-shadow-[0_0_12px_rgba(6,182,212,0.35)]">
          {/* Outer Hexagon Edge Base */}
          <path
            d="M18 3L32 10.5V25.5L18 33L4 25.5V10.5L18 3Z"
            stroke="#0ea5e9"
            strokeWidth="2.2"
            strokeLinejoin="round"
            className="opacity-90"
          />
          {/* Strata Parallel Speed Lines */}
          <path
            d="M10 16H26"
            stroke="#38bdf8"
            strokeWidth="2.4"
            strokeLinecap="round"
          />
          <path
            d="M7 21H29"
            stroke="#0284c7"
            strokeWidth="2.4"
            strokeLinecap="round"
          />
          {/* Central Apex Flux Node */}
          <circle cx="18" cy="11" r="2.8" fill="#38bdf8" />
        </svg>
      </div>

      {showText && (
        <span className={`text-white font-sans ${sizeMap[size].text}`}>
          Strata<span className="text-cyan-400">Flux</span>
        </span>
      )}
    </div>
  );
};
