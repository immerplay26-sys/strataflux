export interface User {
  id: string;
  email: string;
  name: string;
  role: 'user' | 'admin';
  status: 'active' | 'suspended' | 'banned';
  avatar_url?: string;
  email_verified?: boolean;
  plan_tier: 'free' | 'pro' | 'business';
  custom_domain_limit: number;
  storage_limit_bytes: number;
  bandwidth_limit_bytes: number;
  two_factor_enabled: boolean;
  created_at: string;
}

export interface Project {
  id: string;
  user_id: string;
  name: string;
  subdomain: string;
  framework: string;
  current_deployment_id?: string;
  status: 'ready' | 'deploying' | 'failed';
  storage_used_bytes: number;
  bandwidth_used_bytes: number;
  total_deployments: number;
  liveUrl: string;
  subdomainUrl: string;
  currentDeployment?: Deployment | null;
  customDomainsCount?: number;
  created_at: string;
  updated_at: string;
}

export interface Deployment {
  id: string;
  project_id: string;
  user_id: string;
  status: 'queued' | 'processing' | 'deploying' | 'live' | 'failed' | 'cancelled';
  source_type: 'zip' | 'files' | 'git' | 'cli';
  file_count: number;
  total_size_bytes: number;
  url: string;
  liveUrl?: string;
  subdomainUrl?: string;
  branch?: string;
  commit_message?: string;
  build_logs?: string;
  error_message?: string;
  isCurrent?: boolean;
  projectName?: string;
  projectSubdomain?: string;
  userEmail?: string;
  deployed_at?: string;
  created_at: string;
}

export interface CustomDomain {
  id: string;
  project_id: string;
  user_id: string;
  domain: string;
  verification_type: 'cname' | 'a';
  verification_token: string;
  is_verified: boolean;
  ssl_status: 'pending' | 'active' | 'failed';
  projectName?: string;
  projectSubdomain?: string;
  dns_records?: {
    type: string;
    name: string;
    value: string;
  }[];
  verified_at?: string;
  created_at: string;
}

export interface Plan {
  id: string;
  name: string;
  price_monthly: number;
  price_yearly: number;
  features: string[];
  max_projects: number;
  max_custom_domains: number;
  storage_limit_mb: number;
  bandwidth_limit_gb: number;
  analytics_retention_days: number;
}

export interface PaymentMethod {
  id: 'stripe' | 'paypal' | 'payoneer' | 'jazzcash' | 'easypaisa' | string;
  name: string;
  type: 'gateway' | 'manual';
  enabled: boolean;
  icon: string;
  description: string;
  accountName?: string;
  accountEmail?: string;
  accountNumber?: string;
  instructions?: string;
  publishableKey?: string;
  clientId?: string;
  currencies?: string[];
}

export interface Payment {
  id: string;
  user_id: string;
  user_email?: string;
  user_name?: string;
  plan_tier: string;
  plan_name: string;
  billing_interval: 'monthly' | 'yearly';
  amount: number;
  currency: string;
  provider: 'stripe' | 'paypal' | 'payoneer' | 'jazzcash' | 'easypaisa' | 'manual';
  payment_method: string;
  transaction_id: string;
  screenshot_path?: string;
  status: 'pending' | 'approved' | 'rejected' | 'completed' | 'failed';
  admin_note?: string;
  customer_note?: string;
  created_at: string;
  approved_at?: string;
  rejected_at?: string;
  approved_by?: string;
}

export interface SupportTicket {
  id: string;
  user_id: string;
  user_email: string;
  user_name: string;
  subject: string;
  category: 'technical' | 'billing' | 'domain' | 'abuse' | 'general';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  status: 'open' | 'in_progress' | 'resolved' | 'closed';
  messages: {
    id: string;
    sender_id: string;
    sender_name: string;
    sender_role: 'user' | 'admin';
    content: string;
    created_at: string;
  }[];
  created_at: string;
  updated_at: string;
}

export interface ActivityLog {
  id: string;
  actor_id?: string;
  actor_email?: string;
  actor_role?: string;
  action: string;
  resource_type: string;
  resource_id?: string;
  details?: Record<string, any>;
  ip_address?: string;
  created_at: string;
}

export interface PublicConfig {
  siteName: string;
  tagline: string;
  contactEmail: string;
  whatsapp: string;
  supportHours: string;
  heroTitle: string;
  heroSubtitle: string;
  announcement?: string | null;
  seo?: {
    meta_title?: string;
    meta_description?: string;
    canonical_url?: string;
    robots_txt?: string;
    google_site_verification?: string;
  };
  plans?: Plan[];
}
