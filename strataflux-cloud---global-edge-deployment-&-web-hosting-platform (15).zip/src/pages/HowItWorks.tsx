import React from 'react';
import { Upload, Cpu, Globe2, Radio, Terminal, ArrowRight, CheckCircle2 } from 'lucide-react';

interface HowItWorksProps {
  onNavigate: (path: string) => void;
}

export const HowItWorks: React.FC<HowItWorksProps> = ({ onNavigate }) => {
  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-16 space-y-20">
      <div className="text-center space-y-4 max-w-2xl mx-auto">
        <div className="text-cyan-400 font-semibold text-xs tracking-wider uppercase">Pipeline Architecture</div>
        <h1 className="text-4xl sm:text-5xl font-extrabold text-white tracking-tight">
          How StrataFlux deploys websites in seconds.
        </h1>
        <p className="text-slate-400 text-lg">
          From a local build folder or ZIP file to an Anycast edge point of presence around the world.
        </p>
      </div>

      {/* Step Sequence */}
      <div className="space-y-12 relative before:absolute before:inset-0 before:left-8 md:before:left-1/2 before:w-0.5 before:bg-slate-800 before:-translate-x-1/2">
        {/* Step 1 */}
        <div className="relative flex flex-col md:flex-row items-center gap-8">
          <div className="md:w-1/2 md:text-right order-2 md:order-1 space-y-3">
            <span className="text-xs font-mono text-cyan-400 font-semibold uppercase">Step 01 &middot; Package Export</span>
            <h3 className="text-2xl font-bold text-white">Generate your production assets</h3>
            <p className="text-slate-400 text-sm leading-relaxed">
              Run your favorite framework's build command (<code className="text-cyan-300 font-mono">npm run build</code>, <code className="text-cyan-300 font-mono">astro build</code>, etc.) to produce your static <code className="text-cyan-300 font-mono">dist</code> or <code className="text-cyan-300 font-mono">out</code> folder, then compress it into a ZIP archive.
            </p>
          </div>
          <div className="w-16 h-16 rounded-full bg-slate-900 border-2 border-cyan-500 text-cyan-400 flex items-center justify-center flex-shrink-0 z-10 shadow-lg shadow-cyan-950 order-1 md:order-2">
            <Upload className="w-7 h-7" />
          </div>
          <div className="md:w-1/2 order-3 bg-slate-900/80 border border-slate-800 rounded-xl p-5 font-mono text-xs text-slate-300">
            <div className="text-slate-500 mb-2">// 1. Build your static web application</div>
            <div className="text-cyan-400">$ npm run build</div>
            <div className="text-slate-400">&gt; vite build --outDir dist</div>
            <div className="text-emerald-400">&gt; built in 420ms (48 files)</div>
            <div className="text-cyan-400 mt-2">$ zip -r mywebsite.zip dist/</div>
          </div>
        </div>

        {/* Step 2 */}
        <div className="relative flex flex-col md:flex-row items-center gap-8">
          <div className="md:w-1/2 order-3 md:order-1 bg-slate-900/80 border border-slate-800 rounded-xl p-5 font-mono text-xs text-slate-300">
            <div className="text-slate-500 mb-2">// 2. Security sandbox audit</div>
            <div className="text-emerald-400">[PASS] Anti-Zip-Slip path verification</div>
            <div className="text-emerald-400">[PASS] Executable script scan: 0 threats</div>
            <div className="text-cyan-400">[EXTRACT] 48 static files unbundled</div>
            <div className="text-cyan-300">[ROOT] Resolved /index.html entrypoint</div>
          </div>
          <div className="w-16 h-16 rounded-full bg-slate-900 border-2 border-sky-500 text-sky-400 flex items-center justify-center flex-shrink-0 z-10 shadow-lg shadow-sky-950 order-1 md:order-2">
            <Cpu className="w-7 h-7" />
          </div>
          <div className="md:w-1/2 md:text-left order-2 md:order-3 space-y-3">
            <span className="text-xs font-mono text-sky-400 font-semibold uppercase">Step 02 &middot; Ingest & Isolation</span>
            <h3 className="text-2xl font-bold text-white">Quarantine & ZIP Extraction</h3>
            <p className="text-slate-400 text-sm leading-relaxed">
              Upon upload via web dashboard or API, the archive enters our sandbox worker. It verifies safety, detects directory nesting (e.g. flattening <code className="text-sky-300 font-mono">dist/</code>), and generates immutable release metadata.
            </p>
          </div>
        </div>

        {/* Step 3 */}
        <div className="relative flex flex-col md:flex-row items-center gap-8">
          <div className="md:w-1/2 md:text-right order-2 md:order-1 space-y-3">
            <span className="text-xs font-mono text-indigo-400 font-semibold uppercase">Step 03 &middot; Edge Broadcast</span>
            <h3 className="text-2xl font-bold text-white">Edge CDN & SSL Issuance</h3>
            <p className="text-slate-400 text-sm leading-relaxed">
              Assets are synchronized across our edge distribution nodes. Automatic TLS 1.3 certificates are issued for both the instant platform URL (<code className="text-indigo-300 font-mono">project.strataflux.app</code>) and connected custom domains.
            </p>
          </div>
          <div className="w-16 h-16 rounded-full bg-slate-900 border-2 border-indigo-500 text-indigo-400 flex items-center justify-center flex-shrink-0 z-10 shadow-lg shadow-indigo-950 order-1 md:order-2">
            <Globe2 className="w-7 h-7" />
          </div>
          <div className="md:w-1/2 order-3 bg-slate-900/80 border border-slate-800 rounded-xl p-5 font-mono text-xs text-slate-300">
            <div className="text-slate-500 mb-2">// 3. DNS routing & Anycast sync</div>
            <div className="text-indigo-400">Target: my-app.strataflux.app</div>
            <div className="text-slate-400">DNS: CNAME -&gt; edge.strataflux.app</div>
            <div className="text-emerald-400">SSL: Active (Let's Encrypt / Cloudflare Edge TLS)</div>
            <div className="text-cyan-300">Cache-Control: public, max-age=31536000 (assets)</div>
          </div>
        </div>

        {/* Step 4 */}
        <div className="relative flex flex-col md:flex-row items-center gap-8">
          <div className="md:w-1/2 order-3 md:order-1 bg-slate-900/80 border border-slate-800 rounded-xl p-5 font-mono text-xs text-slate-300">
            <div className="text-slate-500 mb-2">// 4. Live Edge Monitoring</div>
            <div className="text-emerald-400">STATUS: 200 OK &middot; Latency: 12ms</div>
            <div className="text-slate-400">Analytics: Hit logged (SHA-256 IP Hash)</div>
            <div className="text-cyan-400">Rollback Ready: Pointer release v2.4</div>
          </div>
          <div className="w-16 h-16 rounded-full bg-slate-900 border-2 border-emerald-500 text-emerald-400 flex items-center justify-center flex-shrink-0 z-10 shadow-lg shadow-emerald-950 order-1 md:order-2">
            <Radio className="w-7 h-7" />
          </div>
          <div className="md:w-1/2 md:text-left order-2 md:order-3 space-y-3">
            <span className="text-xs font-mono text-emerald-400 font-semibold uppercase">Step 04 &middot; Continuous Serving</span>
            <h3 className="text-2xl font-bold text-white">Live Serving & Telemetry</h3>
            <p className="text-slate-400 text-sm leading-relaxed">
              Your website is live globally. Every hit updates your private dashboard analytics (views, unique visitors, geo distribution, and bandwidth) with zero performance penalty.
            </p>
          </div>
        </div>
      </div>

      <div className="pt-8 text-center">
        <button
          onClick={() => onNavigate('/register')}
          className="px-8 py-3.5 text-base font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-xl shadow-lg transition-transform hover:scale-[1.02] inline-flex items-center gap-2"
        >
          <span>Try StrataFlux Now</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
