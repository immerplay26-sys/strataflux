import React, { useState } from 'react';
import { BookOpen, Terminal, Globe, ShieldCheck, Code, Layers, FileCode, CheckCircle2 } from 'lucide-react';

interface DocsProps {
  onNavigate: (path: string) => void;
}

export const Documentation: React.FC<DocsProps> = ({ onNavigate }) => {
  const [activeTab, setActiveTab] = useState<'quickstart' | 'frameworks' | 'domains' | 'api' | 'security'>('quickstart');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 space-y-12">
      <div className="space-y-4 max-w-3xl">
        <div className="text-cyan-400 font-semibold text-xs tracking-wider uppercase">Documentation & Developer Guide</div>
        <h1 className="text-4xl sm:text-5xl font-extrabold text-white tracking-tight">
          StrataFlux Cloud Technical Manual
        </h1>
        <p className="text-slate-400 text-lg">
          Complete guidelines for packaging, deploying, configuring custom domains, and automating deployments via REST API.
        </p>
      </div>

      {/* Docs Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-800 pb-4">
        {[
          { id: 'quickstart', label: 'Quick Start', icon: BookOpen },
          { id: 'frameworks', label: 'Framework Guides', icon: Layers },
          { id: 'domains', label: 'Custom Domains & DNS', icon: Globe },
          { id: 'api', label: 'REST API & cURL', icon: Terminal },
          { id: 'security', label: 'Security & Limits', icon: ShieldCheck }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
                isActive
                  ? 'bg-cyan-950/70 text-cyan-300 border border-cyan-800/80'
                  : 'text-slate-400 hover:text-white hover:bg-slate-900'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Tab Content */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-3 space-y-10">
          {activeTab === 'quickstart' && (
            <div className="space-y-8">
              <section className="space-y-4">
                <h2 className="text-2xl font-bold text-white">Deploying in 3 Simple Steps</h2>
                <p className="text-slate-300 text-sm leading-relaxed">
                  StrataFlux deploys any static website package. You don't need to configure a server, setup NGINX, or write complex Dockerfiles.
                </p>

                <div className="space-y-4 pt-2">
                  <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-2">
                    <h3 className="font-semibold text-white text-base flex items-center gap-2">
                      <span className="w-6 h-6 rounded-full bg-cyan-950 text-cyan-400 border border-cyan-800 text-xs flex items-center justify-center font-mono">1</span>
                      Create a Project in Your Dashboard
                    </h3>
                    <p className="text-slate-400 text-xs leading-relaxed">
                      Choose a project name and a unique platform subdomain (e.g., <code className="text-cyan-300 font-mono">my-portfolio</code>). This creates your permanent edge routing endpoint: <code className="text-cyan-300 font-mono">https://my-portfolio.strataflux.app</code>.
                    </p>
                  </div>

                  <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-2">
                    <h3 className="font-semibold text-white text-base flex items-center gap-2">
                      <span className="w-6 h-6 rounded-full bg-cyan-950 text-cyan-400 border border-cyan-800 text-xs flex items-center justify-center font-mono">2</span>
                      Compress Your Build Output into a ZIP
                    </h3>
                    <p className="text-slate-400 text-xs leading-relaxed">
                      Zip up your HTML, CSS, JavaScript, and media assets. If your files are inside a <code className="text-cyan-300 font-mono">dist</code> or <code className="text-cyan-300 font-mono">build</code> folder, StrataFlux automatically detects and flattens it for you so <code className="text-cyan-300 font-mono">index.html</code> is at the root.
                    </p>
                  </div>

                  <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-2">
                    <h3 className="font-semibold text-white text-base flex items-center gap-2">
                      <span className="w-6 h-6 rounded-full bg-cyan-950 text-cyan-400 border border-cyan-800 text-xs flex items-center justify-center font-mono">3</span>
                      Drag and Drop onto the Deploy Area
                    </h3>
                    <p className="text-slate-400 text-xs leading-relaxed">
                      The server ingests, scans, extracts, and activates your deployment globally. You receive an instant live URL with TLS encryption within seconds.
                    </p>
                  </div>
                </div>
              </section>
            </div>
          )}

          {activeTab === 'frameworks' && (
            <div className="space-y-8">
              <section className="space-y-6">
                <h2 className="text-2xl font-bold text-white">Framework Build Guides</h2>

                {/* Vite / React */}
                <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-bold text-white">Vite / React / Vue</h3>
                    <span className="text-xs bg-slate-800 text-cyan-300 px-2 py-0.5 rounded font-mono">dist/</span>
                  </div>
                  <p className="text-sm text-slate-400">
                    Vite compiles production assets directly into the <code className="text-cyan-300 font-mono">dist</code> directory.
                  </p>
                  <pre className="bg-slate-950 p-4 rounded-lg font-mono text-xs text-slate-300 border border-slate-800 overflow-x-auto">
{`# 1. Build the production bundle
npm run build

# 2. Compress the dist directory
zip -r build.zip dist/

# 3. Upload build.zip to your StrataFlux project dashboard`}
                  </pre>
                </div>

                {/* Next.js Static Export */}
                <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-bold text-white">Next.js (Static HTML Export)</h3>
                    <span className="text-xs bg-slate-800 text-cyan-300 px-2 py-0.5 rounded font-mono">out/</span>
                  </div>
                  <p className="text-sm text-slate-400">
                    Add <code className="text-cyan-300 font-mono">output: 'export'</code> to your <code className="text-cyan-300 font-mono">next.config.js</code> file:
                  </p>
                  <pre className="bg-slate-950 p-4 rounded-lg font-mono text-xs text-slate-300 border border-slate-800 overflow-x-auto">
{`// next.config.js
module.exports = {
  output: 'export',
  images: { unoptimized: true }
};

# Run the build (generates out/ folder)
npm run build

# Compress the export
zip -r site.zip out/`}
                  </pre>
                </div>

                {/* Astro */}
                <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-bold text-white">Astro</h3>
                    <span className="text-xs bg-slate-800 text-cyan-300 px-2 py-0.5 rounded font-mono">dist/</span>
                  </div>
                  <p className="text-sm text-slate-400">
                    Astro generates static HTML/CSS/JS by default.
                  </p>
                  <pre className="bg-slate-950 p-4 rounded-lg font-mono text-xs text-slate-300 border border-slate-800 overflow-x-auto">
{`npm run build
zip -r astro-build.zip dist/`}
                  </pre>
                </div>
              </section>
            </div>
          )}

          {activeTab === 'domains' && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-white">Custom Domain & DNS Setup</h2>
              <p className="text-slate-300 text-sm leading-relaxed">
                StrataFlux allows you to attach custom domains to any project. Our automated DNS verification engine checks CNAME and TXT records.
              </p>

              <div className="border border-slate-800 rounded-xl overflow-hidden">
                <table className="w-full text-left text-xs font-mono text-slate-300">
                  <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                    <tr>
                      <th className="py-3 px-4">Type</th>
                      <th className="py-3 px-4">Host / Name</th>
                      <th className="py-3 px-4">Target / Value</th>
                      <th className="py-3 px-4">Purpose</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    <tr>
                      <td className="py-3 px-4 text-cyan-400 font-bold">CNAME</td>
                      <td className="py-3 px-4">www or subdomain</td>
                      <td className="py-3 px-4 text-emerald-400">strataflux.app</td>
                      <td className="py-3 px-4 text-slate-400 font-sans">Routes web traffic to Anycast edge network</td>
                    </tr>
                    <tr>
                      <td className="py-3 px-4 text-amber-400 font-bold">TXT</td>
                      <td className="py-3 px-4">_strataflux.yourdomain.com</td>
                      <td className="py-3 px-4 text-slate-300">strataflux-verification=&lt;token&gt;</td>
                      <td className="py-3 px-4 text-slate-400 font-sans">Verifies domain ownership</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-2">
                <h3 className="font-semibold text-white text-sm">Automated Edge SSL Certificates</h3>
                <p className="text-slate-400 text-xs leading-relaxed">
                  Once your CNAME or TXT record is detected by our DNS verification worker, an edge TLS 1.3 certificate is automatically issued and maintained with zero downtime.
                </p>
              </div>
            </div>
          )}

          {activeTab === 'api' && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-white">REST API & Automated Deployments</h2>
              <p className="text-slate-300 text-sm leading-relaxed">
                Integrate StrataFlux into your CI/CD pipelines (GitHub Actions, GitLab CI, or custom deployment scripts) using our standard HTTP endpoints.
              </p>

              <div className="space-y-4">
                <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
                  <div className="flex items-center gap-2 font-mono text-xs">
                    <span className="bg-emerald-950 text-emerald-400 border border-emerald-800 px-2 py-0.5 rounded font-bold">POST</span>
                    <span className="text-white">/api/deploy/zip/:projectId</span>
                  </div>
                  <p className="text-xs text-slate-400">Deploy a ZIP archive to a project with a single cURL command:</p>
                  <pre className="bg-slate-950 p-4 rounded-lg font-mono text-xs text-cyan-300 border border-slate-800 overflow-x-auto">
{`curl -X POST "https://strataflux.app/api/deploy/zip/prj_xyz123" \\
  -H "Authorization: Bearer YOUR_API_TOKEN" \\
  -F "zipfile=@dist.zip" \\
  -F "message=Automated release from GitHub Actions"`}
                  </pre>
                </div>

                <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
                  <div className="flex items-center gap-2 font-mono text-xs">
                    <span className="bg-blue-950 text-blue-400 border border-blue-800 px-2 py-0.5 rounded font-bold">GET</span>
                    <span className="text-white">/api/projects</span>
                  </div>
                  <p className="text-xs text-slate-400">List all projects and their active live deployment URLs:</p>
                  <pre className="bg-slate-950 p-4 rounded-lg font-mono text-xs text-cyan-300 border border-slate-800 overflow-x-auto">
{`curl "https://strataflux.app/api/projects" \\
  -H "Authorization: Bearer YOUR_API_TOKEN"`}
                  </pre>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'security' && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-white">Security Controls & File Constraints</h2>
              <p className="text-slate-300 text-sm leading-relaxed">
                To guarantee maximum platform reliability and prevent abusive payloads, StrataFlux enforces strict sandbox validation:
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-2">
                  <h3 className="font-semibold text-rose-400">Forbidden Executables</h3>
                  <p className="text-slate-400">
                    Uploaded archives containing executable binaries or server scripts (<code className="font-mono text-rose-300">.php, .exe, .sh, .py, .rb, .pl, .cgi</code>) are instantly rejected during unpack.
                  </p>
                </div>

                <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-2">
                  <h3 className="font-semibold text-cyan-400">Supported File Types</h3>
                  <p className="text-slate-400">
                    All static assets: HTML, CSS, JavaScript, JSON, SVG, PNG, JPG, WebP, AVIF, WOFF2, TTF, MP4, WebM, PDF, and WASM.
                  </p>
                </div>

                <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-2">
                  <h3 className="font-semibold text-amber-400">Archive Size Limits</h3>
                  <p className="text-slate-400">
                    Standard ZIP uploads support archives up to 50 MB (Starter tier) or 250 MB (Pro/Business tiers).
                  </p>
                </div>

                <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-2">
                  <h3 className="font-semibold text-indigo-400">Path Sanitization</h3>
                  <p className="text-slate-400">
                    Zip-Slip security guards reject any relative path traversal components (<code className="font-mono text-indigo-300">..</code>) to ensure strict sandbox isolation.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Sidebar Help Card */}
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-4">
            <h3 className="text-base font-bold text-white">Need Support?</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Our engineering team is available 24/7 for technical assistance, migration support, and custom domain advice.
            </p>
            <button
              onClick={() => onNavigate('/contact-us')}
              className="w-full py-2 px-3 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg transition-colors"
            >
              Contact Support
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
