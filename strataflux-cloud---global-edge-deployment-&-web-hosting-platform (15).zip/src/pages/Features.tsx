import React from 'react';
import { Zap, Globe, Shield, RefreshCw, BarChart3, Database, Server, Cpu, CheckCircle2 } from 'lucide-react';

interface FeaturesProps {
  onNavigate: (path: string) => void;
}

export const Features: React.FC<FeaturesProps> = ({ onNavigate }) => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 space-y-20">
      <div className="text-center space-y-4 max-w-3xl mx-auto">
        <div className="text-cyan-400 font-semibold text-xs tracking-wider uppercase">Platform Capabilities</div>
        <h1 className="text-4xl sm:text-5xl font-extrabold text-white tracking-tight">
          Everything required to deploy, scale, and secure static websites.
        </h1>
        <p className="text-slate-400 text-lg">
          Designed from the ground up for front-end developers, marketing teams, agencies, and enterprise web applications.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 space-y-4">
          <div className="w-12 h-12 rounded-lg bg-cyan-950 border border-cyan-800/60 text-cyan-400 flex items-center justify-center">
            <Zap className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-bold text-white">ZIP & Folder Extraction</h3>
          <p className="text-slate-400 text-sm leading-relaxed">
            Drag and drop ZIP archives exported from any framework (Vite, Next.js static HTML, Nuxt, Astro, Svelte, or vanilla JS). Our server extracts and verifies files in under 2 seconds.
          </p>
          <ul className="text-xs text-slate-300 space-y-2 pt-2">
            <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-cyan-400" /> Automatic index.html root resolution</li>
            <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-cyan-400" /> MIME type auto-detection</li>
            <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-cyan-400" /> Zip-slip path traversal guards</li>
          </ul>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 space-y-4">
          <div className="w-12 h-12 rounded-lg bg-sky-950 border border-sky-800/60 text-sky-400 flex items-center justify-center">
            <Globe className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-bold text-white">Custom Domains & Auto-TLS</h3>
          <p className="text-slate-400 text-sm leading-relaxed">
            Connect any branded custom domain with real-time CNAME and TXT verification. Automated SSL/TLS provisioning ensures 100% encrypted HTTPS traffic.
          </p>
          <ul className="text-xs text-slate-300 space-y-2 pt-2">
            <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-sky-400" /> Subdomain & Apex domain support</li>
            <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-sky-400" /> Automated TLS 1.3 certificates</li>
            <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-sky-400" /> Instant DNS record validation</li>
          </ul>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 space-y-4">
          <div className="w-12 h-12 rounded-lg bg-indigo-950 border border-indigo-800/60 text-indigo-400 flex items-center justify-center">
            <Shield className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-bold text-white">Isolated Sandbox Security</h3>
          <p className="text-slate-400 text-sm leading-relaxed">
            Uploaded websites operate within isolated sandboxes. No dangerous server scripts (PHP, Python, shell scripts) are permitted to execute on the server.
          </p>
          <ul className="text-xs text-slate-300 space-y-2 pt-2">
            <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-indigo-400" /> Strict executable file quarantine</li>
            <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-indigo-400" /> Content Security & XSS protection</li>
            <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-indigo-400" /> Per-project storage boundary isolation</li>
          </ul>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 space-y-4">
          <div className="w-12 h-12 rounded-lg bg-amber-950 border border-amber-800/60 text-amber-400 flex items-center justify-center">
            <RefreshCw className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-bold text-white">Version Control & Rollbacks</h3>
          <p className="text-slate-400 text-sm leading-relaxed">
            Every deployment receives an immutable release ID. Inspect past commits, view historical build logs, and switch your live URL to any previous release instantly.
          </p>
          <ul className="text-xs text-slate-300 space-y-2 pt-2">
            <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-amber-400" /> One-click promote to production</li>
            <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-amber-400" /> Full build output log audits</li>
            <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-amber-400" /> Zero-downtime revision pointer swaps</li>
          </ul>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 space-y-4">
          <div className="w-12 h-12 rounded-lg bg-emerald-950 border border-emerald-800/60 text-emerald-400 flex items-center justify-center">
            <BarChart3 className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-bold text-white">Edge-Native Analytics</h3>
          <p className="text-slate-400 text-sm leading-relaxed">
            Get accurate visitor insights without cookies or privacy-invading tracking scripts. Hits are aggregated directly at the HTTP server level with daily salted SHA-256 IP hashing.
          </p>
          <ul className="text-xs text-slate-300 space-y-2 pt-2">
            <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-400" /> Geographic country breakdown</li>
            <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-400" /> Devices, browsers & operating systems</li>
            <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-400" /> Real-time bandwidth tracking</li>
          </ul>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 space-y-4">
          <div className="w-12 h-12 rounded-lg bg-purple-950 border border-purple-800/60 text-purple-400 flex items-center justify-center">
            <Server className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-bold text-white">Relational DB & Enterprise API</h3>
          <p className="text-slate-400 text-sm leading-relaxed">
            Built on a production PostgreSQL database architecture with connection pooling, migrations, automated activity audit logs, and RESTful APIs.
          </p>
          <ul className="text-xs text-slate-300 space-y-2 pt-2">
            <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-purple-400" /> Production SQL migrations included</li>
            <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-purple-400" /> Comprehensive REST endpoints</li>
            <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-purple-400" /> Cloudflare R2 / S3 storage integration</li>
          </ul>
        </div>
      </div>

      <div className="pt-8 text-center">
        <button
          onClick={() => onNavigate('/pricing')}
          className="px-8 py-3.5 text-base font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-xl shadow-lg transition-transform hover:scale-[1.02]"
        >
          View Pricing Plans & Get Started
        </button>
      </div>
    </div>
  );
};
