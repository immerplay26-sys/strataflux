import React from 'react';

interface UseProps {
  onNavigate: (path: string) => void;
}

export const AcceptableUse: React.FC<UseProps> = ({ onNavigate }) => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 space-y-10 text-slate-300">
      <div className="border-b border-slate-800 pb-6 space-y-2">
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white">Acceptable Use Policy (AUP)</h1>
        <p className="text-xs text-slate-500 font-mono">Last Updated: September 2026</p>
      </div>

      <div className="space-y-6 text-sm leading-relaxed">
        <p>
          This Acceptable Use Policy governs all websites, projects, and files uploaded to or distributed via StrataFlux Cloud edge infrastructure.
        </p>

        <section className="space-y-2">
          <h2 className="text-lg font-bold text-white">Prohibited Activities</h2>
          <ul className="list-disc pl-5 space-y-1.5 text-slate-400">
            <li>Hosting phishing portals, credential harvesters, or deceptive brand impersonations.</li>
            <li>Uploading malware, ransomware, cryptominers, or exploit payloads.</li>
            <li>Attempting server sandbox breakouts or relative path traversal exploits.</li>
            <li>Distributing pirated software or unauthorized copyrighted digital media.</li>
            <li>Conducting denial of service attacks or unauthorized penetration testing.</li>
          </ul>
        </section>

        <section className="space-y-2">
          <h2 className="text-lg font-bold text-white">Enforcement & Abuse Reporting</h2>
          <p>
            Deployments violating this policy are suspended immediately without refund. If you encounter a website hosted on StrataFlux violating these standards, report it to:
          </p>
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 font-mono text-xs text-rose-300">
            Abuse Desk: muhammadofficial356@gmail.com | WhatsApp: +923199389323
          </div>
        </section>
      </div>
    </div>
  );
};
