import React from 'react';
import { Shield, Lock, FileCheck, Server, AlertTriangle, EyeOff } from 'lucide-react';

interface SecurityProps {
  onNavigate: (path: string) => void;
}

export const Security: React.FC<SecurityProps> = ({ onNavigate }) => {
  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-16 space-y-16">
      <div className="space-y-4 max-w-3xl">
        <div className="text-cyan-400 font-semibold text-xs tracking-wider uppercase">Infrastructure Defense</div>
        <h1 className="text-4xl sm:text-5xl font-extrabold text-white tracking-tight">
          Security by Design & Sandbox Isolation
        </h1>
        <p className="text-slate-400 text-lg leading-relaxed">
          How StrataFlux Cloud protects tenant data, prevents malicious payload execution, guarantees privacy compliance, and secures edge deployments.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-3">
          <div className="w-10 h-10 rounded-lg bg-indigo-950 border border-indigo-800 text-indigo-400 flex items-center justify-center">
            <Lock className="w-5 h-5" />
          </div>
          <h3 className="text-lg font-bold text-white">Zero Server-Side Script Execution</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            StrataFlux is strictly a static deployment engine. Uploaded files are served with read-only sandbox permissions. Executable scripts such as PHP, Python, Bash, Perl, or binaries are completely quarantined and prohibited from invoking OS processes.
          </p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-3">
          <div className="w-10 h-10 rounded-lg bg-cyan-950 border border-cyan-800 text-cyan-400 flex items-center justify-center">
            <FileCheck className="w-5 h-5" />
          </div>
          <h3 className="text-lg font-bold text-white">Zip-Slip & Path Sanitization</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            All uploaded ZIP archives undergo recursive path verification. Any relative directory traversal sequences (<code className="text-cyan-300 font-mono">..</code>) or absolute escape paths are intercepted and rejected before extraction.
          </p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-3">
          <div className="w-10 h-10 rounded-lg bg-emerald-950 border border-emerald-800 text-emerald-400 flex items-center justify-center">
            <EyeOff className="w-5 h-5" />
          </div>
          <h3 className="text-lg font-bold text-white">Hashed Analytics (Zero Cookies)</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            We never track users across websites, set third-party cookies, or store raw IP addresses. Client IPs are combined with daily cryptographically salted keys and hashed with SHA-256 for GDPR and CCPA compliant privacy.
          </p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-3">
          <div className="w-10 h-10 rounded-lg bg-amber-950 border border-amber-800 text-amber-400 flex items-center justify-center">
            <Server className="w-5 h-5" />
          </div>
          <h3 className="text-lg font-bold text-white">Anycast DDoS Mitigation & Edge TLS</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Traffic routes through global Anycast nodes with distributed Layer 3/4 and Layer 7 DDoS mitigation. TLS 1.3 encryption is applied automatically across all custom domains.
          </p>
        </div>
      </div>

      <div className="border border-slate-800 rounded-xl bg-slate-900/60 p-8 space-y-4">
        <h2 className="text-xl font-bold text-white">Responsible Disclosure & Security Inquiries</h2>
        <p className="text-sm text-slate-400 leading-relaxed">
          If you have discovered a security vulnerability or have compliance inquiries regarding SOC 2, HIPAA, or ISO 27001 data processing, please contact our security team directly:
        </p>
        <div className="text-xs text-slate-300 space-y-1 font-mono">
          <div>Email: <a href="mailto:muhammadofficial356@gmail.com" className="text-cyan-400 underline">muhammadofficial356@gmail.com</a></div>
          <div>WhatsApp Security Hotline: <span className="text-emerald-400">+923199389323</span></div>
        </div>
      </div>
    </div>
  );
};
