import React from 'react';
import { ShieldCheck, Zap, Globe, Heart, Phone, Mail } from 'lucide-react';

interface AboutProps {
  onNavigate: (path: string) => void;
}

export const AboutUs: React.FC<AboutProps> = ({ onNavigate }) => {
  const officialEmail = 'muhammadofficial356@gmail.com';
  const officialPhone = '+923199389323';

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-16 space-y-16">
      <div className="space-y-4 max-w-3xl">
        <div className="text-cyan-400 font-semibold text-xs tracking-wider uppercase">About StrataFlux Cloud</div>
        <h1 className="text-4xl sm:text-5xl font-extrabold text-white tracking-tight">
          Democratizing global website deployment for developers everywhere.
        </h1>
        <p className="text-slate-400 text-lg leading-relaxed">
          We built StrataFlux because deploying static web applications should take seconds, not hours of server provisioning, complex CI/CD debugging, or expensive multi-cloud contracts.
        </p>
      </div>

      {/* Core Mission */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-3">
          <div className="w-10 h-10 rounded-lg bg-cyan-950 border border-cyan-800/60 text-cyan-400 flex items-center justify-center">
            <Zap className="w-5 h-5" />
          </div>
          <h3 className="text-lg font-bold text-white">What StrataFlux Does</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            StrataFlux turns static packages (ZIP archives or folders of HTML, CSS, JavaScript, and media) into globally accessible, secure web applications backed by automated edge CDN distribution and TLS encryption.
          </p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-3">
          <div className="w-10 h-10 rounded-lg bg-sky-950 border border-sky-800/60 text-sky-400 flex items-center justify-center">
            <Globe className="w-5 h-5" />
          </div>
          <h3 className="text-lg font-bold text-white">Why It Exists</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Legacy cloud providers force developers through labyrinthine dashboards, IAM permissions, VPC routing tables, and unpredictable billing models. StrataFlux distills this into a single drag-and-drop workflow.
          </p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-3">
          <div className="w-10 h-10 rounded-lg bg-indigo-950 border border-indigo-800/60 text-indigo-400 flex items-center justify-center">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <h3 className="text-lg font-bold text-white">Who It Is For</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Frontend engineers, JAMstack creators, marketing teams, design agencies, and fast-moving startups looking to launch portfolios, documentation, e-commerce landing pages, and web apps with zero friction.
          </p>
        </div>
      </div>

      {/* Philosophy Section */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-8 space-y-6">
        <h2 className="text-2xl font-bold text-white">Our Engineering Principles</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-sm text-slate-300">
          <div className="space-y-2">
            <div className="font-semibold text-cyan-400">Zero-Friction Ingestion</div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Whether you upload a ZIP via your browser, deploy through our REST API, or drag a folder, extraction and sandbox verification happens instantaneously.
            </p>
          </div>
          <div className="space-y-2">
            <div className="font-semibold text-cyan-400">Privacy-First Edge Telemetry</div>
            <p className="text-xs text-slate-400 leading-relaxed">
              We never install third-party tracking pixels or sell visitor analytics. All hit metrics are computed server-side with daily salted SHA-256 IP hashes.
            </p>
          </div>
          <div className="space-y-2">
            <div className="font-semibold text-cyan-400">Deterministic Sandboxing</div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Every project is quarantined in isolated object storage paths. Executable server scripts are rejected, keeping the global network secure and immune to exploits.
            </p>
          </div>
          <div className="space-y-2">
            <div className="font-semibold text-cyan-400">Continuous Availability & Rollback</div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Past deployments remain immutable. If a mistake makes it into production, reverting to any previous revision takes one click and zero downtime.
            </p>
          </div>
        </div>
      </div>

      {/* Official Team & Contact */}
      <div className="border-t border-slate-800 pt-8 space-y-4">
        <h2 className="text-xl font-bold text-white">Official Platform Administration & Contact</h2>
        <p className="text-sm text-slate-400">
          Have questions, custom enterprise inquiries, or partnership proposals? Contact our core platform team directly:
        </p>
        <div className="flex flex-col sm:flex-row gap-4 pt-2">
          <a
            href={`https://wa.me/923199389323?text=${encodeURIComponent('Hello StrataFlux Platform Team')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-3 bg-emerald-950/40 border border-emerald-800/60 p-4 rounded-xl text-emerald-300 hover:bg-emerald-950/60 transition-colors"
          >
            <Phone className="w-5 h-5 text-emerald-400" />
            <div>
              <div className="text-xs text-slate-400">Official WhatsApp</div>
              <div className="font-mono font-semibold">{officialPhone}</div>
            </div>
          </a>

          <a
            href={`mailto:${officialEmail}?subject=Inquiry%20regarding%20StrataFlux`}
            className="flex items-center gap-3 bg-cyan-950/40 border border-cyan-800/60 p-4 rounded-xl text-cyan-300 hover:bg-cyan-950/60 transition-colors"
          >
            <Mail className="w-5 h-5 text-cyan-400" />
            <div>
              <div className="text-xs text-slate-400">Official Email</div>
              <div className="font-mono font-semibold">{officialEmail}</div>
            </div>
          </a>
        </div>
      </div>
    </div>
  );
};
