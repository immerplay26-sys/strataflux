import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Logo } from '../../components/Logo';
import {
  LayoutDashboard,
  FolderGit2,
  Rocket,
  Globe,
  BarChart3,
  CreditCard,
  LifeBuoy,
  Settings,
  BookOpen,
  LogOut,
  Menu,
  X,
  ExternalLink,
  Shield,
  Bell
} from 'lucide-react';

interface DashboardLayoutProps {
  currentPath: string;
  onNavigate: (path: string) => void;
  children: React.ReactNode;
}

export const DashboardLayout: React.FC<DashboardLayoutProps> = ({ currentPath, onNavigate, children }) => {
  const { user, logout } = useAuth();
  const [mobileOpen, setMobileOpen] = useState(false);

  const sidebarLinks = [
    { label: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
    { label: 'Projects', path: '/dashboard/projects', icon: FolderGit2 },
    { label: 'Deployments', path: '/dashboard/deployments', icon: Rocket },
    { label: 'Domains', path: '/dashboard/domains', icon: Globe },
    { label: 'Analytics', path: '/dashboard/analytics', icon: BarChart3 },
    { label: 'Billing', path: '/dashboard/billing', icon: CreditCard },
    { label: 'Support', path: '/dashboard/support', icon: LifeBuoy },
    { label: 'Settings', path: '/dashboard/settings', icon: Settings },
    { label: 'Documentation', path: '/documentation', icon: BookOpen },
  ];

  const handleNav = (p: string) => {
    onNavigate(p);
    setMobileOpen(false);
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col md:flex-row">
      {/* Mobile Top Header */}
      <div className="md:hidden flex items-center justify-between p-4 border-b border-slate-800 bg-slate-950 sticky top-0 z-40">
        <button onClick={() => handleNav('/dashboard')}>
          <Logo size="sm" />
        </button>
        <button
          onClick={() => setMobileOpen(!mobileOpen)}
          className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-900"
        >
          {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {/* Mobile Backdrop */}
      {mobileOpen && (
        <div
          onClick={() => setMobileOpen(false)}
          className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-40 md:hidden"
        />
      )}

      {/* Sidebar (Desktop + Mobile drawer) */}
      <aside
        className={`${
          mobileOpen ? 'translate-x-0' : '-translate-x-full'
        } md:translate-x-0 transition-transform duration-200 ease-in-out flex flex-col w-64 border-r border-slate-800/80 bg-slate-950 p-4 flex-shrink-0 z-50 fixed md:sticky top-0 h-screen overflow-y-auto`}
      >
        {/* Brand */}
        <div className="hidden md:flex items-center justify-between pb-6 border-b border-slate-800/80">
          <button onClick={() => handleNav('/dashboard')} className="focus:outline-none">
            <Logo size="md" />
          </button>
        </div>

        {/* User Card */}
        <div className="my-4 p-3 bg-slate-900/80 border border-slate-800 rounded-xl flex items-center justify-between">
          <div className="truncate">
            <div className="text-xs font-semibold text-white truncate">{user?.name}</div>
            <div className="text-[11px] text-slate-400 truncate">{user?.email}</div>
          </div>
          <span className="uppercase text-[10px] font-bold bg-cyan-950 text-cyan-300 border border-cyan-800/60 px-2 py-0.5 rounded">
            {user?.plan_tier}
          </span>
        </div>

        {/* Nav Items */}
        <nav className="space-y-1 flex-1">
          {sidebarLinks.map((item) => {
            const Icon = item.icon;
            const isActive = currentPath === item.path || (item.path !== '/dashboard' && currentPath.startsWith(item.path));
            return (
              <button
                key={item.path}
                onClick={() => handleNav(item.path)}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-colors ${
                  isActive
                    ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-cyan-400' : 'text-slate-400'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Footer Actions */}
        <div className="pt-4 border-t border-slate-800/80 space-y-2">
          {user?.role === 'admin' && (
            <button
              onClick={() => handleNav('/admin')}
              className="w-full flex items-center gap-2.5 px-3.5 py-2 rounded-xl text-xs font-semibold text-amber-300 bg-amber-950/40 border border-amber-800/50 hover:bg-amber-900/40 transition-colors"
            >
              <Shield className="w-4 h-4" />
              <span>Admin Console</span>
            </button>
          )}

          <button
            onClick={() => {
              logout();
              handleNav('/');
            }}
            className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-medium text-slate-400 hover:text-rose-400 hover:bg-slate-900/60 transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span>Sign Out</span>
          </button>
        </div>
      </aside>

      {/* Main Content Pane */}
      <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto overflow-y-auto">
        {children}
      </main>
    </div>
  );
};
