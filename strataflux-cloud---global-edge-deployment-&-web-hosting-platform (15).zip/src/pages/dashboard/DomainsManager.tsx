import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { CustomDomain } from '../../types';
import { Globe, RefreshCw, Trash2, ShieldCheck, AlertCircle } from 'lucide-react';

interface DomainsManagerProps {
  onNavigate: (path: string) => void;
}

export const DomainsManager: React.FC<DomainsManagerProps> = ({ onNavigate }) => {
  const { token } = useAuth();
  const [domains, setDomains] = useState<CustomDomain[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchDomains = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/domains', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setDomains(data.domains || []);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDomains();
  }, []);

  const handleVerify = async (id: string) => {
    try {
      const res = await fetch(`/api/domains/${id}/verify`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (data.check?.verified) {
        alert('Domain verified successfully!');
      } else {
        alert('DNS records not detected yet. CNAME or TXT record required.');
      }
      fetchDomains();
    } catch (e) {
      alert('Verification error');
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Remove this custom domain?')) return;
    try {
      await fetch(`/api/domains/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });
      fetchDomains();
    } catch (e) {}
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">Custom Domains</h1>
          <p className="text-xs text-slate-400 mt-1">
            Global Anycast edge routing and automated SSL certificates across all connected domains.
          </p>
        </div>
        <button
          onClick={fetchDomains}
          className="p-2 text-slate-400 hover:text-white bg-slate-900 border border-slate-800 rounded-lg self-start sm:self-auto"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
        {loading ? (
          <div className="text-center py-12 text-xs text-slate-500">Loading custom domains...</div>
        ) : domains.length === 0 ? (
          <div className="text-center py-12 text-xs text-slate-500 space-y-2">
            <div>No custom domains attached to your projects yet.</div>
            <p className="text-slate-600 max-w-sm mx-auto">
              Open any project to attach your custom branded domain with automated DNS verification.
            </p>
          </div>
        ) : (
          <div className="divide-y divide-slate-800/80">
            {domains.map((d) => (
              <div key={d.id} className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white text-base font-mono">{d.domain}</span>
                    <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded ${
                      d.is_verified ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/60' : 'bg-amber-950 text-amber-400'
                    }`}>
                      {d.is_verified ? 'Verified & Active' : 'Pending DNS'}
                    </span>
                    <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded font-mono">
                      TLS 1.3: {d.ssl_status}
                    </span>
                  </div>
                  <div className="text-xs text-slate-400">
                    Project: <strong className="text-slate-300">{d.projectName}</strong> ({d.projectSubdomain}.strataflux.app)
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <button
                    onClick={() => handleVerify(d.id)}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-cyan-400 font-semibold text-xs rounded-lg transition-colors flex items-center gap-1.5"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    Verify DNS
                  </button>
                  <button
                    onClick={() => handleDelete(d.id)}
                    className="p-1.5 text-slate-500 hover:text-rose-400 rounded-lg hover:bg-slate-800"
                    title="Delete domain"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-6 space-y-3">
        <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider">DNS Record Requirements</h3>
        <p className="text-xs text-slate-400 leading-relaxed">
          Configure a <strong className="text-cyan-400 font-mono">CNAME</strong> record pointing your subdomain or domain to <code className="text-cyan-300 font-mono">strataflux.app</code>. For apex domain setups, configure an ALIAS/ANAME record or our edge IP addresses.
        </p>
      </div>
    </div>
  );
};
