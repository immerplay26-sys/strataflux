import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { User, Lock, Key, Shield, Copy, Check, Trash2 } from 'lucide-react';

interface UserSettingsProps {
  onNavigate: (path: string) => void;
}

export const UserSettings: React.FC<UserSettingsProps> = ({ onNavigate }) => {
  const { user, token, updateProfile, changePassword, logout } = useAuth();

  const [name, setName] = useState(user?.name || '');
  const [email, setEmail] = useState(user?.email || '');
  const [twoFactor, setTwoFactor] = useState(user?.two_factor_enabled || false);
  const [profileMsg, setProfileMsg] = useState<string | null>(null);

  // Password state
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passMsg, setPassMsg] = useState<string | null>(null);
  const [passError, setPassError] = useState<string | null>(null);

  // API Token
  const [copiedToken, setCopiedToken] = useState(false);

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setProfileMsg(null);
    try {
      await updateProfile({ name, email, two_factor_enabled: twoFactor });
      setProfileMsg('Profile updated successfully.');
    } catch (e: any) {
      alert(e.message || 'Failed updating profile');
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPassMsg(null);
    setPassError(null);

    if (newPassword !== confirmPassword) {
      setPassError('New passwords do not match.');
      return;
    }
    if (newPassword.length < 8) {
      setPassError('New password must be at least 8 characters long.');
      return;
    }

    try {
      await changePassword(currentPassword, newPassword);
      setPassMsg('Password changed successfully.');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (e: any) {
      setPassError(e.message || 'Failed changing password');
    }
  };

  const copyApiToken = () => {
    if (!token) return;
    navigator.clipboard.writeText(token);
    setCopiedToken(true);
    setTimeout(() => setCopiedToken(false), 2000);
  };

  const handleDeleteAccount = () => {
    if (confirm('Are you absolutely certain you want to delete your account? All projects and deployments will be permanently deleted.')) {
      logout();
      onNavigate('/');
    }
  };

  return (
    <div className="space-y-8 max-w-3xl">
      <div>
        <h1 className="text-2xl font-bold text-white tracking-tight">Account & Security Settings</h1>
        <p className="text-xs text-slate-400 mt-1">
          Configure personal credentials, security keys, and automated deployment tokens.
        </p>
      </div>

      {/* Profile Form */}
      <form onSubmit={handleUpdateProfile} className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
        <h2 className="text-base font-bold text-white">Profile Details</h2>

        {profileMsg && (
          <div className="p-3 bg-emerald-950/40 border border-emerald-800/60 rounded-lg text-emerald-300 text-xs">
            {profileMsg}
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Full Name</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Email Address</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
            />
          </div>
        </div>

        <div className="flex items-center gap-2 pt-2">
          <input
            type="checkbox"
            id="twoFactor"
            checked={twoFactor}
            onChange={(e) => setTwoFactor(e.target.checked)}
            className="rounded border-slate-700 bg-slate-950 text-cyan-500 focus:ring-0"
          />
          <label htmlFor="twoFactor" className="text-xs text-slate-300">
            Require Two-Factor Authentication (2FA) for administrative operations
          </label>
        </div>

        <button
          type="submit"
          className="px-4 py-2 bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-semibold text-xs rounded-lg transition-colors"
        >
          Save Profile
        </button>
      </form>

      {/* Password Change Form */}
      <form onSubmit={handleChangePassword} className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
        <h2 className="text-base font-bold text-white">Change Password</h2>

        {passMsg && (
          <div className="p-3 bg-emerald-950/40 border border-emerald-800/60 rounded-lg text-emerald-300 text-xs">
            {passMsg}
          </div>
        )}
        {passError && (
          <div className="p-3 bg-rose-950/40 border border-rose-800/60 rounded-lg text-rose-300 text-xs">
            {passError}
          </div>
        )}

        <div>
          <label className="block text-xs font-medium text-slate-300 mb-1">Current Password</label>
          <input
            type="password"
            required
            value={currentPassword}
            onChange={(e) => setCurrentPassword(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">New Password (min 8 chars)</label>
            <input
              type="password"
              required
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Confirm New Password</label>
            <input
              type="password"
              required
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
            />
          </div>
        </div>

        <button
          type="submit"
          className="px-4 py-2 bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-semibold text-xs rounded-lg transition-colors"
        >
          Update Password
        </button>
      </form>

      {/* REST API & CLI Token */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
        <h2 className="text-base font-bold text-white">CLI & REST API Bearer Token</h2>
        <p className="text-xs text-slate-400 leading-relaxed">
          Use this secret authentication token in your CI/CD pipelines (e.g., GitHub Actions, cURL scripts) to deploy directly to your projects without logging in through the web UI.
        </p>

        <div className="flex items-center gap-2">
          <input
            type="password"
            readOnly
            value={token || 'Not logged in'}
            className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-3.5 py-2 text-xs font-mono text-cyan-300 focus:outline-none"
          />
          <button
            onClick={copyApiToken}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors"
          >
            {copiedToken ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            <span>{copiedToken ? 'Copied' : 'Copy Token'}</span>
          </button>
        </div>
      </div>

      {/* Danger Zone */}
      <div className="bg-rose-950/20 border border-rose-900/60 rounded-2xl p-6 space-y-3">
        <h3 className="text-sm font-bold text-rose-400">Delete Account</h3>
        <p className="text-xs text-slate-400 leading-relaxed">
          Permanently erase your user profile, all projects, sandboxed files, and historical analytics. This action cannot be reversed.
        </p>
        <button
          onClick={handleDeleteAccount}
          className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white font-semibold text-xs rounded-lg transition-colors flex items-center gap-1.5"
        >
          <Trash2 className="w-3.5 h-3.5" />
          Delete Account
        </button>
      </div>
    </div>
  );
};
