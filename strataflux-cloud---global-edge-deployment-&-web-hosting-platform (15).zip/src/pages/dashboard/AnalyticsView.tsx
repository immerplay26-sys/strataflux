import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { BarChart3, Users, Globe, Activity, RefreshCw } from 'lucide-react';

interface AnalyticsViewProps {
  onNavigate: (path: string) => void;
}

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({ onNavigate }) => {
  const { token } = useAuth();
  const [data, setData] = useState<any>(null);
  const [days, setDays] = useState(30);
  const [loading, setLoading] = useState(true);

  const fetchAnalytics = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/analytics/overview?days=${days}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const d = await res.json();
        setData(d);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAnalytics();
  }, [days]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">Website Analytics</h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time server-side traffic metrics aggregated across all your hosted projects.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {[7, 30, 90].map((d) => (
            <button
              key={d}
              onClick={() => setDays(d)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                days === d
                  ? 'bg-cyan-500 text-slate-950 shadow-sm'
                  : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {d} Days
            </button>
          ))}
          <button
            onClick={fetchAnalytics}
            className="p-1.5 text-slate-400 hover:text-white bg-slate-900 border border-slate-800 rounded-lg"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-1">
          <span className="text-xs text-slate-400 font-semibold uppercase">Total Views ({days}d)</span>
          <div className="text-3xl font-extrabold text-white font-mono">{data?.summary?.totalViews || 0}</div>
          <div className="text-[11px] text-slate-500">Page visits served</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-1">
          <span className="text-xs text-slate-400 font-semibold uppercase">Edge Bandwidth</span>
          <div className="text-3xl font-extrabold text-cyan-400 font-mono">
            {data?.summary?.totalBandwidthBytes
              ? (data.summary.totalBandwidthBytes / 1024 / 1024).toFixed(1) + ' MB'
              : '0 MB'}
          </div>
          <div className="text-[11px] text-slate-500">Transferred via Anycast</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-1">
          <span className="text-xs text-slate-400 font-semibold uppercase">Active Projects</span>
          <div className="text-3xl font-extrabold text-white font-mono">{data?.summary?.totalProjects || 0}</div>
          <div className="text-[11px] text-slate-500">Reporting telemetry</div>
        </div>
      </div>

      {/* Projects Breakdown Table */}
      <div className="space-y-3">
        <h2 className="text-sm font-bold text-white">Project Traffic Breakdown</h2>
        <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
          {loading ? (
            <div className="text-center py-12 text-xs text-slate-500">Loading traffic distribution...</div>
          ) : !data?.projects || data.projects.length === 0 ? (
            <div className="text-center py-12 text-xs text-slate-500">No project visits recorded in this period.</div>
          ) : (
            <div className="overflow-x-auto w-full table-responsive-container">
              <table className="w-full text-left text-xs text-slate-300 min-w-[560px]">
                <thead className="bg-slate-950 text-slate-400 font-semibold border-b border-slate-800">
                  <tr>
                    <th className="py-3 px-4">Project</th>
                    <th className="py-3 px-4">Subdomain</th>
                    <th className="py-3 px-4">Total Views</th>
                    <th className="py-3 px-4">Unique Visitors</th>
                    <th className="py-3 px-4">Bandwidth</th>
                    <th className="py-3 px-4 text-right">Details</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono">
                  {data.projects.map((p: any) => (
                    <tr key={p.id} className="hover:bg-slate-800/30">
                      <td className="py-3 px-4 font-sans font-bold text-white">{p.name}</td>
                      <td className="py-3 px-4 text-cyan-300">{p.subdomain}.strataflux.app</td>
                      <td className="py-3 px-4 text-white font-bold">{p.views}</td>
                      <td className="py-3 px-4 text-slate-400">{p.visitors}</td>
                      <td className="py-3 px-4 text-slate-400">{(p.bandwidth / 1024 / 1024).toFixed(2)} MB</td>
                      <td className="py-3 px-4 text-right font-sans whitespace-nowrap">
                        <button
                          onClick={() => onNavigate(`/dashboard/projects/${p.id}`)}
                          className="text-cyan-400 hover:text-cyan-300 font-medium"
                        >
                          Inspect
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
