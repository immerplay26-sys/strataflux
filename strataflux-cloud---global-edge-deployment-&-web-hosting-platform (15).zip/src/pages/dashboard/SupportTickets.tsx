import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { SupportTicket } from '../../types';
import { LifeBuoy, Plus, Send, MessageSquare, Clock, CheckCircle2, Shield } from 'lucide-react';

interface SupportTicketsProps {
  onNavigate: (path: string) => void;
}

export const SupportTickets: React.FC<SupportTicketsProps> = ({ onNavigate }) => {
  const { token, user } = useAuth();
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTicket, setActiveTicket] = useState<SupportTicket | null>(null);

  // New ticket state
  const [showNewModal, setShowNewModal] = useState(false);
  const [subject, setSubject] = useState('');
  const [category, setCategory] = useState<'technical' | 'billing' | 'domain' | 'abuse' | 'general'>('technical');
  const [priority, setPriority] = useState<'low' | 'medium' | 'high' | 'urgent'>('medium');
  const [initialMessage, setInitialMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);

  // Reply state
  const [replyContent, setReplyContent] = useState('');
  const [replying, setReplying] = useState(false);

  const fetchTickets = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/support/tickets', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setTickets(data.tickets || []);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTickets();
  }, []);

  const handleCreateTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await fetch('/api/support/tickets', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          subject,
          category,
          priority,
          message: initialMessage
        })
      });
      if (res.ok) {
        setShowNewModal(false);
        setSubject('');
        setInitialMessage('');
        fetchTickets();
      } else {
        const d = await res.json();
        alert(d.error || 'Failed submitting ticket');
      }
    } catch (e) {
      alert('Error submitting ticket');
    } finally {
      setSubmitting(false);
    }
  };

  const handleSendReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeTicket || !replyContent.trim()) return;
    setReplying(true);
    try {
      const res = await fetch(`/api/support/tickets/${activeTicket.id}/reply`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ content: replyContent })
      });
      if (res.ok) {
        const data = await res.json();
        setActiveTicket(data.ticket);
        setReplyContent('');
        fetchTickets();
      }
    } catch (e) {
      alert('Failed sending reply');
    } finally {
      setReplying(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">Support & Escalations</h1>
          <p className="text-xs text-slate-400 mt-1">
            Submit questions to our engineering and operations team with trackable ticket history.
          </p>
        </div>
        <button
          onClick={() => setShowNewModal(true)}
          className="px-4 py-2 bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-semibold text-xs rounded-lg shadow-sm transition-colors flex items-center gap-1.5 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          Create Support Ticket
        </button>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
        {loading ? (
          <div className="text-center py-12 text-xs text-slate-500">Loading support tickets...</div>
        ) : tickets.length === 0 ? (
          <div className="text-center py-12 text-xs text-slate-500 space-y-3">
            <LifeBuoy className="w-10 h-10 text-slate-600 mx-auto" />
            <div>You have no active or historical support tickets.</div>
          </div>
        ) : (
          <div className="overflow-x-auto w-full table-responsive-container">
            <table className="w-full text-left text-xs text-slate-300 min-w-[580px]">
              <thead className="bg-slate-950 text-slate-400 font-semibold border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4">Subject</th>
                  <th className="py-3 px-4">Category</th>
                  <th className="py-3 px-4">Priority</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Last Updated</th>
                  <th className="py-3 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono">
                {tickets.map((t) => (
                  <tr key={t.id} className="hover:bg-slate-800/30">
                    <td className="py-3 px-4 font-sans font-medium text-white max-w-xs truncate">{t.subject}</td>
                    <td className="py-3 px-4 uppercase text-slate-400 text-[10px]">{t.category}</td>
                    <td className="py-3 px-4 uppercase text-[10px] text-amber-300">{t.priority}</td>
                    <td className="py-3 px-4">
                      <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded ${
                        t.status === 'open'
                          ? 'bg-cyan-950 text-cyan-400 border border-cyan-800/60'
                          : t.status === 'in_progress'
                          ? 'bg-amber-950 text-amber-400 border border-amber-800/60'
                          : 'bg-emerald-950 text-emerald-400 border border-emerald-800/60'
                      }`}>
                        {t.status.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-500 font-sans whitespace-nowrap">{new Date(t.updated_at).toLocaleDateString()}</td>
                    <td className="py-3 px-4 text-right font-sans whitespace-nowrap">
                      <button
                        onClick={() => setActiveTicket(t)}
                        className="text-cyan-400 hover:text-cyan-300 font-medium"
                      >
                        View Thread ({t.messages?.length || 0})
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* New Ticket Modal */}
      {showNewModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-white text-base">Submit Support Ticket</h3>
              <button onClick={() => setShowNewModal(false)} className="text-slate-400 hover:text-white text-xs">
                Cancel
              </button>
            </div>

            <form onSubmit={handleCreateTicket} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Subject</label>
                <input
                  type="text"
                  required
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="e.g. Issue connecting custom domain CNAME"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3.5 py-2 text-white focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3.5 py-2 text-white focus:outline-none focus:border-cyan-500"
                  >
                    <option value="technical">Technical / Extraction</option>
                    <option value="domain">Custom Domain / DNS</option>
                    <option value="billing">Billing & Plans</option>
                    <option value="abuse">Abuse / Security</option>
                    <option value="general">General Question</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-medium mb-1">Priority</label>
                  <select
                    value={priority}
                    onChange={(e) => setPriority(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3.5 py-2 text-white focus:outline-none focus:border-cyan-500"
                  >
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                    <option value="urgent">Urgent</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Description / Error Details</label>
                <textarea
                  required
                  rows={4}
                  value={initialMessage}
                  onChange={(e) => setInitialMessage(e.target.value)}
                  placeholder="Provide complete information, project name, or reproduction steps..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3.5 py-2 text-white focus:outline-none focus:border-cyan-500 resize-none"
                ></textarea>
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="w-full py-2.5 bg-cyan-400 hover:bg-cyan-300 disabled:opacity-50 text-slate-950 font-semibold rounded-lg transition-colors"
              >
                {submitting ? 'Submitting...' : 'Open Support Ticket'}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Conversation Thread Modal */}
      {activeTicket && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full p-6 space-y-4 shadow-2xl flex flex-col max-h-[85vh]">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="font-bold text-white text-sm">{activeTicket.subject}</h3>
                <div className="text-[11px] text-slate-400 font-mono">
                  {activeTicket.id} &middot; Status: <span className="uppercase text-cyan-400">{activeTicket.status}</span>
                </div>
              </div>
              <button onClick={() => setActiveTicket(null)} className="text-slate-400 hover:text-white text-xs">
                Close
              </button>
            </div>

            {/* Messages Stream */}
            <div className="flex-1 overflow-y-auto space-y-3 pr-2">
              {activeTicket.messages?.map((m) => {
                const isAdmin = m.sender_role === 'admin';
                return (
                  <div
                    key={m.id}
                    className={`p-4 rounded-xl text-xs space-y-1.5 ${
                      isAdmin
                        ? 'bg-amber-950/30 border border-amber-800/50 text-amber-200'
                        : 'bg-slate-950 border border-slate-800 text-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="font-bold flex items-center gap-1.5">
                        {isAdmin && <Shield className="w-3.5 h-3.5 text-amber-400" />}
                        {m.sender_name} {isAdmin ? '(StrataFlux Support)' : '(You)'}
                      </span>
                      <span className="text-slate-500">{new Date(m.created_at).toLocaleString()}</span>
                    </div>
                    <p className="whitespace-pre-wrap leading-relaxed">{m.content}</p>
                  </div>
                );
              })}
            </div>

            {/* Reply Box */}
            <form onSubmit={handleSendReply} className="pt-2 border-t border-slate-800 flex gap-2">
              <input
                type="text"
                required
                value={replyContent}
                onChange={(e) => setReplyContent(e.target.value)}
                placeholder="Type your reply to the engineering team..."
                className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
              />
              <button
                type="submit"
                disabled={replying}
                className="px-4 py-2 bg-cyan-400 hover:bg-cyan-300 disabled:opacity-50 text-slate-950 font-semibold text-xs rounded-lg transition-colors flex items-center gap-1"
              >
                <Send className="w-3.5 h-3.5" />
                Reply
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
