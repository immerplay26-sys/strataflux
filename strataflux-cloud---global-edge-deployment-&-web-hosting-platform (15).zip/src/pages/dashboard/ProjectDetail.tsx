import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Project, Deployment, CustomDomain } from '../../types';
import {
  UploadCloud,
  Rocket,
  Globe,
  BarChart3,
  Settings,
  History,
  CheckCircle2,
  AlertTriangle,
  ExternalLink,
  Copy,
  Trash2,
  RefreshCw,
  Terminal,
  FileText,
  Clock,
  Check,
  ShieldCheck,
  ArrowLeft
} from 'lucide-react';

interface ProjectDetailProps {
  projectId: string;
  onNavigate: (path: string) => void;
}

export const ProjectDetail: React.FC<ProjectDetailProps> = ({ projectId, onNavigate }) => {
  const { token, user } = useAuth();
  const [project, setProject] = useState<Project | null>(null);
  const [deployments, setDeployments] = useState<Deployment[]>([]);
  const [domains, setDomains] = useState<CustomDomain[]>([]);
  const [analytics, setAnalytics] = useState<any>(null);
  const [activeTab, setActiveTab] = useState<'deploy' | 'history' | 'domains' | 'analytics' | 'settings'>('deploy');
  const [loading, setLoading] = useState(true);

  // Deploy workflow state
  const [uploadMode, setUploadMode] = useState<'zip' | 'files'>('zip');
  const [dragActive, setDragActive] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [commitMessage, setCommitMessage] = useState('');
  const [deployingState, setDeployingState] = useState<'idle' | 'uploading' | 'processing' | 'deploying' | 'live' | 'failed'>('idle');
  const [deployProgress, setDeployProgress] = useState(0);
  const [deployLogs, setDeployLogs] = useState('');
  const [deployError, setDeployError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Domain add state
  const [newDomain, setNewDomain] = useState('');
  const [addingDomain, setAddingDomain] = useState(false);
  const [domainError, setDomainError] = useState<string | null>(null);

  // Logs modal
  const [inspectedDeployment, setInspectedDeployment] = useState<Deployment | null>(null);

  // Settings
  const [editName, setEditName] = useState('');
  const [editFramework, setEditFramework] = useState('static');
  const [copiedUrl, setCopiedUrl] = useState(false);

  const fetchProjectDetails = async () => {
    try {
      const res = await fetch(`/api/projects/${projectId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setProject(data.project);
        setDeployments(data.project.deployments || []);
        setDomains(data.project.domains || []);
        setEditName(data.project.name);
        setEditFramework(data.project.framework || 'static');
      }
    } catch (e) {
      console.error('Failed fetching project', e);
    } finally {
      setLoading(false);
    }
  };

  const fetchAnalytics = async () => {
    try {
      const res = await fetch(`/api/analytics/project/${projectId}?days=30`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setAnalytics(data);
      }
    } catch (e) {
      console.error('Failed loading analytics', e);
    }
  };

  useEffect(() => {
    fetchProjectDetails();
  }, [projectId]);

  useEffect(() => {
    if (activeTab === 'analytics') {
      fetchAnalytics();
    }
  }, [activeTab]);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') setDragActive(true);
    else if (e.type === 'dragleave') setDragActive(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      if (uploadMode === 'zip') {
        const file = e.dataTransfer.files[0];
        setSelectedFile(file);
        if (!commitMessage) setCommitMessage(`Deployed ${file.name}`);
      } else {
        const files = Array.from(e.dataTransfer.files);
        setSelectedFiles(files);
        if (!commitMessage) setCommitMessage(`Uploaded ${files.length} static website files`);
      }
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      if (uploadMode === 'zip') {
        const file = e.target.files[0];
        setSelectedFile(file);
        if (!commitMessage) setCommitMessage(`Deployed ${file.name}`);
      } else {
        const files = Array.from(e.target.files);
        setSelectedFiles(files);
        if (!commitMessage) setCommitMessage(`Uploaded ${files.length} static website files`);
      }
    }
  };

  const startDeployment = async () => {
    const isZip = uploadMode === 'zip';
    if (isZip && !selectedFile) return;
    if (!isZip && selectedFiles.length === 0) return;

    setDeployingState('uploading');
    setDeployProgress(25);
    setDeployError(null);
    setDeployLogs(`[${new Date().toISOString()}] Initiating asset upload to edge cluster...\n`);

    const formData = new FormData();
    if (isZip && selectedFile) {
      formData.append('zipfile', selectedFile);
      formData.append('message', commitMessage || 'Manual dashboard upload');
    } else {
      selectedFiles.forEach((f) => formData.append('files', f));
      formData.append('message', commitMessage || `Uploaded ${selectedFiles.length} files`);
    }

    try {
      setDeployingState('processing');
      setDeployProgress(55);
      setDeployLogs(prev => prev + `[${new Date().toISOString()}] Unpacking archive and auditing sandbox safety...\n`);

      const endpoint = isZip ? `/api/deploy/zip/${projectId}` : `/api/deploy/files/${projectId}`;
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
        body: formData
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Deployment failed');

      setDeployProgress(85);
      setDeployingState('deploying');
      setDeployLogs(data.deployment.build_logs || '');

      setTimeout(() => {
        setDeployProgress(100);
        setDeployingState('live');
        fetchProjectDetails();
        setSelectedFile(null);
        setSelectedFiles([]);
      }, 800);
    } catch (err: any) {
      setDeployingState('failed');
      setDeployError(err.message || 'Deployment error');
      setDeployLogs(prev => prev + `\n[FATAL ERROR] ${err.message}`);
    }
  };

  const handleRollback = async (deploymentId: string) => {
    if (!confirm('Promote this previous deployment to production? The live URL will immediately switch to this revision.')) return;
    try {
      const res = await fetch(`/api/deploy/rollback/${deploymentId}`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        await fetchProjectDetails();
        alert('Deployment successfully restored as the live production version.');
      } else {
        const data = await res.json();
        alert(data.error || 'Failed rollback');
      }
    } catch (e) {
      alert('Error rolling back');
    }
  };

  const handleAddDomain = async (e: React.FormEvent) => {
    e.preventDefault();
    setAddingDomain(true);
    setDomainError(null);

    try {
      const res = await fetch('/api/domains', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ projectId, domain: newDomain })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed connecting domain');

      setNewDomain('');
      fetchProjectDetails();
    } catch (err: any) {
      setDomainError(err.message || 'Domain connection error');
    } finally {
      setAddingDomain(false);
    }
  };

  const handleVerifyDomain = async (domainId: string) => {
    try {
      const res = await fetch(`/api/domains/${domainId}/verify`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (data.check?.verified) {
        alert('Domain verified successfully! SSL certificate is active.');
      } else {
        alert('DNS records not yet detected. Please verify your CNAME record points to strataflux.app.');
      }
      fetchProjectDetails();
    } catch (e) {
      alert('Error verifying domain DNS');
    }
  };

  const handleDeleteDomain = async (domainId: string) => {
    if (!confirm('Remove this custom domain from project?')) return;
    try {
      await fetch(`/api/domains/${domainId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });
      fetchProjectDetails();
    } catch (e) {}
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch(`/api/projects/${projectId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ name: editName, framework: editFramework })
      });
      if (res.ok) {
        alert('Project settings saved.');
        fetchProjectDetails();
      }
    } catch (e) {
      alert('Failed saving settings');
    }
  };

  const handleDeleteProject = async () => {
    const confirmation = prompt(`To permanently delete this project and all its deployments, type "${project?.name}":`);
    if (confirmation !== project?.name) return;

    try {
      const res = await fetch(`/api/projects/${projectId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        onNavigate('/dashboard/projects');
      }
    } catch (e) {
      alert('Failed deleting project');
    }
  };

  const copyUrl = () => {
    if (!project) return;
    navigator.clipboard.writeText(project.liveUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  if (loading) {
    return <div className="text-center py-20 text-xs text-slate-500">Loading project configuration...</div>;
  }

  if (!project) {
    return (
      <div className="text-center py-20 space-y-4">
        <h2 className="text-lg font-bold text-white">Project Not Found</h2>
        <button onClick={() => onNavigate('/dashboard/projects')} className="text-xs text-cyan-400 underline">
          Return to Projects
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Top Breadcrumb & Header */}
      <div className="space-y-3">
        <button
          onClick={() => onNavigate('/dashboard/projects')}
          className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-white transition-colors"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to Projects</span>
        </button>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-2xl p-6">
          <div className="space-y-1">
            <div className="flex items-center gap-3">
              <h1 className="text-2xl font-bold text-white">{project.name}</h1>
              <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                project.status === 'ready'
                  ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/60'
                  : 'bg-amber-950 text-amber-400'
              }`}>
                {project.status}
              </span>
            </div>

            <div className="flex items-center gap-3 text-xs text-slate-400 font-mono pt-1">
              <span>{project.subdomain}.strataflux.app</span>
              <button
                onClick={copyUrl}
                title="Copy live URL"
                className="hover:text-cyan-400 transition-colors flex items-center gap-1"
              >
                {copiedUrl ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <a
              href={project.liveUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2 bg-cyan-400 hover:bg-cyan-300 text-slate-950 text-xs font-semibold rounded-lg shadow-sm transition-colors flex items-center gap-1.5"
            >
              <span>Visit Live Website</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2 overflow-x-auto text-xs font-semibold">
        {[
          { id: 'deploy', label: 'Deploy & Upload', icon: UploadCloud },
          { id: 'history', label: `Deployments (${deployments.length})`, icon: History },
          { id: 'domains', label: `Custom Domains (${domains.length})`, icon: Globe },
          { id: 'analytics', label: 'Website Analytics', icon: BarChart3 },
          { id: 'settings', label: 'Project Settings', icon: Settings },
        ].map((t) => {
          const Icon = t.icon;
          const isActive = activeTab === t.id;
          return (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id as any)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition-colors whitespace-nowrap ${
                isActive
                  ? 'bg-cyan-950/70 text-cyan-400 border border-cyan-800/80'
                  : 'text-slate-400 hover:text-white hover:bg-slate-900'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{t.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: Deploy & Upload */}
      {activeTab === 'deploy' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="space-y-0.5">
                <h2 className="text-lg font-bold text-white">Deploy New Website Revision</h2>
                <p className="text-xs text-slate-400">
                  Deploy instantly via pre-packaged ZIP archive or multi-file website drop.
                </p>
              </div>

              {/* Upload Mode Switcher */}
              <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 self-start sm:self-auto">
                <button
                  type="button"
                  onClick={() => {
                    setUploadMode('zip');
                    setSelectedFile(null);
                    setSelectedFiles([]);
                  }}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                    uploadMode === 'zip'
                      ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Upload ZIP Archive
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setUploadMode('files');
                    setSelectedFile(null);
                    setSelectedFiles([]);
                  }}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                    uploadMode === 'files'
                      ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Upload Website Files
                </button>
              </div>
            </div>

            {/* Drag & Drop Zone */}
            <div
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-xl p-8 sm:p-12 text-center cursor-pointer transition-all ${
                dragActive
                  ? 'border-cyan-400 bg-cyan-950/20'
                  : 'border-slate-800 hover:border-slate-700 bg-slate-950/60'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept={uploadMode === 'zip' ? '.zip' : '.html,.htm,.css,.js,.mjs,.json,.png,.jpg,.jpeg,.svg,.gif,.webp,.ico,.txt,.pdf,.wasm'}
                multiple={uploadMode === 'files'}
                onChange={handleFileChange}
                className="hidden"
              />

              <div className="w-14 h-14 rounded-full bg-cyan-950/60 text-cyan-400 flex items-center justify-center mx-auto mb-3">
                <UploadCloud className="w-7 h-7" />
              </div>

              {uploadMode === 'zip' ? (
                selectedFile ? (
                  <div className="space-y-1">
                    <div className="text-sm font-semibold text-white font-mono">{selectedFile.name}</div>
                    <div className="text-xs text-cyan-400 font-mono">{(selectedFile.size / 1024).toFixed(1)} KB &middot; Ready to deploy</div>
                    <div className="text-[11px] text-slate-500 pt-1">Click to select a different file</div>
                  </div>
                ) : (
                  <div className="space-y-1">
                    <div className="text-sm font-semibold text-white">Drop your website ZIP archive here</div>
                    <div className="text-xs text-slate-400">Supports Vite, Next export, Astro, React, and pure HTML (.zip)</div>
                    <div className="text-[11px] text-cyan-400 pt-1 font-medium">or click to browse ZIP archive</div>
                  </div>
                )
              ) : (
                selectedFiles.length > 0 ? (
                  <div className="space-y-1">
                    <div className="text-sm font-semibold text-white font-mono">{selectedFiles.length} files selected</div>
                    <div className="text-xs text-cyan-400 font-mono">
                      {(selectedFiles.reduce((acc, f) => acc + f.size, 0) / 1024).toFixed(1)} KB total &middot; Ready to deploy
                    </div>
                    <div className="text-[11px] text-slate-500 pt-1">
                      {selectedFiles.slice(0, 3).map(f => f.name).join(', ')}{selectedFiles.length > 3 ? '...' : ''} &middot; Click to re-select
                    </div>
                  </div>
                ) : (
                  <div className="space-y-1">
                    <div className="text-sm font-semibold text-white">Drop your website files here</div>
                    <div className="text-xs text-slate-400">Select index.html, styles, scripts and assets</div>
                    <div className="text-[11px] text-cyan-400 pt-1 font-medium">or click to browse multiple files</div>
                  </div>
                )
              )}
            </div>

            {/* Commit Message & Action */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 items-end">
              <div className="sm:col-span-2">
                <label className="block text-xs font-medium text-slate-300 mb-1">Deployment Note / Commit Message</label>
                <input
                  type="text"
                  value={commitMessage}
                  onChange={(e) => setCommitMessage(e.target.value)}
                  placeholder="e.g. Updated homepage hero & added pricing section"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3.5 py-2 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <button
                onClick={startDeployment}
                disabled={(!selectedFile && selectedFiles.length === 0) || deployingState === 'uploading' || deployingState === 'processing'}
                className="w-full py-2.5 px-4 bg-cyan-400 hover:bg-cyan-300 disabled:opacity-40 text-slate-950 font-semibold text-xs rounded-lg shadow-md transition-colors flex items-center justify-center gap-2"
              >
                <Rocket className="w-4 h-4" />
                {deployingState === 'uploading' || deployingState === 'processing'
                  ? 'Deploying to Edge...'
                  : 'Start Edge Deployment'}
              </button>
            </div>

            {/* Active Deploy State Progress Bar */}
            {deployingState !== 'idle' && (
              <div className="space-y-3 pt-4 border-t border-slate-800/80">
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-white uppercase font-bold flex items-center gap-2">
                    {deployingState === 'live' ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    ) : deployingState === 'failed' ? (
                      <AlertTriangle className="w-4 h-4 text-rose-400" />
                    ) : (
                      <RefreshCw className="w-4 h-4 text-cyan-400 animate-spin" />
                    )}
                    Pipeline Status: {deployingState}
                  </span>
                  <span className="text-cyan-400">{deployProgress}%</span>
                </div>

                <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                  <div
                    className={`h-full transition-all duration-300 ${
                      deployingState === 'live'
                        ? 'bg-emerald-400'
                        : deployingState === 'failed'
                        ? 'bg-rose-500'
                        : 'bg-cyan-400'
                    }`}
                    style={{ width: `${deployProgress}%` }}
                  ></div>
                </div>

                {/* Build logs terminal preview */}
                <div className="bg-slate-950 rounded-xl p-4 font-mono text-xs text-slate-300 border border-slate-800 max-h-48 overflow-y-auto whitespace-pre-wrap">
                  {deployLogs}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: Deployments History */}
      {activeTab === 'history' && (
        <div className="space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
            <div className="overflow-x-auto w-full table-responsive-container">
              <table className="w-full text-left text-xs text-slate-300 min-w-[620px]">
                <thead className="bg-slate-950 text-slate-400 font-semibold border-b border-slate-800">
                  <tr>
                    <th className="py-3 px-4">Deployment ID</th>
                    <th className="py-3 px-4">Commit / Note</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4">Size & Files</th>
                    <th className="py-3 px-4">Deployed</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono">
                  {deployments.map((d) => (
                    <tr key={d.id} className="hover:bg-slate-800/30">
                      <td className="py-3 px-4 font-bold text-white flex items-center gap-2">
                        <span>{d.id.slice(0, 14)}...</span>
                        {d.isCurrent && (
                          <span className="bg-emerald-950 text-emerald-400 border border-emerald-800/60 text-[9px] uppercase px-1.5 py-0.5 rounded font-sans">
                            Production Live
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-4 font-sans text-slate-300 truncate max-w-xs">{d.commit_message || 'Deploy'}</td>
                      <td className="py-3 px-4">
                        <span className={`text-[10px] uppercase font-bold px-1.5 py-0.5 rounded ${
                          d.status === 'live' ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-800/60' : 'bg-rose-950 text-rose-400'
                        }`}>
                          {d.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-slate-400 font-sans">
                        {(d.total_size_bytes / 1024).toFixed(1)} KB ({d.file_count} files)
                      </td>
                      <td className="py-3 px-4 text-slate-500 font-sans">{new Date(d.created_at).toLocaleString()}</td>
                      <td className="py-3 px-4 text-right font-sans space-x-2 whitespace-nowrap">
                        <button
                          onClick={() => setInspectedDeployment(d)}
                          className="text-cyan-400 hover:text-cyan-300 font-medium"
                        >
                          Logs
                        </button>
                        {!d.isCurrent && d.status === 'live' && (
                          <button
                            onClick={() => handleRollback(d.id)}
                            className="text-amber-400 hover:text-amber-300 font-medium"
                          >
                            Rollback
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: Custom Domains */}
      {activeTab === 'domains' && (
        <div className="space-y-8">
          {/* Add Domain Form */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
            <h2 className="text-base font-bold text-white">Connect Custom Domain</h2>
            <p className="text-xs text-slate-400">
              Attach a custom domain name (e.g., <code className="text-cyan-300 font-mono">mycompany.com</code> or <code className="text-cyan-300 font-mono">app.mycompany.com</code>) to route through our Anycast edge network.
            </p>

            {domainError && (
              <div className="p-3 bg-rose-950/50 border border-rose-800/60 rounded-lg text-rose-300 text-xs">
                {domainError}
              </div>
            )}

            <form onSubmit={handleAddDomain} className="flex flex-col sm:flex-row gap-3">
              <input
                type="text"
                required
                value={newDomain}
                onChange={(e) => setNewDomain(e.target.value)}
                placeholder="example.com or sub.example.com"
                className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-3.5 py-2 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-cyan-500 font-mono"
              />
              <button
                type="submit"
                disabled={addingDomain}
                className="px-5 py-2 bg-cyan-400 hover:bg-cyan-300 disabled:opacity-50 text-slate-950 font-semibold text-xs rounded-lg shadow-sm transition-colors whitespace-nowrap"
              >
                {addingDomain ? 'Connecting...' : 'Add Domain'}
              </button>
            </form>
          </div>

          {/* Domains Table & DNS Instructions */}
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-white">Configured Domains</h3>
            {domains.length === 0 ? (
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 text-center text-xs text-slate-500">
                No custom domains connected yet.
              </div>
            ) : (
              domains.map((dom) => (
                <div key={dom.id} className="bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800/80 pb-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white text-base font-mono">{dom.domain}</span>
                        <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                          dom.is_verified ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/60' : 'bg-amber-950 text-amber-400'
                        }`}>
                          {dom.is_verified ? 'Verified & Active' : 'Pending Verification'}
                        </span>
                        <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded font-mono">
                          SSL: {dom.ssl_status}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleVerifyDomain(dom.id)}
                        className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-cyan-400 font-medium text-xs rounded-lg transition-colors flex items-center gap-1.5"
                      >
                        <RefreshCw className="w-3.5 h-3.5" />
                        Verify DNS Records
                      </button>
                      <button
                        onClick={() => handleDeleteDomain(dom.id)}
                        className="p-1.5 text-slate-500 hover:text-rose-400 rounded-lg hover:bg-slate-800"
                        title="Remove domain"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* DNS Record Setup Details */}
                  <div className="space-y-2">
                    <div className="text-xs font-semibold text-slate-400">Required DNS Configuration</div>
                    <div className="bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs font-mono space-y-2 text-slate-300">
                      <div className="flex items-center justify-between">
                        <div>
                          <span className="text-cyan-400 font-bold mr-2">CNAME:</span>
                          <span className="text-slate-400">{dom.domain.startsWith('www.') ? 'www' : '@'} &rarr;</span>
                          <span className="text-white ml-2">strataflux.app</span>
                        </div>
                        <span className="text-[10px] text-slate-500 font-sans">Routing</span>
                      </div>
                      <div className="flex items-center justify-between pt-1 border-t border-slate-900">
                        <div>
                          <span className="text-amber-400 font-bold mr-2">TXT:</span>
                          <span className="text-slate-400">_strataflux.{dom.domain.replace(/^www\./, '')} &rarr;</span>
                          <span className="text-white ml-2">strataflux-verification={dom.verification_token}</span>
                        </div>
                        <span className="text-[10px] text-slate-500 font-sans">Ownership</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* TAB 4: Website Analytics */}
      {activeTab === 'analytics' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-1">
              <span className="text-xs text-slate-400 font-semibold uppercase">Total Views</span>
              <div className="text-2xl font-bold text-white font-mono">{analytics?.summary?.totalViews || 0}</div>
            </div>
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-1">
              <span className="text-xs text-slate-400 font-semibold uppercase">Unique Visitors</span>
              <div className="text-2xl font-bold text-cyan-400 font-mono">{analytics?.summary?.uniqueVisitors || 0}</div>
            </div>
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-1">
              <span className="text-xs text-slate-400 font-semibold uppercase">Bandwidth</span>
              <div className="text-2xl font-bold text-white font-mono">
                {analytics?.summary?.totalBandwidthBytes
                  ? (analytics.summary.totalBandwidthBytes / 1024 / 1024).toFixed(2) + ' MB'
                  : '0 MB'}
              </div>
            </div>
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-1">
              <span className="text-xs text-slate-400 font-semibold uppercase">Avg Transfer</span>
              <div className="text-2xl font-bold text-white font-mono">
                {analytics?.summary?.avgBandwidthPerView
                  ? (analytics.summary.avgBandwidthPerView / 1024).toFixed(1) + ' KB'
                  : '0 KB'}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Top Countries */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
              <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">Top Countries</h3>
              {analytics?.countries?.length === 0 ? (
                <div className="text-xs text-slate-500 py-6 text-center">No visitor geographic data recorded yet.</div>
              ) : (
                <div className="space-y-2 text-xs">
                  {analytics?.countries?.map((c: any) => (
                    <div key={c.code} className="flex items-center justify-between text-slate-300">
                      <span>{c.name} ({c.code})</span>
                      <span className="font-mono text-cyan-400 font-bold">{c.count} views</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Popular Pages */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
              <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">Popular Paths</h3>
              {analytics?.popularPages?.length === 0 ? (
                <div className="text-xs text-slate-500 py-6 text-center">No page hit data recorded yet.</div>
              ) : (
                <div className="space-y-2 text-xs font-mono">
                  {analytics?.popularPages?.map((p: any) => (
                    <div key={p.path} className="flex items-center justify-between text-slate-300">
                      <span className="truncate max-w-[200px]">{p.path}</span>
                      <span className="text-cyan-400 font-bold">{p.count} hits</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: Project Settings */}
      {activeTab === 'settings' && (
        <div className="space-y-8 max-w-2xl">
          <form onSubmit={handleSaveSettings} className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
            <h2 className="text-base font-bold text-white">General Project Settings</h2>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Project Name</label>
              <input
                type="text"
                required
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Framework Preset</label>
              <select
                value={editFramework}
                onChange={(e) => setEditFramework(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
              >
                <option value="static">Static HTML / CSS / JS</option>
                <option value="react">React / Vite</option>
                <option value="next">Next.js (Static Export)</option>
                <option value="astro">Astro</option>
                <option value="vue">Vue.js / Nuxt Static</option>
              </select>
            </div>

            <button
              type="submit"
              className="px-4 py-2 bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-semibold text-xs rounded-lg transition-colors"
            >
              Save Changes
            </button>
          </form>

          {/* Danger Zone */}
          <div className="bg-rose-950/20 border border-rose-900/60 rounded-2xl p-6 space-y-3">
            <h3 className="text-sm font-bold text-rose-400">Danger Zone</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Deleting this project will permanently erase all historical deployments, purge isolated file sandboxes, and disconnect custom domains. This action cannot be undone.
            </p>
            <button
              onClick={handleDeleteProject}
              className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white font-semibold text-xs rounded-lg transition-colors flex items-center gap-1.5"
            >
              <Trash2 className="w-3.5 h-3.5" />
              Delete Project
            </button>
          </div>
        </div>
      )}

      {/* Build Logs Inspector Modal */}
      {inspectedDeployment && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="font-bold text-white text-sm">Deployment Build Logs</h3>
                <div className="text-[11px] text-slate-400 font-mono">{inspectedDeployment.id}</div>
              </div>
              <button
                onClick={() => setInspectedDeployment(null)}
                className="text-slate-400 hover:text-white text-xs font-semibold"
              >
                Close
              </button>
            </div>

            <pre className="bg-slate-950 p-4 rounded-xl font-mono text-xs text-slate-300 max-h-96 overflow-y-auto whitespace-pre-wrap border border-slate-800">
              {inspectedDeployment.build_logs || 'No build logs recorded for this deployment.'}
            </pre>
          </div>
        </div>
      )}
    </div>
  );
};
