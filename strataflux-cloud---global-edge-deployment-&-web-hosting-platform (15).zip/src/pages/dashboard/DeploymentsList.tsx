import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Deployment, Project } from '../../types';
import { Rocket, ExternalLink, RefreshCw, Search } from 'lucide-react';

interface DeploymentsListProps {
  onNavigate: (path: string) => void;
}

export const DeploymentsList: React.FC<DeploymentsListProps> = ({ onNavigate }) => {
  const { token } = useAuth();
  const [deployments, setDeployments] = useState<Deployment[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [inspectedLog, setInspectedLog] = useState<Deployment | null>(null);

  const fetchDeployments = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/projects', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        const all: Deployment[] = [];
        data.projects?.forEach((p: Project) => {
          if (p.currentDeployment) {
            all.push({
              ...p.currentDeployment,
              projectName: p.name,
              projectSubdomain: p.subdomain
            });
          }
        });
        setDeployments(all);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDeployments();
  }, []);

  const filtered = deployments.filter(d =>
    (d.projectName || '').toLowerCase().includes(search.toLowerCase()) ||
    (d.commit_message || '').toLowerCase().includes(search.toLowerCase()) ||
    d.id.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">Deployments</h1>
          <p className="text-xs text-slate-400 mt-1">
            Global deployment releases, audit records, and raw build outputs.
          </p>
        </div>
        <button
          onClick={fetchDeployments}
          className="p-2 text-slate-400 hover:text-white bg-slate-900 border border-slate-800 rounded-lg self-start sm:self-auto"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      <div className="relative max-w-md">
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Filter by project, commit message, or deployment ID..."
          className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
        />
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
        {loading ? (
          <div className="text-center py-12 text-xs text-slate-500">Loading deployments...</div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-12 text-xs text-slate-500">No matching deployments found.</div>
        ) : (
          <div className="overflow-x-auto w-full table-responsive-container">
            <table className="w-full text-left text-xs text-slate-300 min-w-[620px]">
              <thead className="bg-slate-950 text-slate-400 font-semibold border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4">Deployment</th>
                  <th className="py-3 px-4">Project</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Size</th>
                  <th className="py-3 px-4">Deployed At</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono">
                {filtered.map((d) => (
                  <tr key={d.id} className="hover:bg-slate-800/30">
                    <td className="py-3 px-4">
                      <div className="font-bold text-white">{d.id.slice(0, 14)}...</div>
                      <div className="text-[11px] text-slate-400 font-sans truncate max-w-xs">{d.commit_message || 'Manual ZIP'}</div>
                    </td>
                    <td className="py-3 px-4 font-sans font-medium text-white">{d.projectName}</td>
                    <td className="py-3 px-4">
                      <span className="text-emerald-400 uppercase font-bold text-[10px] bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800/60">
                        {d.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-400 font-sans">{(d.total_size_bytes / 1024).toFixed(1)} KB</td>
                    <td className="py-3 px-4 text-slate-500 font-sans">{new Date(d.created_at).toLocaleString()}</td>
                    <td className="py-3 px-4 text-right font-sans space-x-2 whitespace-nowrap">
                      <button
                        onClick={() => setInspectedLog(d)}
                        className="text-cyan-400 hover:text-cyan-300 font-medium"
                      >
                        Logs
                      </button>
                      <button
                        onClick={() => onNavigate(`/dashboard/projects/${d.project_id}`)}
                        className="text-slate-400 hover:text-white font-medium"
                      >
                        Project
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {inspectedLog && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="font-bold text-white text-sm">Deployment Build Output</h3>
                <div className="text-[11px] text-slate-400 font-mono">{inspectedLog.id}</div>
              </div>
              <button onClick={() => setInspectedLog(null)} className="text-slate-400 hover:text-white text-xs font-semibold">
                Close
              </button>
            </div>
            <pre className="bg-slate-950 p-4 rounded-xl font-mono text-xs text-slate-300 max-h-96 overflow-y-auto whitespace-pre-wrap border border-slate-800">
              {inspectedLog.build_logs || 'No log details available.'}
            </pre>
          </div>
        </div>
      )}
    </div>
  );
};
