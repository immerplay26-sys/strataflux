import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Project } from '../../types';
import { Plus, Search, FolderGit2, ExternalLink, HardDrive, Rocket, Globe } from 'lucide-react';

interface ProjectsListProps {
  onNavigate: (path: string) => void;
  onOpenNewProject: () => void;
}

export const ProjectsList: React.FC<ProjectsListProps> = ({ onNavigate, onOpenNewProject }) => {
  const { token } = useAuth();
  const [projects, setProjects] = useState<Project[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  const fetchProjects = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/projects', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setProjects(data.projects || []);
      }
    } catch (e) {
      console.error('Failed fetching projects', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProjects();
  }, []);

  const filtered = projects.filter(p =>
    p.name.toLowerCase().includes(search.toLowerCase()) ||
    p.subdomain.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">Your Projects</h1>
          <p className="text-xs text-slate-400 mt-1">
            Manage your deployed static applications, domains, and revision pipelines.
          </p>
        </div>
        <button
          onClick={onOpenNewProject}
          className="px-4 py-2 bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-semibold text-xs rounded-lg shadow-md transition-colors flex items-center gap-1.5 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          Create New Project
        </button>
      </div>

      {/* Search Input */}
      <div className="relative max-w-md">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-500">
          <Search className="w-4 h-4" />
        </div>
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Filter projects by name or subdomain..."
          className="w-full bg-slate-900 border border-slate-800 rounded-lg pl-9 pr-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
        />
      </div>

      {/* Projects Grid */}
      {loading ? (
        <div className="text-center py-16 text-slate-500 text-xs">
          Loading your deployment projects...
        </div>
      ) : filtered.length === 0 ? (
        <div className="border border-dashed border-slate-800 rounded-2xl p-12 text-center space-y-4 bg-slate-900/40">
          <FolderGit2 className="w-10 h-10 text-slate-600 mx-auto" />
          <div className="space-y-1">
            <h3 className="text-sm font-semibold text-white">No projects found</h3>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              {search ? 'Try adjusting your search filter.' : 'Deploy your first website by creating a new project.'}
            </p>
          </div>
          {!search && (
            <button
              onClick={onOpenNewProject}
              className="px-4 py-2 bg-cyan-400 text-slate-950 font-semibold text-xs rounded-lg hover:bg-cyan-300 transition-colors"
            >
              Create Project
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((p) => (
            <div
              key={p.id}
              onClick={() => onNavigate(`/dashboard/projects/${p.id}`)}
              className="bg-slate-900 border border-slate-800 hover:border-cyan-500/50 rounded-xl p-5 space-y-4 cursor-pointer transition-all hover:bg-slate-900/90 group flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h3 className="font-bold text-white group-hover:text-cyan-400 transition-colors text-base">
                      {p.name}
                    </h3>
                    <div className="text-xs text-slate-400 font-mono mt-0.5">{p.subdomain}.strataflux.app</div>
                  </div>
                  <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                    p.status === 'ready'
                      ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/60'
                      : p.status === 'deploying'
                      ? 'bg-cyan-950 text-cyan-400 border border-cyan-800/60 animate-pulse'
                      : 'bg-rose-950 text-rose-400'
                  }`}>
                    {p.status}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[11px] font-mono text-slate-300 pt-1">
                  <div className="bg-slate-950 p-2 rounded border border-slate-800/60">
                    <span className="text-slate-500 block text-[10px]">Framework</span>
                    <span className="text-cyan-300 uppercase">{p.framework || 'STATIC'}</span>
                  </div>
                  <div className="bg-slate-950 p-2 rounded border border-slate-800/60">
                    <span className="text-slate-500 block text-[10px]">Deployments</span>
                    <span className="text-white">{p.total_deployments} runs</span>
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
                <span className="flex items-center gap-1.5">
                  <HardDrive className="w-3.5 h-3.5 text-slate-500" />
                  {(p.storage_used_bytes / 1024).toFixed(0)} KB
                </span>
                <a
                  href={p.liveUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={(e) => e.stopPropagation()}
                  className="text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-medium"
                >
                  <span>Open Live Site</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
