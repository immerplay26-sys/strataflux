import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Project, Deployment } from '../../types';
import {
  FolderGit2,
  Rocket,
  CheckCircle2,
  XCircle,
  Users,
  HardDrive,
  Activity,
  Plus,
  ArrowUpRight,
  UploadCloud,
  RefreshCw,
  ExternalLink
} from 'lucide-react';

interface OverviewProps {
  onNavigate: (path: string) => void;
  onOpenNewProject: () => void;
}

export const DashboardOverview: React.FC<OverviewProps> = ({ onNavigate, onOpenNewProject }) => {
  const { user, token } = useAuth();
  const [projects, setProjects] = useState<Project[]>([]);
  const [deployments, setDeployments] = useState<Deployment[]>([]);
  const [analyticsSummary, setAnalyticsSummary] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const loadData = async () => {
    setLoading(true);
    try {
      const [projRes, analyticsRes] = await Promise.all([
        fetch('/api/projects', { headers: { Authorization: `Bearer ${token}` } }),
        fetch('/api/analytics/overview', { headers: { Authorization: `Bearer ${token}` } })
      ]);

      if (projRes.ok) {
        const pData = await projRes.json();
        setProjects(pData.projects || []);

        // Flatten deployments from projects
        const allDeps: Deployment[] = [];
        pData.projects?.forEach((p: Project) => {
          if (p.currentDeployment) {
            allDeps.push({
              ...p.currentDeployment,
              projectName: p.name,
              projectSubdomain: p.subdomain
            });
          }
        });
        setDeployments(allDeps);
      }

      if (analyticsRes.ok) {
        const aData = await analyticsRes.json();
        setAnalyticsSummary(aData.summary);
      }
    } catch (e) {
      console.error('Failed loading dashboard overview', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const totalProjects = projects.length;
  const totalDeployments = projects.reduce((acc, p) => acc + (p.total_deployments || 0), 0);
  const totalStorageBytes = projects.reduce((acc, p) => acc + (p.storage_used_bytes || 0), 0);
  const totalBandwidthBytes = projects.reduce((acc, p) => acc + (p.bandwidth_used_bytes || 0), 0);
  const successfulDeployments = projects.filter(p => p.status === 'ready' && p.current_deployment_id).length;
  const failedDeployments = projects.filter(p => p.status === 'failed').length;

  return (
    <div className="space-y-8">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">System Overview</h1>
          <p className="text-xs text-slate-400 mt-1">
            Global static deployment metrics and active infrastructure for <strong className="text-white">{user?.name}</strong>.
          </p>
        </div>
        <div className="flex items-center gap-2.5">
          <button
            onClick={loadData}
            title="Refresh statistics"
            className="p-2 text-slate-400 hover:text-white bg-slate-900 border border-slate-800 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
          <button
            onClick={onOpenNewProject}
            className="px-4 py-2 bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-semibold text-xs rounded-lg shadow-md transition-colors flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            Create Project
          </button>
        </div>
      </div>

      {/* 7 Required Metrics Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-7 gap-3">
        {/* Projects */}
        <div className="bg-slate-900/90 border border-slate-800/80 rounded-xl p-4 space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Projects</span>
            <FolderGit2 className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-xl font-bold text-white font-mono">{totalProjects}</div>
          <div className="text-[10px] text-slate-500">Active sites</div>
        </div>

        {/* Deployments */}
        <div className="bg-slate-900/90 border border-slate-800/80 rounded-xl p-4 space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Deployments</span>
            <Rocket className="w-4 h-4 text-sky-400" />
          </div>
          <div className="text-xl font-bold text-white font-mono">{totalDeployments}</div>
          <div className="text-[10px] text-slate-500">Lifetime runs</div>
        </div>

        {/* Successful */}
        <div className="bg-slate-900/90 border border-slate-800/80 rounded-xl p-4 space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Successful</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-xl font-bold text-emerald-400 font-mono">{successfulDeployments}</div>
          <div className="text-[10px] text-slate-500">Active live</div>
        </div>

        {/* Failed */}
        <div className="bg-slate-900/90 border border-slate-800/80 rounded-xl p-4 space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Failed</span>
            <XCircle className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-xl font-bold text-rose-400 font-mono">{failedDeployments}</div>
          <div className="text-[10px] text-slate-500">Build issues</div>
        </div>

        {/* Visitors */}
        <div className="bg-slate-900/90 border border-slate-800/80 rounded-xl p-4 space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Visitors</span>
            <Users className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="text-xl font-bold text-white font-mono">{analyticsSummary?.uniqueVisitors || 0}</div>
          <div className="text-[10px] text-slate-500">30d unique hits</div>
        </div>

        {/* Storage */}
        <div className="bg-slate-900/90 border border-slate-800/80 rounded-xl p-4 space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Storage</span>
            <HardDrive className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-xl font-bold text-white font-mono">
            {totalStorageBytes > 1024 * 1024 * 1024
              ? `${(totalStorageBytes / (1024 * 1024 * 1024)).toFixed(1)} GB`
              : `${(totalStorageBytes / (1024 * 1024)).toFixed(1)} MB`}
          </div>
          <div className="text-[10px] text-slate-500">Object sandbox</div>
        </div>

        {/* Bandwidth */}
        <div className="bg-slate-900/90 border border-slate-800/80 rounded-xl p-4 space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Bandwidth</span>
            <Activity className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-xl font-bold text-white font-mono">
            {totalBandwidthBytes > 1024 * 1024 * 1024
              ? `${(totalBandwidthBytes / (1024 * 1024 * 1024)).toFixed(1)} GB`
              : `${(totalBandwidthBytes / (1024 * 1024)).toFixed(1)} MB`}
          </div>
          <div className="text-[10px] text-slate-500">Edge transferred</div>
        </div>
      </div>

      {/* Projects List & Quick Launch */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-white">Your Projects</h2>
          <button
            onClick={() => onNavigate('/dashboard/projects')}
            className="text-xs text-cyan-400 hover:underline flex items-center gap-1"
          >
            <span>View all projects</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {projects.length === 0 ? (
          <div className="border border-dashed border-slate-800 rounded-2xl p-12 text-center space-y-4 bg-slate-900/40">
            <div className="w-12 h-12 rounded-full bg-cyan-950/60 text-cyan-400 flex items-center justify-center mx-auto">
              <UploadCloud className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <h3 className="text-base font-semibold text-white">No projects created yet</h3>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                Create your first project and upload a ZIP archive of your website to publish it globally in seconds.
              </p>
            </div>
            <button
              onClick={onOpenNewProject}
              className="px-4 py-2 bg-cyan-400 text-slate-950 font-semibold text-xs rounded-lg hover:bg-cyan-300 transition-colors"
            >
              Create First Project
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {projects.slice(0, 6).map((p) => (
              <div
                key={p.id}
                onClick={() => onNavigate(`/dashboard/projects/${p.id}`)}
                className="bg-slate-900 border border-slate-800 hover:border-cyan-500/50 rounded-xl p-5 space-y-4 cursor-pointer transition-all hover:bg-slate-900/90 group"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h3 className="font-semibold text-white group-hover:text-cyan-400 transition-colors">
                      {p.name}
                    </h3>
                    <div className="text-xs text-slate-400 font-mono mt-0.5">{p.subdomain}.strataflux.app</div>
                  </div>
                  <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                    p.status === 'ready' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/60' : 'bg-amber-950 text-amber-400'
                  }`}>
                    {p.status}
                  </span>
                </div>

                <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
                  <span>{(p.storage_used_bytes / 1024).toFixed(0)} KB &middot; {p.total_deployments} deploys</span>
                  <a
                    href={p.liveUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={(e) => e.stopPropagation()}
                    className="text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-medium"
                  >
                    <span>Open Live</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Recent Deployments Table */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-white">Recent Deployment Activity</h2>
          <button
            onClick={() => onNavigate('/dashboard/deployments')}
            className="text-xs text-cyan-400 hover:underline flex items-center gap-1"
          >
            <span>View all deployments</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
          {deployments.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-500">
              No deployments recorded yet.
            </div>
          ) : (
            <div className="overflow-x-auto w-full table-responsive-container">
              <table className="w-full text-left text-xs text-slate-300 min-w-[580px]">
                <thead className="bg-slate-950 text-slate-400 font-semibold border-b border-slate-800">
                  <tr>
                    <th className="py-3 px-4">Project</th>
                    <th className="py-3 px-4">Deployment Note / Commit</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4">Size</th>
                    <th className="py-3 px-4">Created</th>
                    <th className="py-3 px-4 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {deployments.slice(0, 5).map((d) => (
                    <tr key={d.id} className="hover:bg-slate-800/30">
                      <td className="py-3 px-4 font-medium text-white">{d.projectName || 'Project'}</td>
                      <td className="py-3 px-4 text-slate-400 font-mono truncate max-w-xs">{d.commit_message || 'ZIP deployment'}</td>
                      <td className="py-3 px-4">
                        <span className="text-emerald-400 font-semibold font-mono uppercase text-[10px] bg-emerald-950/60 px-1.5 py-0.5 rounded border border-emerald-800/40">
                          {d.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-mono text-slate-400">{(d.total_size_bytes / 1024).toFixed(1)} KB</td>
                      <td className="py-3 px-4 text-slate-500 whitespace-nowrap">{new Date(d.created_at).toLocaleDateString()}</td>
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <button
                          onClick={() => onNavigate(`/dashboard/projects/${d.project_id}`)}
                          className="text-cyan-400 hover:text-cyan-300 font-medium"
                        >
                          Inspect
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
