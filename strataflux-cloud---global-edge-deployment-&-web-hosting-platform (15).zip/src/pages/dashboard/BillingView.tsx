import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../../context/AuthContext';
import {
  CreditCard,
  Check,
  Zap,
  AlertCircle,
  X,
  Send,
  Smartphone,
  Wallet,
  Upload,
  CheckCircle2,
  Clock,
  XCircle,
  ExternalLink,
  Receipt,
  FileText
} from 'lucide-react';
import { Plan, PaymentMethod, Payment } from '../../types';

interface BillingViewProps {
  onNavigate: (path: string) => void;
}

export const BillingView: React.FC<BillingViewProps> = ({ onNavigate }) => {
  const { user, token, refreshUser } = useAuth();
  const [subscription, setSubscription] = useState<any>(null);
  const [plans, setPlans] = useState<Plan[]>([]);
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([]);
  const [paymentsHistory, setPaymentsHistory] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(true);

  // Checkout Modal State
  const [checkoutModalOpen, setCheckoutModalOpen] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<Plan | null>(null);
  const [billingInterval, setBillingInterval] = useState<'monthly' | 'yearly'>('monthly');
  const [selectedProvider, setSelectedProvider] = useState<string>('stripe');

  // Manual payment form fields
  const [transactionId, setTransactionId] = useState('');
  const [paidAmount, setPaidAmount] = useState<string>('');
  const [paidCurrency, setPaidCurrency] = useState('USD');
  const [customerNote, setCustomerNote] = useState('');
  const [screenshotFile, setScreenshotFile] = useState<File | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [subRes, plansRes, methodsRes, historyRes] = await Promise.all([
        fetch('/api/billing/subscription', { headers: { Authorization: `Bearer ${token}` } }),
        fetch('/api/billing/plans'),
        fetch('/api/billing/methods'),
        fetch('/api/billing/payments', { headers: { Authorization: `Bearer ${token}` } })
      ]);

      if (subRes.ok) {
        setSubscription(await subRes.json());
      }
      if (plansRes.ok) {
        const d = await plansRes.json();
        const loadedPlans: Plan[] = d.plans || [];
        setPlans(loadedPlans);

        // Auto open checkout if specified in URL query params (e.g. from Pricing page)
        const urlParams = new URLSearchParams(window.location.search);
        const planParam = urlParams.get('plan');
        const intervalParam = urlParams.get('interval') === 'yearly' ? 'yearly' : 'monthly';
        if (planParam) {
          const matchedPlan = loadedPlans.find((p) => p.id === planParam);
          if (matchedPlan && matchedPlan.price_monthly > 0) {
            setSelectedPlan(matchedPlan);
            setBillingInterval(intervalParam);
            const amt = intervalParam === 'yearly' ? matchedPlan.price_yearly : matchedPlan.price_monthly;
            setPaidAmount(amt.toString());
            setCheckoutModalOpen(true);
          }
        }
      }
      if (methodsRes.ok) {
        const d = await methodsRes.json();
        const enabledMethods = (d.methods || []).filter((m: PaymentMethod) => m.enabled);
        setPaymentMethods(enabledMethods);
        if (enabledMethods.length > 0 && !selectedProvider) {
          setSelectedProvider(enabledMethods[0].id);
        }
      }
      if (historyRes.ok) {
        const d = await historyRes.json();
        setPaymentsHistory(d.payments || []);
      }
    } catch (e) {
      console.error('Error loading billing info', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const openCheckout = (plan: Plan) => {
    setSelectedPlan(plan);
    const amount = billingInterval === 'yearly' ? plan.price_yearly : plan.price_monthly;
    setPaidAmount(amount.toString());
    setPaidCurrency('USD');
    setTransactionId('');
    setCustomerNote('');
    setScreenshotFile(null);
    setErrorMsg(null);
    setSuccessMsg(null);

    // Pick first enabled method
    const enabled = paymentMethods.filter(m => m.enabled);
    if (enabled.length > 0) {
      setSelectedProvider(enabled[0].id);
    }
    setCheckoutModalOpen(true);
  };

  const handleIntervalChange = (interval: 'monthly' | 'yearly') => {
    setBillingInterval(interval);
    if (selectedPlan) {
      const amount = interval === 'yearly' ? selectedPlan.price_yearly : selectedPlan.price_monthly;
      setPaidAmount(amount.toString());
    }
  };

  const handleProviderSelect = (providerId: string) => {
    setSelectedProvider(providerId);
    setErrorMsg(null);
    if (providerId === 'jazzcash' || providerId === 'easypaisa') {
      setPaidCurrency('PKR');
      if (selectedPlan) {
        const usdPrice = billingInterval === 'yearly' ? selectedPlan.price_yearly : selectedPlan.price_monthly;
        // Approx 280 PKR per USD calculation guide
        setPaidAmount((usdPrice * 280).toString());
      }
    } else {
      setPaidCurrency('USD');
      if (selectedPlan) {
        const usdPrice = billingInterval === 'yearly' ? selectedPlan.price_yearly : selectedPlan.price_monthly;
        setPaidAmount(usdPrice.toString());
      }
    }
  };

  const handleScreenshotChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setScreenshotFile(e.target.files[0]);
    }
  };

  const handleSubmitPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPlan) return;
    setErrorMsg(null);
    setSuccessMsg(null);

    const activeMethod = paymentMethods.find(m => m.id === selectedProvider);

    // Automated Gateway Flow (Stripe or PayPal)
    if (activeMethod?.type === 'gateway') {
      setSubmitting(true);
      try {
        const res = await fetch('/api/billing/create-checkout', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`
          },
          body: JSON.stringify({
            planId: selectedPlan.id,
            interval: billingInterval,
            provider: selectedProvider
          })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Checkout initiation failed');

        if (data.checkoutUrl) {
          window.location.href = data.checkoutUrl;
        } else if (data.approvalUrl) {
          window.location.href = data.approvalUrl;
        } else {
          setSuccessMsg(data.message || 'Payment flow initiated.');
        }
      } catch (err: any) {
        setErrorMsg(err.message || 'Payment initiation error.');
      } finally {
        setSubmitting(false);
      }
      return;
    }

    // Manual Payment Submission Flow (Payoneer, JazzCash, Easypaisa)
    if (!transactionId.trim()) {
      setErrorMsg('Transaction / Reference ID is required to verify your payment.');
      return;
    }

    setSubmitting(true);
    try {
      const formData = new FormData();
      formData.append('planId', selectedPlan.id);
      formData.append('interval', billingInterval);
      formData.append('provider', selectedProvider);
      formData.append('transactionId', transactionId.trim());
      formData.append('amount', paidAmount || '0');
      formData.append('currency', paidCurrency);
      if (customerNote) formData.append('customerNote', customerNote.trim());
      if (screenshotFile) formData.append('screenshot', screenshotFile);

      const res = await fetch('/api/billing/manual-payment', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`
        },
        body: formData
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed submitting payment');

      setSuccessMsg(`Payment submitted! Reference #${transactionId} is currently PENDING administrative verification. Your plan will be activated upon approval.`);
      await fetchData();
    } catch (err: any) {
      setErrorMsg(err.message || 'Error submitting payment reference.');
    } finally {
      setSubmitting(false);
    }
  };

  const usage = subscription?.usage;
  const activeMethod = paymentMethods.find(m => m.id === selectedProvider);

  const getProviderIcon = (iconName: string) => {
    switch (iconName) {
      case 'CreditCard': return <CreditCard className="w-5 h-5 text-sky-400" />;
      case 'Wallet': return <Wallet className="w-5 h-5 text-indigo-400" />;
      case 'Send': return <Send className="w-5 h-5 text-amber-400" />;
      case 'Smartphone': return <Smartphone className="w-5 h-5 text-emerald-400" />;
      default: return <CreditCard className="w-5 h-5 text-slate-400" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'approved':
      case 'completed':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-950/80 text-emerald-400 border border-emerald-800">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Approved
          </span>
        );
      case 'pending':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-950/80 text-amber-400 border border-amber-800 animate-pulse">
            <Clock className="w-3.5 h-3.5" />
            Pending Verification
          </span>
        );
      case 'rejected':
      case 'failed':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-950/80 text-rose-400 border border-rose-800">
            <XCircle className="w-3.5 h-3.5" />
            Rejected
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-800 text-slate-300">
            {status}
          </span>
        );
    }
  };

  return (
    <div className="space-y-10 max-w-5xl">
      <div>
        <h1 className="text-2xl font-bold text-white tracking-tight">Billing & Subscriptions</h1>
        <p className="text-xs text-slate-400 mt-1">
          Manage resource allocations, active plan tier, payment methods, and transaction history.
        </p>
      </div>

      {/* Current Quota Consumption Meters */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div>
            <span className="text-xs text-slate-400 uppercase font-semibold">Current Active Plan</span>
            <div className="text-xl font-bold text-white flex items-center gap-2 mt-0.5">
              <span>{subscription?.plan?.name || user?.plan_tier?.toUpperCase()}</span>
              <span className="text-xs font-mono bg-cyan-950 text-cyan-300 border border-cyan-800 px-2 py-0.5 rounded uppercase">
                Active
              </span>
            </div>
          </div>
          <div className="text-xs text-slate-400">
            Need an enterprise custom contract?{' '}
            <button onClick={() => onNavigate('/contact-us')} className="text-cyan-400 underline hover:text-cyan-300">
              Contact Sales
            </button>
          </div>
        </div>

        {/* Meters */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-xs">
          {/* Projects Meter */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-slate-300">
              <span>Projects Quota</span>
              <span className="font-mono text-cyan-400">{usage?.projectsCount || 0} / {usage?.maxProjects || 3}</span>
            </div>
            <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
              <div
                className="h-full bg-cyan-400 transition-all"
                style={{ width: `${Math.min(100, ((usage?.projectsCount || 0) / (usage?.maxProjects || 3)) * 100)}%` }}
              ></div>
            </div>
          </div>

          {/* Domains Meter */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-slate-300">
              <span>Custom Domains Quota</span>
              <span className="font-mono text-cyan-400">{usage?.customDomainsCount || 0} / {usage?.maxCustomDomains || 1}</span>
            </div>
            <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
              <div
                className="h-full bg-cyan-400 transition-all"
                style={{ width: `${Math.min(100, ((usage?.customDomainsCount || 0) / (usage?.maxCustomDomains || 1)) * 100)}%` }}
              ></div>
            </div>
          </div>

          {/* Storage Meter */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-slate-300">
              <span>Isolated Object Storage</span>
              <span className="font-mono text-cyan-400">
                {((usage?.storageBytesUsed || 0) / 1024 / 1024).toFixed(1)} MB / {((usage?.storageLimitBytes || 524288000) / 1024 / 1024).toFixed(0)} MB
              </span>
            </div>
            <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
              <div
                className="h-full bg-cyan-400 transition-all"
                style={{ width: `${Math.min(100, ((usage?.storageBytesUsed || 0) / (usage?.storageLimitBytes || 1)) * 100)}%` }}
              ></div>
            </div>
          </div>

          {/* Bandwidth Meter */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-slate-300">
              <span>Anycast Edge Bandwidth</span>
              <span className="font-mono text-cyan-400">
                {((usage?.bandwidthBytesUsed || 0) / 1024 / 1024).toFixed(1)} MB / {((usage?.bandwidthLimitBytes || 10737418240) / 1024 / 1024 / 1024).toFixed(0)} GB
              </span>
            </div>
            <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
              <div
                className="h-full bg-cyan-400 transition-all"
                style={{ width: `${Math.min(100, ((usage?.bandwidthBytesUsed || 0) / (usage?.bandwidthLimitBytes || 1)) * 100)}%` }}
              ></div>
            </div>
          </div>
        </div>
      </div>

      {/* Available Tier Upgrades */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h2 className="text-lg font-bold text-white">Upgrade or Change Plan</h2>
            <p className="text-xs text-slate-400">Select any plan to choose your preferred payment method.</p>
          </div>
          <div className="text-xs text-slate-400 flex items-center gap-1.5 bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-lg">
            <span>Accepted Methods:</span>
            <span className="text-cyan-400 font-medium">Stripe &middot; PayPal &middot; Payoneer &middot; JazzCash &middot; Easypaisa</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {plans.map((p) => {
            const isCurrent = user?.plan_tier === p.id;
            return (
              <div
                key={p.id}
                className={`bg-slate-900 border rounded-2xl p-6 flex flex-col justify-between transition-all ${
                  isCurrent ? 'border-cyan-500 bg-cyan-950/10' : 'border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="space-y-4">
                  <div>
                    <h3 className="font-bold text-white text-lg">{p.name}</h3>
                    <div className="text-3xl font-extrabold text-white mt-2">
                      ${p.price_monthly}<span className="text-xs text-slate-400 font-normal">/mo</span>
                    </div>
                    {p.price_yearly > 0 && (
                      <p className="text-xs text-slate-400 font-mono mt-0.5">
                        or ${p.price_yearly}/yr (Save 20%)
                      </p>
                    )}
                  </div>

                  <ul className="space-y-2 text-xs text-slate-300 border-t border-slate-800 pt-4">
                    {p.features.map((f, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <Check className="w-3.5 h-3.5 text-cyan-400 mt-0.5 flex-shrink-0" />
                        <span>{f}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="pt-6">
                  <button
                    onClick={() => openCheckout(p)}
                    disabled={isCurrent}
                    className={`w-full py-2.5 px-4 rounded-xl text-xs font-semibold transition-colors flex items-center justify-center gap-2 ${
                      isCurrent
                        ? 'bg-slate-800 text-slate-400 cursor-default'
                        : 'bg-cyan-400 hover:bg-cyan-300 text-slate-950 shadow-md'
                    }`}
                  >
                    {isCurrent ? 'Current Active Tier' : `Select ${p.name}`}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Payment History & Transactions */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-white">Payment History & Transactions</h2>
            <p className="text-xs text-slate-400">Records of all manual submissions and automated subscription payments.</p>
          </div>
          <button
            onClick={fetchData}
            className="text-xs text-cyan-400 hover:underline"
          >
            Refresh History
          </button>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden text-xs">
          {paymentsHistory.length === 0 ? (
            <div className="py-12 text-center text-slate-500">
              No transactions recorded yet. When you upgrade a plan, payment receipts will appear here.
            </div>
          ) : (
            <div className="overflow-x-auto w-full table-responsive-container">
              <table className="w-full text-left text-slate-300 min-w-[620px]">
                <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                  <tr>
                    <th className="py-3 px-4">Date</th>
                    <th className="py-3 px-4">Plan</th>
                    <th className="py-3 px-4">Amount</th>
                    <th className="py-3 px-4">Method</th>
                    <th className="py-3 px-4">Transaction / Ref ID</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4">Receipt</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono">
                  {paymentsHistory.map((pm) => (
                    <tr key={pm.id}>
                      <td className="py-3 px-4 font-sans text-slate-400 whitespace-nowrap">
                        {new Date(pm.created_at).toLocaleDateString()}
                      </td>
                      <td className="py-3 px-4 font-sans text-white font-semibold whitespace-nowrap">{pm.plan_name}</td>
                      <td className="py-3 px-4 text-cyan-300 font-bold whitespace-nowrap">
                        {pm.currency} {pm.amount}
                      </td>
                      <td className="py-3 px-4 uppercase whitespace-nowrap">{pm.payment_method}</td>
                      <td className="py-3 px-4 text-slate-300 select-all">{pm.transaction_id}</td>
                      <td className="py-3 px-4 whitespace-nowrap">{getStatusBadge(pm.status)}</td>
                      <td className="py-3 px-4 font-sans whitespace-nowrap">
                        {pm.screenshot_path ? (
                          <a
                            href={pm.screenshot_path}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 text-cyan-400 hover:underline"
                          >
                            <Receipt className="w-3.5 h-3.5" />
                            View
                          </a>
                        ) : (
                          <span className="text-slate-600">-</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* CHECKOUT & PAYMENT MODAL */}
      {checkoutModalOpen && selectedPlan && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full p-6 sm:p-8 space-y-6 shadow-2xl relative my-8">
            <div className="flex items-start justify-between border-b border-slate-800 pb-4">
              <div>
                <span className="text-xs font-mono uppercase text-cyan-400">Secure Checkout</span>
                <h2 className="text-xl font-bold text-white mt-0.5">
                  Upgrade to {selectedPlan.name}
                </h2>
              </div>
              <button
                onClick={() => setCheckoutModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {errorMsg && (
              <div className="p-3 bg-rose-950/50 border border-rose-800/80 rounded-xl text-rose-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {successMsg && (
              <div className="p-4 bg-emerald-950/50 border border-emerald-800/80 rounded-xl text-emerald-300 text-xs space-y-2">
                <div className="flex items-center gap-2 font-bold text-sm">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  <span>Submission Received</span>
                </div>
                <p className="leading-relaxed">{successMsg}</p>
                <div className="pt-2">
                  <button
                    onClick={() => setCheckoutModalOpen(false)}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold"
                  >
                    Done
                  </button>
                </div>
              </div>
            )}

            {!successMsg && (
              <form onSubmit={handleSubmitPayment} className="space-y-6">
                {/* Billing Interval Selector */}
                <div className="space-y-2">
                  <label className="text-xs font-semibold text-slate-300 block">Choose Billing Frequency</label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => handleIntervalChange('monthly')}
                      className={`p-3 rounded-xl border text-left transition-all ${
                        billingInterval === 'monthly'
                          ? 'bg-cyan-950/40 border-cyan-500 text-white'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                      }`}
                    >
                      <div className="font-bold text-sm text-white">Monthly Billing</div>
                      <div className="text-xs text-cyan-400 font-mono mt-0.5">${selectedPlan.price_monthly} / month</div>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleIntervalChange('yearly')}
                      className={`p-3 rounded-xl border text-left transition-all ${
                        billingInterval === 'yearly'
                          ? 'bg-cyan-950/40 border-cyan-500 text-white'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                      }`}
                    >
                      <div className="font-bold text-sm text-white flex items-center justify-between">
                        <span>Annual Billing</span>
                        <span className="text-[10px] bg-emerald-950 text-emerald-400 px-1.5 py-0.5 rounded font-mono">Save 20%</span>
                      </div>
                      <div className="text-xs text-cyan-400 font-mono mt-0.5">${selectedPlan.price_yearly} / year</div>
                    </button>
                  </div>
                </div>

                {/* Choose Payment Method */}
                <div className="space-y-2">
                  <label className="text-xs font-semibold text-slate-300 block">
                    Choose Payment Method (Select One)
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {paymentMethods.map((m) => {
                      const isSelected = selectedProvider === m.id;
                      return (
                        <div
                          key={m.id}
                          onClick={() => handleProviderSelect(m.id)}
                          className={`p-3.5 rounded-xl border cursor-pointer transition-all flex items-start gap-3 ${
                            isSelected
                              ? 'bg-cyan-950/30 border-cyan-400 shadow-md'
                              : 'bg-slate-950 border-slate-800 hover:border-slate-700 text-slate-400'
                          }`}
                        >
                          <div className="mt-0.5">{getProviderIcon(m.icon)}</div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between">
                              <span className={`text-xs font-bold ${isSelected ? 'text-white' : 'text-slate-300'}`}>
                                {m.name}
                              </span>
                              {isSelected && <Check className="w-4 h-4 text-cyan-400" />}
                            </div>
                            <p className="text-[11px] text-slate-400 mt-0.5 leading-snug line-clamp-2">
                              {m.description}
                            </p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Method Specific Details & Input Area */}
                {activeMethod && (
                  <div className="bg-slate-950 border border-slate-800 rounded-xl p-5 space-y-4">
                    <div className="flex items-center gap-2 border-b border-slate-800/80 pb-3">
                      {getProviderIcon(activeMethod.icon)}
                      <span className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                        {activeMethod.name} Instructions
                      </span>
                    </div>

                    {/* GATEWAYS: Stripe / PayPal */}
                    {activeMethod.type === 'gateway' ? (
                      <div className="space-y-3 text-xs text-slate-300">
                        <p>
                          You will be transferred to {activeMethod.name} to complete payment for{' '}
                          <span className="font-bold text-white">
                            ${billingInterval === 'yearly' ? selectedPlan.price_yearly : selectedPlan.price_monthly} USD
                          </span>
                          .
                        </p>
                        <div className="text-[11px] text-slate-400 bg-slate-900 p-3 rounded-lg border border-slate-800">
                          {activeMethod.id === 'stripe' ? (
                            <span>Accepts all international credit/debit cards with PCI-DSS compliant checkout.</span>
                          ) : (
                            <span>PayPal account or card processing in sandbox/live gateway.</span>
                          )}
                        </div>
                      </div>
                    ) : (
                      /* MANUAL METHODS: Payoneer, JazzCash, Easypaisa */
                      <div className="space-y-4">
                        {/* Account credentials display */}
                        <div className="bg-slate-900 border border-slate-800 rounded-lg p-3.5 space-y-2 text-xs">
                          {activeMethod.accountName && (
                            <div className="flex justify-between">
                              <span className="text-slate-400">Account Title:</span>
                              <span className="font-bold text-white select-all">{activeMethod.accountName}</span>
                            </div>
                          )}
                          {activeMethod.accountEmail && (
                            <div className="flex justify-between">
                              <span className="text-slate-400">Payoneer Email:</span>
                              <span className="font-bold text-amber-400 select-all font-mono">{activeMethod.accountEmail}</span>
                            </div>
                          )}
                          {activeMethod.accountNumber && (
                            <div className="flex justify-between">
                              <span className="text-slate-400">Mobile Account Number:</span>
                              <span className="font-bold text-emerald-400 select-all font-mono">{activeMethod.accountNumber}</span>
                            </div>
                          )}
                          <div className="pt-1 text-[11px] text-slate-300 border-t border-slate-800/80 leading-relaxed">
                            {activeMethod.instructions}
                          </div>
                        </div>

                        {/* Submission Inputs */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                          <div>
                            <label className="block text-slate-300 mb-1 font-semibold">
                              Transaction / Reference ID <span className="text-rose-400">*</span>
                            </label>
                            <input
                              type="text"
                              required
                              value={transactionId}
                              onChange={(e) => setTransactionId(e.target.value)}
                              placeholder={activeMethod.id === 'payoneer' ? 'e.g. 192847120' : 'e.g. 8558129038'}
                              className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-white font-mono placeholder-slate-600 focus:outline-none focus:border-cyan-500"
                            />
                          </div>

                          <div>
                            <label className="block text-slate-300 mb-1 font-semibold">
                              Amount Paid ({paidCurrency}) <span className="text-rose-400">*</span>
                            </label>
                            <input
                              type="text"
                              required
                              value={paidAmount}
                              onChange={(e) => setPaidAmount(e.target.value)}
                              placeholder="Amount transferred"
                              className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-white font-mono placeholder-slate-600 focus:outline-none focus:border-cyan-500"
                            />
                          </div>
                        </div>

                        {/* Optional Receipt Screenshot */}
                        <div className="space-y-1 text-xs">
                          <label className="block text-slate-300 font-semibold">
                            Payment Screenshot / Receipt (Optional)
                          </label>
                          <div
                            onClick={() => fileInputRef.current?.click()}
                            className="border border-dashed border-slate-800 hover:border-slate-700 bg-slate-900/60 rounded-lg p-3 text-center cursor-pointer transition-all flex items-center justify-center gap-2"
                          >
                            <input
                              ref={fileInputRef}
                              type="file"
                              accept="image/png,image/jpeg,image/webp,application/pdf"
                              onChange={handleScreenshotChange}
                              className="hidden"
                            />
                            <Upload className="w-4 h-4 text-cyan-400" />
                            {screenshotFile ? (
                              <span className="text-white font-mono">{screenshotFile.name} ({(screenshotFile.size / 1024).toFixed(1)} KB)</span>
                            ) : (
                              <span className="text-slate-400">Click to upload transaction receipt (PNG, JPG, PDF)</span>
                            )}
                          </div>
                        </div>

                        {/* Optional Customer Note */}
                        <div className="text-xs">
                          <label className="block text-slate-300 mb-1 font-semibold">Additional Note (Optional)</label>
                          <input
                            type="text"
                            value={customerNote}
                            onChange={(e) => setCustomerNote(e.target.value)}
                            placeholder="e.g. Sent from sender account Muhammad..."
                            className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-white placeholder-slate-600 focus:outline-none focus:border-cyan-500"
                          />
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Modal Actions */}
                <div className="flex items-center justify-end gap-3 pt-2 border-t border-slate-800">
                  <button
                    type="button"
                    onClick={() => setCheckoutModalOpen(false)}
                    className="px-4 py-2 text-slate-400 hover:text-white text-xs font-semibold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={submitting}
                    className="px-5 py-2.5 bg-cyan-400 hover:bg-cyan-300 disabled:opacity-50 text-slate-950 font-bold text-xs rounded-xl shadow-md transition-colors flex items-center gap-2"
                  >
                    {submitting ? (
                      'Processing...'
                    ) : activeMethod?.type === 'gateway' ? (
                      'Proceed to Checkout'
                    ) : (
                      'Submit Payment for Verification'
                    )}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
