import React from 'react';
import { Logo } from '../components/Logo';
import { Home, ArrowLeft } from 'lucide-react';

interface NotFoundProps {
  onNavigate: (path: string) => void;
}

export const NotFound: React.FC<NotFoundProps> = ({ onNavigate }) => {
  return (
    <div className="min-h-[75vh] flex items-center justify-center px-4 py-16 text-center">
      <div className="max-w-md w-full space-y-6">
        <div className="flex justify-center">
          <Logo size="md" />
        </div>
        <div className="text-7xl font-extrabold text-cyan-400 font-mono">404</div>
        <h1 className="text-2xl font-bold text-white">Page Not Found</h1>
        <p className="text-sm text-slate-400">
          The requested edge route or platform resource does not exist on StrataFlux Cloud.
        </p>
        <div className="pt-4 flex items-center justify-center gap-3">
          <button
            onClick={() => onNavigate('/')}
            className="px-5 py-2.5 bg-cyan-400 hover:bg-cyan-300 text-slate-950 text-sm font-semibold rounded-xl flex items-center gap-2 transition-colors"
          >
            <Home className="w-4 h-4" />
            Back to Home
          </button>
        </div>
      </div>
    </div>
  );
};
