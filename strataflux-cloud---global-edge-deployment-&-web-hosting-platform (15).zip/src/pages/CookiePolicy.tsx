import React from 'react';

interface CookieProps {
  onNavigate: (path: string) => void;
}

export const CookiePolicy: React.FC<CookieProps> = ({ onNavigate }) => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 space-y-10 text-slate-300">
      <div className="border-b border-slate-800 pb-6 space-y-2">
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white">Cookie Policy</h1>
        <p className="text-xs text-slate-500 font-mono">Last Updated: September 2026</p>
      </div>

      <div className="space-y-6 text-sm leading-relaxed">
        <section className="space-y-2">
          <h2 className="text-lg font-bold text-white">Strictly Minimal, Functional Cookies Only</h2>
          <p>
            StrataFlux Cloud believes in digital privacy. We do not use third-party marketing cookies, cross-site trackers, or behavioral advertising cookies.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-lg font-bold text-white">What Cookies We Use</h2>
          <div className="border border-slate-800 rounded-lg overflow-hidden bg-slate-900">
            <table className="w-full text-left text-xs font-mono text-slate-300">
              <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="py-2.5 px-4">Cookie Name</th>
                  <th className="py-2.5 px-4">Type</th>
                  <th className="py-2.5 px-4">Purpose</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                <tr>
                  <td className="py-2.5 px-4 text-cyan-400 font-semibold">strataflux_token</td>
                  <td className="py-2.5 px-4">Strictly Necessary (HTTPOnly)</td>
                  <td className="py-2.5 px-4 text-slate-400 font-sans">Maintains user session security and authentication</td>
                </tr>
              </tbody>
            </table>
          </div>
        </section>

        <section className="space-y-2">
          <h2 className="text-lg font-bold text-white">Contact</h2>
          <p>
            For inquiries regarding our cookie standards, email: <span className="text-cyan-400 font-mono">muhammadofficial356@gmail.com</span>
          </p>
        </section>
      </div>
    </div>
  );
};
