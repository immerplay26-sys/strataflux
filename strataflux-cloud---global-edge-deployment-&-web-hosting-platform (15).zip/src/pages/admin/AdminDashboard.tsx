import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Logo } from '../../components/Logo';
import {
  Shield,
  Users,
  FolderGit2,
  Rocket,
  Globe,
  BarChart3,
  DollarSign,
  Layers,
  HardDrive,
  LifeBuoy,
  Megaphone,
  Search,
  Settings,
  Lock,
  Activity,
  Server,
  Download,
  Trash2,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  ExternalLink,
  LogOut,
  UserCheck,
  UserX,
  Plus,
  CreditCard,
  Wallet,
  Send,
  Smartphone,
  Clock,
  XCircle,
  Check,
  Eye,
  X,
  Copy,
  CheckCheck,
  Menu
} from 'lucide-react';

interface AdminDashboardProps {
  onNavigate: (path: string) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onNavigate }) => {
  const { user, token, logout } = useAuth();
  const [activeSection, setActiveSection] = useState<string>('overview');
  const [loading, setLoading] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Data states
  const [overview, setOverview] = useState<any>(null);
  const [usersList, setUsersList] = useState<any[]>([]);
  const [userSearch, setUserSearch] = useState('');
  const [projectsList, setProjectsList] = useState<any[]>([]);
  const [deploymentsList, setDeploymentsList] = useState<any[]>([]);
  const [domainsList, setDomainsList] = useState<any[]>([]);
  const [analyticsData, setAnalyticsData] = useState<any>(null);
  const [plansList, setPlansList] = useState<any[]>([]);
  const [supportTickets, setSupportTickets] = useState<any[]>([]);
  const [activityLogs, setActivityLogs] = useState<any[]>([]);
  const [systemHealth, setSystemHealth] = useState<any>(null);
  const [settingsData, setSettingsData] = useState<any>(null);

  // Payments & Manual Verifications
  const [paymentsList, setPaymentsList] = useState<any[]>([]);
  const [paymentFilter, setPaymentFilter] = useState<'pending' | 'approved' | 'rejected' | 'all' | 'settings'>('pending');
  const [adminPaymentSettings, setAdminPaymentSettings] = useState<any>(null);
  const [selectedReceipt, setSelectedReceipt] = useState<string | null>(null);
  const [paymentActionModal, setPaymentActionModal] = useState<{
    isOpen: boolean;
    type: 'approve' | 'reject';
    payment: any;
    note: string;
  } | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Forms states
  const [announcementText, setAnnouncementText] = useState('');
  const [announcementActive, setAnnouncementActive] = useState(false);
  const [seoTitle, setSeoTitle] = useState('');
  const [seoDesc, setSeoDesc] = useState('');
  const [seoRobots, setSeoRobots] = useState('');
  const [siteName, setSiteName] = useState('');
  const [siteEmail, setSiteEmail] = useState('');
  const [siteWhatsapp, setSiteWhatsapp] = useState('');
  const [siteMaintenance, setSiteMaintenance] = useState(false);

  // Admin Profile form
  const [adminName, setAdminName] = useState(user?.name || '');
  const [adminEmail, setAdminEmail] = useState(user?.email || '');
  const [adminCurrentPass, setAdminCurrentPass] = useState('');
  const [adminNewPass, setAdminNewPass] = useState('');

  // Selected ticket reply
  const [selectedTicket, setSelectedTicket] = useState<any>(null);
  const [ticketReply, setTicketReply] = useState('');

  // Logs modal for deployments
  const [inspectedDep, setInspectedDep] = useState<any>(null);

  const fetchSectionData = async (section: string) => {
    setLoading(true);
    try {
      if (section === 'overview') {
        const res = await fetch('/api/admin/overview', { headers: { Authorization: `Bearer ${token}` } });
        if (res.ok) setOverview(await res.json());
      } else if (section === 'users') {
        const res = await fetch('/api/admin/users', { headers: { Authorization: `Bearer ${token}` } });
        if (res.ok) {
          const d = await res.json();
          setUsersList(d.users || []);
        }
      } else if (section === 'projects') {
        const res = await fetch('/api/admin/projects', { headers: { Authorization: `Bearer ${token}` } });
        if (res.ok) {
          const d = await res.json();
          setProjectsList(d.projects || []);
        }
      } else if (section === 'deployments') {
        const res = await fetch('/api/admin/deployments', { headers: { Authorization: `Bearer ${token}` } });
        if (res.ok) {
          const d = await res.json();
          setDeploymentsList(d.deployments || []);
        }
      } else if (section === 'domains') {
        const res = await fetch('/api/admin/domains', { headers: { Authorization: `Bearer ${token}` } });
        if (res.ok) {
          const d = await res.json();
          setDomainsList(d.domains || []);
        }
      } else if (section === 'analytics') {
        const res = await fetch('/api/admin-analytics?days=30', { headers: { Authorization: `Bearer ${token}` } })
          .catch(() => fetch('/api/analytics/admin?days=30', { headers: { Authorization: `Bearer ${token}` } }));
        if (res && res.ok) setAnalyticsData(await res.json());
      } else if (section === 'plans') {
        const res = await fetch('/api/admin/plans', { headers: { Authorization: `Bearer ${token}` } });
        if (res.ok) {
          const d = await res.json();
          setPlansList(d.plans || []);
        }
      } else if (section === 'revenue') {
        const [payRes, setRes] = await Promise.all([
          fetch('/api/admin/payments', { headers: { Authorization: `Bearer ${token}` } }),
          fetch('/api/admin/payment-settings', { headers: { Authorization: `Bearer ${token}` } })
        ]);
        if (payRes.ok) {
          const d = await payRes.json();
          setPaymentsList(d.payments || []);
        }
        if (setRes.ok) {
          const d = await setRes.json();
          setAdminPaymentSettings(d.settings || {});
        }
      } else if (section === 'support') {
        const res = await fetch('/api/admin/support', { headers: { Authorization: `Bearer ${token}` } });
        if (res.ok) {
          const d = await res.json();
          setSupportTickets(d.tickets || []);
        }
      } else if (section === 'logs') {
        const res = await fetch('/api/admin/logs?limit=100', { headers: { Authorization: `Bearer ${token}` } });
        if (res.ok) {
          const d = await res.json();
          setActivityLogs(d.logs || []);
        }
      } else if (section === 'system' || section === 'storage' || section === 'integrations') {
        const res = await fetch('/api/admin/system-health', { headers: { Authorization: `Bearer ${token}` } });
        if (res.ok) setSystemHealth(await res.json());
      } else if (section === 'settings' || section === 'announcements' || section === 'seo') {
        const res = await fetch('/api/admin/settings', { headers: { Authorization: `Bearer ${token}` } });
        if (res.ok) {
          const d = await res.json();
          setSettingsData(d.settings);
          if (d.settings?.website) {
            setSiteName(d.settings.website.name || 'StrataFlux Cloud');
            setSiteEmail(d.settings.website.contact_email || 'muhammadofficial356@gmail.com');
            setSiteWhatsapp(d.settings.website.whatsapp || '+923199389323');
            setSiteMaintenance(!!d.settings.website.maintenance_mode);
            setAnnouncementText(d.settings.website.announcement_text || '');
            setAnnouncementActive(!!d.settings.website.announcement_active);
          }
          if (d.settings?.seo) {
            setSeoTitle(d.settings.seo.meta_title || '');
            setSeoDesc(d.settings.seo.meta_description || '');
            setSeoRobots(d.settings.seo.robots_txt || '');
          }
        }
      }
    } catch (e) {
      console.error('Failed loading admin section data', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSectionData(activeSection);
  }, [activeSection]);

  const handleToggleUserStatus = async (userId: string, currentStatus: string) => {
    const nextStatus = currentStatus === 'active' ? 'suspended' : 'active';
    try {
      const res = await fetch(`/api/admin/users/${userId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ status: nextStatus })
      });
      if (res.ok) fetchSectionData('users');
    } catch (e) {}
  };

  const handleDeleteUser = async (userId: string) => {
    if (!confirm('Permanently delete this user and all their deployments?')) return;
    try {
      const res = await fetch(`/api/admin/users/${userId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) fetchSectionData('users');
    } catch (e) {}
  };

  const handleDeleteProject = async (projectId: string) => {
    if (!confirm('Force delete this project from the platform?')) return;
    try {
      const res = await fetch(`/api/admin/projects/${projectId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) fetchSectionData('projects');
    } catch (e) {}
  };

  const handleDeleteDeployment = async (depId: string) => {
    if (!confirm('Force delete this deployment release from edge storage?')) return;
    try {
      const res = await fetch(`/api/admin/deployments/${depId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) fetchSectionData('deployments');
    } catch (e) {}
  };

  const handleForceVerifyDomain = async (domId: string) => {
    try {
      const res = await fetch(`/api/admin/domains/${domId}/force-verify`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        alert('Domain force-verified with TLS active.');
        fetchSectionData('domains');
      }
    } catch (e) {}
  };

  const handleUpdatePlans = async () => {
    try {
      const res = await fetch('/api/admin/plans', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ plans: plansList })
      });
      if (res.ok) alert('Subscription tiers saved successfully.');
    } catch (e) {}
  };

  const openApproveModal = (payment: any) => {
    setPaymentActionModal({
      isOpen: true,
      type: 'approve',
      payment,
      note: 'Verified and approved by administrator.'
    });
  };

  const openRejectModal = (payment: any) => {
    setPaymentActionModal({
      isOpen: true,
      type: 'reject',
      payment,
      note: 'Transaction / reference ID could not be confirmed on the receiving account statement.'
    });
  };

  const handleConfirmPaymentAction = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!paymentActionModal) return;
    const { type, payment, note } = paymentActionModal;
    try {
      const endpoint = type === 'approve' ? `/api/admin/payments/${payment.id}/approve` : `/api/admin/payments/${payment.id}/reject`;
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ note: note.trim() || undefined })
      });
      const data = await res.json();
      if (!res.ok) {
        setToastMessage({ type: 'error', text: data.error || `Failed to ${type} payment.` });
        return;
      }
      setToastMessage({
        type: 'success',
        text: type === 'approve'
          ? `Payment of ${payment.currency} ${payment.amount} approved! Plan ${payment.plan_name} has been activated.`
          : `Payment reference #${payment.transaction_id} rejected.`
      });
      setPaymentActionModal(null);
      fetchSectionData('revenue');
    } catch (err: any) {
      setToastMessage({ type: 'error', text: err.message || `Error during payment ${type}.` });
    }
  };

  const handleSavePaymentSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/admin/payment-settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ settings: adminPaymentSettings })
      });
      const d = await res.json();
      if (res.ok) {
        setToastMessage({ type: 'success', text: 'All 5 payment provider settings saved successfully!' });
        fetchSectionData('revenue');
      } else {
        setToastMessage({ type: 'error', text: d.error || 'Failed saving payment settings' });
      }
    } catch (e: any) {
      setToastMessage({ type: 'error', text: e.message || 'Error saving payment settings' });
    }
  };

  const handleCopyId = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleReplyTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTicket || !ticketReply.trim()) return;
    try {
      const res = await fetch(`/api/admin/support/${selectedTicket.id}/reply`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ content: ticketReply })
      });
      if (res.ok) {
        const d = await res.json();
        setSelectedTicket(d.ticket);
        setTicketReply('');
        fetchSectionData('support');
      }
    } catch (e) {}
  };

  const handleSaveAnnouncements = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const current = settingsData?.website || {};
      await fetch('/api/admin/settings/website', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          ...current,
          announcement_text: announcementText,
          announcement_active: announcementActive
        })
      });
      alert('Global announcements updated.');
    } catch (e) {}
  };

  const handleSaveSEO = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await fetch('/api/admin/settings/seo', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          meta_title: seoTitle,
          meta_description: seoDesc,
          robots_txt: seoRobots
        })
      });
      alert('SEO & search crawler configuration updated.');
    } catch (e) {}
  };

  const handleSaveWebsite = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const current = settingsData?.website || {};
      await fetch('/api/admin/settings/website', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          ...current,
          name: siteName,
          contact_email: siteEmail,
          whatsapp: siteWhatsapp,
          maintenance_mode: siteMaintenance
        })
      });
      alert('Official website settings saved.');
    } catch (e) {}
  };

  const handleSaveAdminProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/admin/profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          name: adminName,
          email: adminEmail,
          currentPassword: adminCurrentPass,
          newPassword: adminNewPass || undefined
        })
      });
      const data = await res.json();
      if (res.ok) {
        alert('Administrator credentials updated.');
        setAdminCurrentPass('');
        setAdminNewPass('');
      } else {
        alert(data.error || 'Failed updating profile');
      }
    } catch (e) {
      alert('Error updating administrator profile');
    }
  };

  const adminNavItems = [
    { id: 'overview', label: 'Overview', icon: Activity },
    { id: 'users', label: 'Users', icon: Users },
    { id: 'projects', label: 'Projects', icon: FolderGit2 },
    { id: 'deployments', label: 'Deployments', icon: Rocket },
    { id: 'domains', label: 'Custom Domains', icon: Globe },
    { id: 'analytics', label: 'Platform Analytics', icon: BarChart3 },
    { id: 'revenue', label: 'Revenue & Subs', icon: DollarSign },
    { id: 'plans', label: 'Plans & Pricing', icon: Layers },
    { id: 'storage', label: 'Storage & Bandwidth', icon: HardDrive },
    { id: 'support', label: 'Support Desk', icon: LifeBuoy },
    { id: 'announcements', label: 'Announcements', icon: Megaphone },
    { id: 'seo', label: 'SEO & Metadata', icon: Search },
    { id: 'settings', label: 'Website Settings', icon: Settings },
    { id: 'integrations', label: 'External Services', icon: Globe },
    { id: 'logs', label: 'Security & Logs', icon: Lock },
    { id: 'system', label: 'System Health & Backup', icon: Server },
    { id: 'profile', label: 'Admin Security', icon: Shield },
  ];

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col md:flex-row text-slate-200">
      {/* Mobile Admin Header Bar */}
      <div className="md:hidden flex items-center justify-between p-4 border-b border-amber-900/40 bg-slate-900 sticky top-0 z-40">
        <div className="flex items-center gap-2">
          <Shield className="w-5 h-5 text-amber-400" />
          <span className="font-mono font-bold text-sm text-white">StrataFlux Admin</span>
          <span className="text-[10px] bg-amber-950 text-amber-300 border border-amber-800 px-1.5 py-0.5 rounded font-mono">
            ROOT
          </span>
        </div>
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
          aria-label="Toggle admin navigation"
        >
          {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {/* Mobile Drawer Backdrop */}
      {mobileMenuOpen && (
        <div
          onClick={() => setMobileMenuOpen(false)}
          className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-40 md:hidden"
        />
      )}

      {/* Admin Sidebar */}
      <aside
        className={`${
          mobileMenuOpen ? 'translate-x-0' : '-translate-x-full'
        } md:translate-x-0 transition-transform duration-200 ease-in-out flex flex-col w-64 bg-slate-900 border-r border-amber-900/40 p-4 flex-shrink-0 z-50 fixed md:sticky top-0 h-screen overflow-y-auto`}
      >
        <div className="hidden md:flex items-center justify-between pb-4 border-b border-amber-900/40">
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-amber-400" />
            <span className="font-mono font-bold text-sm text-white">StrataFlux Admin</span>
          </div>
          <span className="text-[10px] bg-amber-950 text-amber-300 border border-amber-800 px-1.5 py-0.5 rounded font-mono">
            ROOT
          </span>
        </div>

        <nav className="space-y-1 my-4 flex-1 overflow-y-auto pr-1">
          {adminNavItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeSection === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveSection(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-semibold transition-colors ${
                  isActive
                    ? 'bg-amber-950/60 text-amber-300 border border-amber-800/60'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-amber-400' : 'text-slate-500'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="pt-3 border-t border-amber-900/40 space-y-2">
          <button
            onClick={() => {
              onNavigate('/dashboard');
              setMobileMenuOpen(false);
            }}
            className="w-full text-xs text-slate-400 hover:text-white py-1.5 flex items-center gap-2"
          >
            <FolderGit2 className="w-4 h-4" />
            <span>Switch to User View</span>
          </button>
          <button
            onClick={() => {
              logout();
              onNavigate('/');
            }}
            className="w-full text-xs text-rose-400 hover:text-rose-300 py-1.5 flex items-center gap-2"
          >
            <LogOut className="w-4 h-4" />
            <span>Logout Admin</span>
          </button>
        </div>
      </aside>

      {/* Admin Content Pane */}
      <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto overflow-y-auto">
        {/* SECTION 1: OVERVIEW */}
        {activeSection === 'overview' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-white tracking-tight">Platform Control Center</h1>
                <p className="text-xs text-slate-400 mt-1">Real-time status of global tenants, infrastructure, and edge traffic.</p>
              </div>
              <button onClick={() => fetchSectionData('overview')} className="p-2 bg-slate-900 border border-slate-800 rounded-lg text-slate-400 hover:text-white">
                <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-1">
                <span className="text-[11px] font-semibold text-slate-400 uppercase">Registered Users</span>
                <div className="text-2xl font-bold text-white font-mono">{overview?.metrics?.totalUsers || 0}</div>
              </div>
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-1">
                <span className="text-[11px] font-semibold text-slate-400 uppercase">Total Projects</span>
                <div className="text-2xl font-bold text-cyan-400 font-mono">{overview?.metrics?.totalProjects || 0}</div>
              </div>
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-1">
                <span className="text-[11px] font-semibold text-slate-400 uppercase">Deployments</span>
                <div className="text-2xl font-bold text-emerald-400 font-mono">{overview?.metrics?.totalDeployments || 0}</div>
              </div>
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-1">
                <span className="text-[11px] font-semibold text-slate-400 uppercase">30d Global Views</span>
                <div className="text-2xl font-bold text-white font-mono">{overview?.metrics?.totalViews30d || 0}</div>
              </div>
            </div>

            {/* Recent Activity Table */}
            <div className="space-y-3">
              <h2 className="text-sm font-bold text-white">Recent Global Activity</h2>
              <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden text-xs">
                <div className="overflow-x-auto w-full table-responsive-container">
                  <table className="w-full text-left text-slate-300 min-w-[550px]">
                    <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                      <tr>
                        <th className="py-2.5 px-4">Action</th>
                        <th className="py-2.5 px-4">Actor</th>
                        <th className="py-2.5 px-4">IP Address</th>
                        <th className="py-2.5 px-4">Timestamp</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60 font-mono">
                      {overview?.recentActivity?.map((a: any) => (
                        <tr key={a.id}>
                          <td className="py-2.5 px-4 text-cyan-300 font-bold">{a.action}</td>
                          <td className="py-2.5 px-4 text-slate-400 font-sans">{a.actor_email || 'System'}</td>
                          <td className="py-2.5 px-4 text-slate-500">{a.ip_address || '127.0.0.1'}</td>
                          <td className="py-2.5 px-4 text-slate-500 font-sans">{new Date(a.created_at).toLocaleString()}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* SECTION 2: USERS */}
        {activeSection === 'users' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-2xl font-bold text-white tracking-tight">Platform Users</h1>
                <p className="text-xs text-slate-400 mt-1">Manage accounts, change roles, deactivate abusive users.</p>
              </div>
              <input
                type="text"
                value={userSearch}
                onChange={(e) => setUserSearch(e.target.value)}
                placeholder="Search by name or email..."
                className="bg-slate-900 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-white"
              />
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
              <div className="overflow-x-auto w-full table-responsive-container">
                <table className="w-full text-left text-xs text-slate-300 min-w-[620px]">
                  <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                    <tr>
                      <th className="py-3 px-4">User</th>
                      <th className="py-3 px-4">Role</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4">Plan Tier</th>
                      <th className="py-3 px-4">Registered</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-mono">
                    {usersList
                      .filter(u => u.email.toLowerCase().includes(userSearch.toLowerCase()) || u.name.toLowerCase().includes(userSearch.toLowerCase()))
                      .map((u) => (
                        <tr key={u.id} className="hover:bg-slate-800/30">
                          <td className="py-3 px-4 font-sans font-medium text-white">
                            <div>{u.name}</div>
                            <div className="text-[11px] text-slate-500 font-mono">{u.email}</div>
                          </td>
                          <td className="py-3 px-4 text-amber-300 uppercase">{u.role}</td>
                          <td className="py-3 px-4">
                            <span className={`text-[10px] uppercase font-bold px-1.5 py-0.5 rounded ${
                              u.status === 'active' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-rose-950 text-rose-400'
                            }`}>
                              {u.status}
                            </span>
                          </td>
                          <td className="py-3 px-4 uppercase text-cyan-300">{u.plan_tier}</td>
                          <td className="py-3 px-4 text-slate-500 font-sans">{new Date(u.created_at).toLocaleDateString()}</td>
                          <td className="py-3 px-4 text-right font-sans space-x-2 whitespace-nowrap">
                            <button
                              onClick={() => handleToggleUserStatus(u.id, u.status)}
                              className="text-amber-400 hover:text-amber-300 text-xs font-medium"
                            >
                              {u.status === 'active' ? 'Suspend' : 'Activate'}
                            </button>
                            {u.id !== user?.id && (
                              <button
                                onClick={() => handleDeleteUser(u.id)}
                                className="text-rose-400 hover:text-rose-300 text-xs font-medium"
                              >
                                Delete
                              </button>
                            )}
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* SECTION 3: PROJECTS */}
        {activeSection === 'projects' && (
          <div className="space-y-6">
            <div>
              <h1 className="text-2xl font-bold text-white tracking-tight">All Deployed Projects</h1>
              <p className="text-xs text-slate-400 mt-1">Audit user applications and prune abusive content.</p>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
              <div className="overflow-x-auto w-full table-responsive-container">
                <table className="w-full text-left text-xs text-slate-300 min-w-[620px]">
                  <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                    <tr>
                      <th className="py-3 px-4">Project</th>
                      <th className="py-3 px-4">Subdomain</th>
                      <th className="py-3 px-4">Owner</th>
                      <th className="py-3 px-4">Storage</th>
                      <th className="py-3 px-4">Deployments</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-mono">
                    {projectsList.map((p) => (
                      <tr key={p.id}>
                        <td className="py-3 px-4 font-sans font-bold text-white">{p.name}</td>
                        <td className="py-3 px-4 text-cyan-300">{p.subdomain}.strataflux.app</td>
                        <td className="py-3 px-4 font-sans text-slate-400">{p.ownerEmail}</td>
                        <td className="py-3 px-4">{(p.storage_used_bytes / 1024).toFixed(1)} KB</td>
                        <td className="py-3 px-4">{p.total_deployments}</td>
                        <td className="py-3 px-4 text-right font-sans space-x-2 whitespace-nowrap">
                          <a
                            href={`/sites/${p.subdomain}/`}
                            target="_blank"
                            rel="noreferrer"
                            className="text-cyan-400 hover:underline"
                          >
                            View Live
                          </a>
                          <button
                            onClick={() => handleDeleteProject(p.id)}
                            className="text-rose-400 hover:text-rose-300 font-medium"
                          >
                            Delete
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* SECTION 4: DEPLOYMENTS */}
        {activeSection === 'deployments' && (
          <div className="space-y-6">
            <div>
              <h1 className="text-2xl font-bold text-white tracking-tight">Deployments Audit</h1>
              <p className="text-xs text-slate-400 mt-1">Raw build logs, archive sizes, and deployment statuses.</p>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
              <div className="overflow-x-auto w-full table-responsive-container">
                <table className="w-full text-left text-xs text-slate-300 min-w-[620px]">
                  <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                    <tr>
                      <th className="py-3 px-4">Deployment ID</th>
                      <th className="py-3 px-4">Project</th>
                      <th className="py-3 px-4">Owner</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4">Size</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-mono">
                    {deploymentsList.map((d) => (
                      <tr key={d.id}>
                        <td className="py-3 px-4 font-bold text-white">{d.id.slice(0, 14)}...</td>
                        <td className="py-3 px-4 font-sans text-slate-300">{d.projectName}</td>
                        <td className="py-3 px-4 font-sans text-slate-400">{d.userEmail}</td>
                        <td className="py-3 px-4 uppercase text-emerald-400 font-bold">{d.status}</td>
                        <td className="py-3 px-4">{(d.total_size_bytes / 1024).toFixed(1)} KB</td>
                        <td className="py-3 px-4 text-right font-sans space-x-2 whitespace-nowrap">
                          <button
                            onClick={() => setInspectedDep(d)}
                            className="text-cyan-400 hover:underline"
                          >
                            Logs
                          </button>
                          <button
                            onClick={() => handleDeleteDeployment(d.id)}
                            className="text-rose-400 hover:underline"
                          >
                            Purge
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* SECTION 5: CUSTOM DOMAINS */}
        {activeSection === 'domains' && (
          <div className="space-y-6">
            <div>
              <h1 className="text-2xl font-bold text-white tracking-tight">Custom Domains Directory</h1>
              <p className="text-xs text-slate-400 mt-1">Review external domains and force-verify Anycast SSL status.</p>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
              <div className="overflow-x-auto w-full table-responsive-container">
                <table className="w-full text-left text-xs text-slate-300 min-w-[620px]">
                  <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                    <tr>
                      <th className="py-3 px-4">Domain</th>
                      <th className="py-3 px-4">Project</th>
                      <th className="py-3 px-4">Owner</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4">SSL</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-mono">
                    {domainsList.map((dm) => (
                      <tr key={dm.id}>
                        <td className="py-3 px-4 font-bold text-white">{dm.domain}</td>
                        <td className="py-3 px-4 font-sans text-slate-300">{dm.projectName}</td>
                        <td className="py-3 px-4 font-sans text-slate-400">{dm.userEmail}</td>
                        <td className="py-3 px-4 uppercase">{dm.is_verified ? 'Verified' : 'Pending'}</td>
                        <td className="py-3 px-4 text-emerald-400">{dm.ssl_status}</td>
                        <td className="py-3 px-4 text-right font-sans whitespace-nowrap">
                          {!dm.is_verified && (
                            <button
                              onClick={() => handleForceVerifyDomain(dm.id)}
                              className="text-amber-400 hover:underline"
                            >
                              Force Verify
                            </button>
                          )}
                        </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

        {/* SECTION 6: PLANS & PRICING */}
        {activeSection === 'plans' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-white tracking-tight">Monetization & Plans Management</h1>
                <p className="text-xs text-slate-400 mt-1">Update monthly/annual prices, storage quotas, and feature lists.</p>
              </div>
              <button
                onClick={handleUpdatePlans}
                className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-lg transition-colors"
              >
                Save All Plans
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {plansList.map((p, idx) => (
                <div key={p.id} className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
                  <h3 className="text-lg font-bold text-white uppercase">{p.name}</h3>

                  <div className="space-y-2 text-xs">
                    <div>
                      <label className="text-slate-400 block mb-1">Monthly Price ($)</label>
                      <input
                        type="number"
                        value={p.price_monthly}
                        onChange={(e) => {
                          const updated = [...plansList];
                          updated[idx].price_monthly = parseInt(e.target.value, 10) || 0;
                          setPlansList(updated);
                        }}
                        className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-white font-mono"
                      />
                    </div>

                    <div>
                      <label className="text-slate-400 block mb-1">Annual Price ($)</label>
                      <input
                        type="number"
                        value={p.price_yearly}
                        onChange={(e) => {
                          const updated = [...plansList];
                          updated[idx].price_yearly = parseInt(e.target.value, 10) || 0;
                          setPlansList(updated);
                        }}
                        className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-white font-mono"
                      />
                    </div>

                    <div>
                      <label className="text-slate-400 block mb-1">Max Projects</label>
                      <input
                        type="number"
                        value={p.max_projects}
                        onChange={(e) => {
                          const updated = [...plansList];
                          updated[idx].max_projects = parseInt(e.target.value, 10) || 1;
                          setPlansList(updated);
                        }}
                        className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-white font-mono"
                      />
                    </div>

                    <div>
                      <label className="text-slate-400 block mb-1">Max Custom Domains</label>
                      <input
                        type="number"
                        value={p.max_custom_domains}
                        onChange={(e) => {
                          const updated = [...plansList];
                          updated[idx].max_custom_domains = parseInt(e.target.value, 10) || 1;
                          setPlansList(updated);
                        }}
                        className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-white font-mono"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* SECTION: REVENUE, PAYMENTS & MANUAL VERIFICATION QUEUE */}
        {activeSection === 'revenue' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-2xl font-bold text-white tracking-tight">Payments & Verification Queue</h1>
                <p className="text-xs text-slate-400 mt-1">
                  Manage Stripe, PayPal, Payoneer, JazzCash, and Easypaisa payments. Verify transaction IDs, review receipts, and activate subscriptions.
                </p>
              </div>
              <button
                onClick={() => fetchSectionData('revenue')}
                className="p-2 bg-slate-900 border border-slate-800 rounded-lg text-slate-400 hover:text-white self-start sm:self-auto"
                title="Refresh payments"
              >
                <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
              </button>
            </div>

            {/* Quick Metrics */}
            {(() => {
              const pending = paymentsList.filter(p => p.status === 'pending');
              const approved = paymentsList.filter(p => p.status === 'approved' || p.status === 'completed');
              const rejected = paymentsList.filter(p => p.status === 'rejected' || p.status === 'failed');
              const totalUsd = approved
                .filter(p => !p.currency || p.currency === 'USD')
                .reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
              const totalPkr = approved
                .filter(p => p.currency === 'PKR')
                .reduce((sum, p) => sum + (Number(p.amount) || 0), 0);

              return (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-1">
                    <span className="text-[11px] font-semibold text-slate-400 uppercase">Verified Revenue</span>
                    <div className="text-xl font-bold text-emerald-400 font-mono">
                      ${totalUsd.toLocaleString()}
                    </div>
                    {totalPkr > 0 && (
                      <div className="text-[11px] font-mono text-emerald-300">
                        + PKR {totalPkr.toLocaleString()}
                      </div>
                    )}
                  </div>
                  <div className={`bg-slate-900 border rounded-xl p-4 space-y-1 ${
                    pending.length > 0 ? 'border-amber-500/80 bg-amber-950/20' : 'border-slate-800'
                  }`}>
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-semibold text-slate-400 uppercase">Pending Verifications</span>
                      {pending.length > 0 && (
                        <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse"></span>
                      )}
                    </div>
                    <div className="text-2xl font-bold text-amber-400 font-mono">{pending.length}</div>
                  </div>
                  <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-1">
                    <span className="text-[11px] font-semibold text-slate-400 uppercase">Approved Payments</span>
                    <div className="text-2xl font-bold text-white font-mono">{approved.length}</div>
                  </div>
                  <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-1">
                    <span className="text-[11px] font-semibold text-slate-400 uppercase">Rejected / Disputed</span>
                    <div className="text-2xl font-bold text-rose-400 font-mono">{rejected.length}</div>
                  </div>
                </div>
              );
            })()}

            {/* Sub-Tabs: Pending, Approved, Rejected, All, Settings */}
            {(() => {
              const pendingCount = paymentsList.filter(p => p.status === 'pending').length;
              const approvedCount = paymentsList.filter(p => p.status === 'approved' || p.status === 'completed').length;
              const rejectedCount = paymentsList.filter(p => p.status === 'rejected' || p.status === 'failed').length;

              return (
                <div className="flex flex-wrap items-center gap-2 border-b border-slate-800 pb-3">
                  <button
                    onClick={() => setPaymentFilter('pending')}
                    className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                      paymentFilter === 'pending'
                        ? 'bg-amber-950 text-amber-300 border border-amber-800'
                        : 'text-slate-400 hover:text-white hover:bg-slate-800'
                    }`}
                  >
                    <Clock className="w-3.5 h-3.5" />
                    <span>Pending Verification</span>
                    {pendingCount > 0 && (
                      <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-amber-500 text-slate-950 font-bold">
                        {pendingCount}
                      </span>
                    )}
                  </button>

                  <button
                    onClick={() => setPaymentFilter('approved')}
                    className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                      paymentFilter === 'approved'
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                        : 'text-slate-400 hover:text-white hover:bg-slate-800'
                    }`}
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Approved ({approvedCount})</span>
                  </button>

                  <button
                    onClick={() => setPaymentFilter('rejected')}
                    className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                      paymentFilter === 'rejected'
                        ? 'bg-rose-950 text-rose-300 border border-rose-800'
                        : 'text-slate-400 hover:text-white hover:bg-slate-800'
                    }`}
                  >
                    <XCircle className="w-3.5 h-3.5" />
                    <span>Rejected ({rejectedCount})</span>
                  </button>

                  <button
                    onClick={() => setPaymentFilter('all')}
                    className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                      paymentFilter === 'all'
                        ? 'bg-slate-800 text-white border border-slate-700'
                        : 'text-slate-400 hover:text-white hover:bg-slate-800'
                    }`}
                  >
                    <span>All Transactions ({paymentsList.length})</span>
                  </button>

                  <div className="ml-auto">
                    <button
                      onClick={() => setPaymentFilter('settings')}
                      className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                        paymentFilter === 'settings'
                          ? 'bg-cyan-950 text-cyan-300 border border-cyan-800'
                          : 'text-slate-400 hover:text-white hover:bg-slate-800'
                      }`}
                    >
                      <Settings className="w-3.5 h-3.5" />
                      <span>Payment Provider Settings</span>
                    </button>
                  </div>
                </div>
              );
            })()}

            {/* TAB CONTENT: PAYMENT PROVIDER SETTINGS */}
            {paymentFilter === 'settings' ? (
              <form onSubmit={handleSavePaymentSettings} className="space-y-6 max-w-4xl">
                <div>
                  <h2 className="text-lg font-bold text-white flex items-center gap-2">
                    <Settings className="w-5 h-5 text-cyan-400" />
                    Payment Provider & Method Settings
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    Enable or disable any of the 5 supported payment methods. Configure manual account titles, mobile numbers, and checkout instructions securely.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  {/* 1. STRIPE */}
                  <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
                    <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                      <div className="flex items-center gap-2">
                        <CreditCard className="w-5 h-5 text-sky-400" />
                        <div>
                          <h3 className="text-sm font-bold text-white">Stripe Card Checkout</h3>
                          <span className="text-[10px] text-slate-400 font-mono">Automated Gateway</span>
                        </div>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input
                          type="checkbox"
                          checked={adminPaymentSettings?.stripe?.enabled !== false}
                          onChange={(e) => {
                            setAdminPaymentSettings({
                              ...adminPaymentSettings,
                              stripe: {
                                ...(adminPaymentSettings?.stripe || {}),
                                enabled: e.target.checked
                              }
                            });
                          }}
                          className="sr-only peer"
                        />
                        <div className="w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-sky-500"></div>
                      </label>
                    </div>

                    <div className="space-y-3 text-xs">
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="text-slate-300 font-medium">Stripe Status</label>
                          <span className={`text-[10px] font-semibold px-2 py-0.5 rounded ${
                            adminPaymentSettings?.stripe?.isConfigured
                              ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                              : 'bg-slate-950 text-slate-400 border border-slate-800'
                          }`}>
                            {adminPaymentSettings?.stripe?.isConfigured ? 'Configured' : 'Not configured'}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400">
                          {adminPaymentSettings?.stripe?.isConfigured
                            ? 'STRIPE_SECRET_KEY is securely loaded in environment variables.'
                            : 'Set STRIPE_SECRET_KEY in server environment to enable live card payments.'}
                        </p>
                      </div>

                      <div>
                        <label className="text-slate-300 block mb-1 font-medium">Publishable Key (Client-side)</label>
                        <input
                          type="text"
                          value={adminPaymentSettings?.stripe?.publishable_key || ''}
                          onChange={(e) => {
                            setAdminPaymentSettings({
                              ...adminPaymentSettings,
                              stripe: {
                                ...(adminPaymentSettings?.stripe || {}),
                                publishable_key: e.target.value
                              }
                            });
                          }}
                          placeholder="pk_live_..."
                          className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-white font-mono text-xs"
                        />
                      </div>
                    </div>
                  </div>

                  {/* 2. PAYPAL */}
                  <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
                    <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                      <div className="flex items-center gap-2">
                        <Wallet className="w-5 h-5 text-indigo-400" />
                        <div>
                          <h3 className="text-sm font-bold text-white">PayPal Checkout</h3>
                          <span className="text-[10px] text-slate-400 font-mono">Automated Gateway</span>
                        </div>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input
                          type="checkbox"
                          checked={adminPaymentSettings?.paypal?.enabled !== false}
                          onChange={(e) => {
                            setAdminPaymentSettings({
                              ...adminPaymentSettings,
                              paypal: {
                                ...(adminPaymentSettings?.paypal || {}),
                                enabled: e.target.checked
                              }
                            });
                          }}
                          className="sr-only peer"
                        />
                        <div className="w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-500"></div>
                      </label>
                    </div>

                    <div className="space-y-3 text-xs">
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="text-slate-300 font-medium">PayPal Status</label>
                          <span className={`text-[10px] font-semibold px-2 py-0.5 rounded ${
                            adminPaymentSettings?.paypal?.isConfigured
                              ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                              : 'bg-slate-950 text-slate-400 border border-slate-800'
                          }`}>
                            {adminPaymentSettings?.paypal?.isConfigured ? 'Configured' : 'Not configured'}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400">
                          {adminPaymentSettings?.paypal?.isConfigured
                            ? 'PAYPAL_CLIENT_ID and SECRET are securely active.'
                            : 'Set PAYPAL_CLIENT_ID and PAYPAL_CLIENT_SECRET in server environment.'}
                        </p>
                      </div>

                      <div>
                        <label className="text-slate-300 block mb-1 font-medium">Client ID</label>
                        <input
                          type="text"
                          value={adminPaymentSettings?.paypal?.client_id || ''}
                          onChange={(e) => {
                            setAdminPaymentSettings({
                              ...adminPaymentSettings,
                              paypal: {
                                ...(adminPaymentSettings?.paypal || {}),
                                client_id: e.target.value
                              }
                            });
                          }}
                          placeholder="PayPal Client ID"
                          className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-white font-mono text-xs"
                        />
                      </div>

                      <div>
                        <label className="text-slate-300 block mb-1 font-medium">Environment Mode</label>
                        <select
                          value={adminPaymentSettings?.paypal?.mode || 'sandbox'}
                          onChange={(e) => {
                            setAdminPaymentSettings({
                              ...adminPaymentSettings,
                              paypal: {
                                ...(adminPaymentSettings?.paypal || {}),
                                mode: e.target.value
                              }
                            });
                          }}
                          className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-white text-xs"
                        >
                          <option value="sandbox">Sandbox (Testing)</option>
                          <option value="live">Live (Production)</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  {/* 3. PAYONEER */}
                  <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
                    <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                      <div className="flex items-center gap-2">
                        <Send className="w-5 h-5 text-amber-400" />
                        <div>
                          <h3 className="text-sm font-bold text-white">Payoneer Global Transfer</h3>
                          <span className="text-[10px] text-amber-400 font-mono">Manual Verification</span>
                        </div>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input
                          type="checkbox"
                          checked={adminPaymentSettings?.payoneer?.enabled !== false}
                          onChange={(e) => {
                            setAdminPaymentSettings({
                              ...adminPaymentSettings,
                              payoneer: {
                                ...(adminPaymentSettings?.payoneer || {}),
                                enabled: e.target.checked
                              }
                            });
                          }}
                          className="sr-only peer"
                        />
                        <div className="w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-amber-500"></div>
                      </label>
                    </div>

                    <div className="space-y-3 text-xs">
                      <div>
                        <label className="text-slate-300 block mb-1 font-medium">Beneficiary / Account Name</label>
                        <input
                          type="text"
                          value={adminPaymentSettings?.payoneer?.account_name || ''}
                          onChange={(e) => {
                            setAdminPaymentSettings({
                              ...adminPaymentSettings,
                              payoneer: {
                                ...(adminPaymentSettings?.payoneer || {}),
                                account_name: e.target.value
                              }
                            });
                          }}
                          placeholder="e.g. StrataFlux Global Technologies"
                          className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-white text-xs"
                        />
                      </div>

                      <div>
                        <label className="text-slate-300 block mb-1 font-medium">Payoneer Receiving Email / ID</label>
                        <input
                          type="text"
                          value={adminPaymentSettings?.payoneer?.account_email || ''}
                          onChange={(e) => {
                            setAdminPaymentSettings({
                              ...adminPaymentSettings,
                              payoneer: {
                                ...(adminPaymentSettings?.payoneer || {}),
                                account_email: e.target.value
                              }
                            });
                          }}
                          placeholder="muhammadofficial356@gmail.com"
                          className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-white font-mono text-xs"
                        />
                      </div>

                      <div>
                        <label className="text-slate-300 block mb-1 font-medium">Customer Payment Instructions</label>
                        <textarea
                          rows={3}
                          value={adminPaymentSettings?.payoneer?.instructions || ''}
                          onChange={(e) => {
                            setAdminPaymentSettings({
                              ...adminPaymentSettings,
                              payoneer: {
                                ...(adminPaymentSettings?.payoneer || {}),
                                instructions: e.target.value
                              }
                            });
                          }}
                          className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-white text-xs leading-relaxed"
                        ></textarea>
                      </div>
                    </div>
                  </div>

                  {/* 4. JAZZCASH (PAKISTAN) */}
                  <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
                    <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                      <div className="flex items-center gap-2">
                        <Smartphone className="w-5 h-5 text-orange-400" />
                        <div>
                          <h3 className="text-sm font-bold text-white">JazzCash (Pakistan)</h3>
                          <span className="text-[10px] text-orange-400 font-mono">Pakistan Mobile Wallet</span>
                        </div>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input
                          type="checkbox"
                          checked={adminPaymentSettings?.jazzcash?.enabled !== false}
                          onChange={(e) => {
                            setAdminPaymentSettings({
                              ...adminPaymentSettings,
                              jazzcash: {
                                ...(adminPaymentSettings?.jazzcash || {}),
                                enabled: e.target.checked
                              }
                            });
                          }}
                          className="sr-only peer"
                        />
                        <div className="w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-orange-500"></div>
                      </label>
                    </div>

                    <div className="space-y-3 text-xs">
                      <div>
                        <label className="text-slate-300 block mb-1 font-medium">Account / Business Title</label>
                        <input
                          type="text"
                          value={adminPaymentSettings?.jazzcash?.account_name || ''}
                          onChange={(e) => {
                            setAdminPaymentSettings({
                              ...adminPaymentSettings,
                              jazzcash: {
                                ...(adminPaymentSettings?.jazzcash || {}),
                                account_name: e.target.value
                              }
                            });
                          }}
                          placeholder="Muhammad Official"
                          className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-white text-xs"
                        />
                      </div>

                      <div>
                        <label className="text-slate-300 block mb-1 font-medium">Mobile Account Number</label>
                        <input
                          type="text"
                          value={adminPaymentSettings?.jazzcash?.account_number || ''}
                          onChange={(e) => {
                            setAdminPaymentSettings({
                              ...adminPaymentSettings,
                              jazzcash: {
                                ...(adminPaymentSettings?.jazzcash || {}),
                                account_number: e.target.value
                              }
                            });
                          }}
                          placeholder="03199389323"
                          className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-white font-mono text-xs"
                        />
                      </div>

                      <div>
                        <label className="text-slate-300 block mb-1 font-medium">Customer Payment Instructions</label>
                        <textarea
                          rows={3}
                          value={adminPaymentSettings?.jazzcash?.instructions || ''}
                          onChange={(e) => {
                            setAdminPaymentSettings({
                              ...adminPaymentSettings,
                              jazzcash: {
                                ...(adminPaymentSettings?.jazzcash || {}),
                                instructions: e.target.value
                              }
                            });
                          }}
                          className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-white text-xs leading-relaxed"
                        ></textarea>
                      </div>
                    </div>
                  </div>

                  {/* 5. EASYPAISA (PAKISTAN) */}
                  <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 md:col-span-2">
                    <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                      <div className="flex items-center gap-2">
                        <Smartphone className="w-5 h-5 text-emerald-400" />
                        <div>
                          <h3 className="text-sm font-bold text-white">Easypaisa (Pakistan)</h3>
                          <span className="text-[10px] text-emerald-400 font-mono">Pakistan Mobile Wallet</span>
                        </div>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input
                          type="checkbox"
                          checked={adminPaymentSettings?.easypaisa?.enabled !== false}
                          onChange={(e) => {
                            setAdminPaymentSettings({
                              ...adminPaymentSettings,
                              easypaisa: {
                                ...(adminPaymentSettings?.easypaisa || {}),
                                enabled: e.target.checked
                              }
                            });
                          }}
                          className="sr-only peer"
                        />
                        <div className="w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-500"></div>
                      </label>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                      <div className="space-y-3">
                        <div>
                          <label className="text-slate-300 block mb-1 font-medium">Account / Business Title</label>
                          <input
                            type="text"
                            value={adminPaymentSettings?.easypaisa?.account_name || ''}
                            onChange={(e) => {
                              setAdminPaymentSettings({
                                ...adminPaymentSettings,
                                easypaisa: {
                                  ...(adminPaymentSettings?.easypaisa || {}),
                                  account_name: e.target.value
                                }
                              });
                            }}
                            placeholder="Muhammad Official"
                            className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-white text-xs"
                          />
                        </div>

                        <div>
                          <label className="text-slate-300 block mb-1 font-medium">Mobile Account Number</label>
                          <input
                            type="text"
                            value={adminPaymentSettings?.easypaisa?.account_number || ''}
                            onChange={(e) => {
                              setAdminPaymentSettings({
                                ...adminPaymentSettings,
                                easypaisa: {
                                  ...(adminPaymentSettings?.easypaisa || {}),
                                  account_number: e.target.value
                                }
                              });
                            }}
                            placeholder="03199389323"
                            className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-white font-mono text-xs"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="text-slate-300 block mb-1 font-medium">Customer Payment Instructions</label>
                        <textarea
                          rows={4}
                          value={adminPaymentSettings?.easypaisa?.instructions || ''}
                          onChange={(e) => {
                            setAdminPaymentSettings({
                              ...adminPaymentSettings,
                              easypaisa: {
                                ...(adminPaymentSettings?.easypaisa || {}),
                                instructions: e.target.value
                              }
                            });
                          }}
                          className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-white text-xs leading-relaxed"
                        ></textarea>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="pt-2 flex justify-end">
                  <button
                    type="submit"
                    className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl shadow-lg transition-colors flex items-center gap-2"
                  >
                    <Check className="w-4 h-4" />
                    <span>Save Payment Provider Settings</span>
                  </button>
                </div>
              </form>
            ) : (
              /* TAB CONTENT: PAYMENTS TRANSACTION LIST (PENDING, APPROVED, REJECTED, ALL) */
              <div className="space-y-4">
                {(() => {
                  const filtered = paymentsList.filter(p => {
                    if (paymentFilter === 'pending') return p.status === 'pending';
                    if (paymentFilter === 'approved') return p.status === 'approved' || p.status === 'completed';
                    if (paymentFilter === 'rejected') return p.status === 'rejected' || p.status === 'failed';
                    return true;
                  });

                  if (filtered.length === 0) {
                    return (
                      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-12 text-center space-y-3">
                        <div className="w-12 h-12 rounded-full bg-slate-800 flex items-center justify-center mx-auto text-slate-400">
                          <DollarSign className="w-6 h-6" />
                        </div>
                        <h3 className="text-sm font-bold text-white">No Transactions Found</h3>
                        <p className="text-xs text-slate-400 max-w-sm mx-auto">
                          There are currently no {paymentFilter === 'all' ? '' : paymentFilter} payment records in this queue.
                        </p>
                      </div>
                    );
                  }

                  return (
                    <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden text-xs">
                      <div className="overflow-x-auto w-full table-responsive-container">
                        <table className="w-full text-left text-slate-300 min-w-[780px]">
                          <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                            <tr>
                              <th className="py-3 px-4">Date</th>
                              <th className="py-3 px-4">Customer</th>
                              <th className="py-3 px-4">Plan & Billing</th>
                              <th className="py-3 px-4">Amount</th>
                              <th className="py-3 px-4">Method</th>
                              <th className="py-3 px-4">Transaction / Ref ID</th>
                              <th className="py-3 px-4">Receipt</th>
                              <th className="py-3 px-4">Status</th>
                              <th className="py-3 px-4 text-right">Actions</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-800/60 font-mono">
                            {filtered.map((pm) => {
                              const isPending = pm.status === 'pending';
                              const isApproved = pm.status === 'approved' || pm.status === 'completed';
                              const isRejected = pm.status === 'rejected' || pm.status === 'failed';

                              return (
                                <tr key={pm.id} className="hover:bg-slate-800/30 transition-colors">
                                  <td className="py-3 px-4 font-sans text-slate-400 whitespace-nowrap">
                                    {new Date(pm.created_at).toLocaleDateString()}
                                    <div className="text-[10px] text-slate-500 font-mono">
                                      {new Date(pm.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                    </div>
                                  </td>
                                  <td className="py-3 px-4 font-sans">
                                    <div className="font-bold text-white">{pm.user_name || 'Customer'}</div>
                                    <div className="text-[11px] text-slate-400">{pm.user_email || pm.user_id}</div>
                                  </td>
                                  <td className="py-3 px-4 font-sans">
                                    <span className="font-semibold text-white">{pm.plan_name}</span>
                                    <span className="ml-1.5 text-[10px] px-1.5 py-0.5 rounded bg-slate-950 text-slate-400 border border-slate-800 uppercase">
                                      {pm.billing_interval || 'monthly'}
                                    </span>
                                  </td>
                                  <td className="py-3 px-4 font-bold text-cyan-300 whitespace-nowrap">
                                    {pm.currency} {pm.amount}
                                  </td>
                                  <td className="py-3 px-4 font-sans">
                                    {(() => {
                                      switch (pm.provider?.toLowerCase()) {
                                        case 'stripe':
                                          return (
                                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold bg-sky-950 text-sky-400 border border-sky-800">
                                              <CreditCard className="w-3 h-3" /> Stripe
                                            </span>
                                          );
                                        case 'paypal':
                                          return (
                                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold bg-indigo-950 text-indigo-400 border border-indigo-800">
                                              <Wallet className="w-3 h-3" /> PayPal
                                            </span>
                                          );
                                        case 'payoneer':
                                          return (
                                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold bg-amber-950 text-amber-400 border border-amber-800">
                                              <Send className="w-3 h-3" /> Payoneer
                                            </span>
                                          );
                                        case 'jazzcash':
                                          return (
                                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold bg-orange-950 text-orange-400 border border-orange-800">
                                              <Smartphone className="w-3 h-3" /> JazzCash
                                            </span>
                                          );
                                        case 'easypaisa':
                                          return (
                                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-950 text-emerald-400 border border-emerald-800">
                                              <Smartphone className="w-3 h-3" /> Easypaisa
                                            </span>
                                          );
                                        default:
                                          return (
                                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold bg-slate-800 text-slate-300">
                                              {pm.payment_method || pm.provider}
                                            </span>
                                          );
                                      }
                                    })()}
                                  </td>
                                  <td className="py-3 px-4">
                                    <div className="flex items-center gap-1.5">
                                      <span className="text-white font-mono select-all bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                                        {pm.transaction_id}
                                      </span>
                                      <button
                                        onClick={() => handleCopyId(pm.transaction_id, pm.id)}
                                        className="text-slate-400 hover:text-white p-1"
                                        title="Copy reference ID"
                                      >
                                        {copiedId === pm.id ? (
                                          <CheckCheck className="w-3.5 h-3.5 text-emerald-400" />
                                        ) : (
                                          <Copy className="w-3.5 h-3.5" />
                                        )}
                                      </button>
                                    </div>
                                    {pm.customer_note && (
                                      <div className="text-[10px] text-slate-400 font-sans italic mt-1 max-w-xs truncate" title={pm.customer_note}>
                                        Note: "{pm.customer_note}"
                                      </div>
                                    )}
                                  </td>
                                  <td className="py-3 px-4 font-sans">
                                    {pm.screenshot_path ? (
                                      <button
                                        onClick={() => setSelectedReceipt(pm.screenshot_path)}
                                        className="inline-flex items-center gap-1 text-cyan-400 hover:text-cyan-300 hover:underline font-semibold"
                                      >
                                        <Eye className="w-3.5 h-3.5" />
                                        <span>View</span>
                                      </button>
                                    ) : (
                                      <span className="text-slate-600">-</span>
                                    )}
                                  </td>
                                  <td className="py-3 px-4 font-sans">
                                    {isPending && (
                                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-amber-950/80 text-amber-400 border border-amber-800 animate-pulse">
                                        <Clock className="w-3 h-3" />
                                        Pending
                                      </span>
                                    )}
                                    {isApproved && (
                                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-950/80 text-emerald-400 border border-emerald-800">
                                        <CheckCircle2 className="w-3 h-3" />
                                        Approved
                                      </span>
                                    )}
                                    {isRejected && (
                                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-rose-950/80 text-rose-400 border border-rose-800">
                                        <XCircle className="w-3 h-3" />
                                        Rejected
                                      </span>
                                    )}
                                  </td>
                                  <td className="py-3 px-4 text-right font-sans whitespace-nowrap">
                                    {isPending ? (
                                      <div className="flex items-center justify-end gap-2">
                                        <button
                                          onClick={() => openApproveModal(pm)}
                                          className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold shadow transition-colors flex items-center gap-1"
                                        >
                                          <Check className="w-3.5 h-3.5" />
                                          <span>Approve</span>
                                        </button>
                                        <button
                                          onClick={() => openRejectModal(pm)}
                                          className="px-2.5 py-1 bg-rose-600/80 hover:bg-rose-600 text-white rounded-lg text-xs font-semibold transition-colors flex items-center gap-1"
                                        >
                                          <X className="w-3.5 h-3.5" />
                                          <span>Reject</span>
                                        </button>
                                      </div>
                                    ) : (
                                      <div className="text-[10px] text-slate-500">
                                        {pm.admin_note ? (
                                          <span className="italic" title={pm.admin_note}>
                                            "{pm.admin_note}"
                                          </span>
                                        ) : (
                                          <span>{isApproved ? 'Approved' : 'Rejected'}</span>
                                        )}
                                      </div>
                                    )}
                                  </td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  );
                })()}
              </div>
            )}
          </div>
        )}

        {/* SECTION 7: SUPPORT TICKETS */}
        {activeSection === 'support' && (
          <div className="space-y-6">
            <div>
              <h1 className="text-2xl font-bold text-white tracking-tight">Customer Support Queue</h1>
              <p className="text-xs text-slate-400 mt-1">Review user issues, update ticket statuses, and respond as administrator.</p>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                  <tr>
                    <th className="py-3 px-4">Subject</th>
                    <th className="py-3 px-4">User</th>
                    <th className="py-3 px-4">Priority</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono">
                  {supportTickets.map((t) => (
                    <tr key={t.id}>
                      <td className="py-3 px-4 font-sans font-bold text-white">{t.subject}</td>
                      <td className="py-3 px-4 font-sans text-slate-400">{t.user_email}</td>
                      <td className="py-3 px-4 uppercase text-amber-300">{t.priority}</td>
                      <td className="py-3 px-4 uppercase">{t.status}</td>
                      <td className="py-3 px-4 text-right font-sans">
                        <button
                          onClick={() => setSelectedTicket(t)}
                          className="text-cyan-400 hover:underline font-bold"
                        >
                          Manage & Reply
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Ticket Reply Modal */}
            {selectedTicket && (
              <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
                <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full p-6 space-y-4 shadow-2xl flex flex-col max-h-[85vh]">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                    <div>
                      <h3 className="font-bold text-white text-sm">{selectedTicket.subject}</h3>
                      <div className="text-xs text-slate-400">{selectedTicket.user_email}</div>
                    </div>
                    <button onClick={() => setSelectedTicket(null)} className="text-slate-400 hover:text-white text-xs">
                      Close
                    </button>
                  </div>

                  <div className="flex-1 overflow-y-auto space-y-3">
                    {selectedTicket.messages?.map((m: any) => (
                      <div key={m.id} className="p-3 bg-slate-950 border border-slate-800 rounded-lg text-xs space-y-1">
                        <div className="flex justify-between font-bold text-[11px]">
                          <span>{m.sender_name} ({m.sender_role})</span>
                          <span className="text-slate-500 font-normal">{new Date(m.created_at).toLocaleString()}</span>
                        </div>
                        <p className="text-slate-300 whitespace-pre-wrap">{m.content}</p>
                      </div>
                    ))}
                  </div>

                  <form onSubmit={handleReplyTicket} className="pt-2 border-t border-slate-800 flex gap-2">
                    <input
                      type="text"
                      required
                      value={ticketReply}
                      onChange={(e) => setTicketReply(e.target.value)}
                      placeholder="Type official administrative reply..."
                      className="flex-1 bg-slate-950 border border-slate-800 rounded px-3 py-2 text-xs text-white"
                    />
                    <button type="submit" className="px-4 py-2 bg-amber-500 text-slate-950 font-bold text-xs rounded">
                      Send Reply
                    </button>
                  </form>
                </div>
              </div>
            )}
          </div>
        )}

        {/* SECTION 8: ANNOUNCEMENTS */}
        {activeSection === 'announcements' && (
          <div className="space-y-6 max-w-2xl">
            <div>
              <h1 className="text-2xl font-bold text-white tracking-tight">Global Announcements Banner</h1>
              <p className="text-xs text-slate-400 mt-1">Broadcast scheduled maintenance or platform notices to all users.</p>
            </div>

            <form onSubmit={handleSaveAnnouncements} className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Announcement Content</label>
                <textarea
                  rows={4}
                  value={announcementText}
                  onChange={(e) => setAnnouncementText(e.target.value)}
                  placeholder="e.g. Scheduled maintenance: Global Anycast edge nodes will be optimized on Sunday at 02:00 UTC."
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs text-white"
                ></textarea>
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="annActive"
                  checked={announcementActive}
                  onChange={(e) => setAnnouncementActive(e.target.checked)}
                  className="rounded border-slate-700 bg-slate-950 text-amber-500"
                />
                <label htmlFor="annActive" className="text-xs text-slate-300">
                  Publish announcement banner live on all platform pages
                </label>
              </div>

              <button type="submit" className="px-4 py-2 bg-amber-500 text-slate-950 font-bold text-xs rounded-lg">
                Save Announcement
              </button>
            </form>
          </div>
        )}

        {/* SECTION 9: SEO & METADATA */}
        {activeSection === 'seo' && (
          <div className="space-y-6 max-w-2xl">
            <div>
              <h1 className="text-2xl font-bold text-white tracking-tight">SEO & Search Crawler Settings</h1>
              <p className="text-xs text-slate-400 mt-1">Customize global meta tags, OpenGraph cards, and robots.txt.</p>
            </div>

            <form onSubmit={handleSaveSEO} className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Global Meta Title</label>
                <input
                  type="text"
                  value={seoTitle}
                  onChange={(e) => setSeoTitle(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2.5 text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Meta Description</label>
                <textarea
                  rows={3}
                  value={seoDesc}
                  onChange={(e) => setSeoDesc(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2.5 text-xs text-white"
                ></textarea>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">robots.txt Directives</label>
                <textarea
                  rows={5}
                  value={seoRobots}
                  onChange={(e) => setSeoRobots(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2.5 text-xs text-white font-mono"
                ></textarea>
              </div>

              <button type="submit" className="px-4 py-2 bg-amber-500 text-slate-950 font-bold text-xs rounded-lg">
                Save SEO Configuration
              </button>
            </form>
          </div>
        )}

        {/* SECTION 10: WEBSITE SETTINGS */}
        {activeSection === 'settings' && (
          <div className="space-y-6 max-w-2xl">
            <div>
              <h1 className="text-2xl font-bold text-white tracking-tight">Official Website Identity & Contact</h1>
              <p className="text-xs text-slate-400 mt-1">Manage brand title, official email, and WhatsApp contact phone.</p>
            </div>

            <form onSubmit={handleSaveWebsite} className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Website Brand Name</label>
                <input
                  type="text"
                  value={siteName}
                  onChange={(e) => setSiteName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Official Contact Email</label>
                <input
                  type="email"
                  value={siteEmail}
                  onChange={(e) => setSiteEmail(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-xs text-white font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Official WhatsApp Number</label>
                <input
                  type="text"
                  value={siteWhatsapp}
                  onChange={(e) => setSiteWhatsapp(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-xs text-white font-mono"
                />
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="siteMaint"
                  checked={siteMaintenance}
                  onChange={(e) => setSiteMaintenance(e.target.checked)}
                  className="rounded border-slate-700 bg-slate-950 text-amber-500"
                />
                <label htmlFor="siteMaint" className="text-xs text-slate-300">
                  Enable Platform Maintenance Mode
                </label>
              </div>

              <button type="submit" className="px-4 py-2 bg-amber-500 text-slate-950 font-bold text-xs rounded-lg">
                Save Website Settings
              </button>
            </form>
          </div>
        )}

        {/* SECTION 11: SECURITY & ACTIVITY LOGS */}
        {activeSection === 'logs' && (
          <div className="space-y-6">
            <div>
              <h1 className="text-2xl font-bold text-white tracking-tight">Security Audit & Activity Logs</h1>
              <p className="text-xs text-slate-400 mt-1">Audit trail of all administrative and tenant actions with IP records.</p>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden font-mono text-xs">
              <div className="overflow-x-auto w-full table-responsive-container">
                <table className="w-full text-left text-slate-300 min-w-[620px]">
                  <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 font-sans font-semibold">
                    <tr>
                      <th className="py-3 px-4">Action</th>
                      <th className="py-3 px-4">Actor</th>
                      <th className="py-3 px-4">Resource</th>
                      <th className="py-3 px-4">IP Address</th>
                      <th className="py-3 px-4">Timestamp</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {activityLogs.map((log) => (
                      <tr key={log.id}>
                        <td className="py-3 px-4 font-bold text-amber-400">{log.action}</td>
                        <td className="py-3 px-4 font-sans text-white">{log.actor_email || 'System'}</td>
                        <td className="py-3 px-4 text-cyan-300">{log.resource_type} ({log.resource_id?.slice(0, 10) || '-'})</td>
                        <td className="py-3 px-4 text-slate-500">{log.ip_address || '127.0.0.1'}</td>
                        <td className="py-3 px-4 text-slate-500 font-sans whitespace-nowrap">{new Date(log.created_at).toLocaleString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* SECTION 12: SYSTEM HEALTH & BACKUPS */}
        {activeSection === 'system' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-white tracking-tight">System Health & Database Backups</h1>
                <p className="text-xs text-slate-400 mt-1">Runtime memory, process telemetry, and database JSON export.</p>
              </div>
              <a
                href="/api/admin/backup/export"
                target="_blank"
                className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-lg transition-colors flex items-center gap-1.5"
              >
                <Download className="w-4 h-4" />
                Export Database Backup
              </a>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-1">
                <span className="text-xs text-slate-400 font-semibold uppercase">Uptime</span>
                <div className="text-2xl font-bold text-white font-mono">
                  {Math.round((systemHealth?.uptimeSeconds || 0) / 60)} minutes
                </div>
              </div>
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-1">
                <span className="text-xs text-slate-400 font-semibold uppercase">Heap Memory</span>
                <div className="text-2xl font-bold text-cyan-400 font-mono">
                  {systemHealth?.processMemory?.heapUsedMb || 0} MB
                </div>
              </div>
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-1">
                <span className="text-xs text-slate-400 font-semibold uppercase">Node Runtime</span>
                <div className="text-2xl font-bold text-white font-mono">
                  {systemHealth?.nodeVersion || 'v22'}
                </div>
              </div>
            </div>

            {/* EXTERNAL SERVICES STATUS */}
            <div className="space-y-4 pt-2">
              <div className="border-t border-slate-800/80 pt-6">
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <Globe className="w-5 h-5 text-amber-400" />
                  External Services & Integration Status
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  Optional third-party services operate in zero-dependency built-in fallback modes until credentials are provided.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {systemHealth?.integrations?.map((svc: any) => (
                  <div key={svc.id} className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3 flex flex-col justify-between">
                    <div className="space-y-2">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <h3 className="text-sm font-bold text-white">{svc.name}</h3>
                          <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-slate-950 text-slate-400 border border-slate-800">
                            {svc.category}
                          </span>
                        </div>
                        <span className={`text-[11px] font-bold px-2.5 py-1 rounded-full flex items-center gap-1.5 ${
                          svc.status === 'Configured'
                            ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/80'
                            : 'bg-slate-950 text-slate-400 border border-slate-800'
                        }`}>
                          <span className={`w-1.5 h-1.5 rounded-full ${svc.status === 'Configured' ? 'bg-emerald-400' : 'bg-slate-500'}`}></span>
                          {svc.status}
                        </span>
                      </div>

                      <div className="text-xs text-slate-300 font-mono bg-slate-950/70 p-2.5 rounded-lg border border-slate-800/60">
                        <span className="text-slate-500 block text-[10px] uppercase font-sans font-semibold">Active Operational Driver</span>
                        {svc.activeDriver}
                      </div>

                      <p className="text-xs text-slate-400 leading-relaxed">
                        {svc.description}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-slate-800/60 text-[11px] text-slate-500 font-mono">
                      <span className="text-slate-400 font-semibold font-sans">Variables: </span>
                      {svc.requiredVars?.join(', ')}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* SECTION: DEDICATED EXTERNAL SERVICES TAB */}
        {activeSection === 'integrations' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-white tracking-tight">External Services & Credentials Status</h1>
                <p className="text-xs text-slate-400 mt-1">
                  Status of third-party cloud infrastructure, payments, and communications.
                </p>
              </div>
              <button
                onClick={() => fetchSectionData('integrations')}
                className="p-2 text-slate-400 hover:text-white bg-slate-900 border border-slate-800 rounded-lg"
              >
                <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {systemHealth?.integrations?.map((svc: any) => (
                <div key={svc.id} className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3 flex flex-col justify-between">
                  <div className="space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h3 className="text-sm font-bold text-white">{svc.name}</h3>
                        <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-slate-950 text-slate-400 border border-slate-800">
                          {svc.category}
                        </span>
                      </div>
                      <span className={`text-[11px] font-bold px-2.5 py-1 rounded-full flex items-center gap-1.5 ${
                        svc.status === 'Configured'
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/80'
                          : 'bg-slate-950 text-slate-400 border border-slate-800'
                      }`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${svc.status === 'Configured' ? 'bg-emerald-400' : 'bg-slate-500'}`}></span>
                        {svc.status}
                      </span>
                    </div>

                    <div className="text-xs text-slate-300 font-mono bg-slate-950/70 p-2.5 rounded-lg border border-slate-800/60">
                      <span className="text-slate-500 block text-[10px] uppercase font-sans font-semibold">Active Operational Driver</span>
                      {svc.activeDriver}
                    </div>

                    <p className="text-xs text-slate-400 leading-relaxed">
                      {svc.description}
                    </p>
                  </div>

                  <div className="pt-2 border-t border-slate-800/60 text-[11px] text-slate-500 font-mono">
                    <span className="text-slate-400 font-semibold font-sans">Variables: </span>
                    {svc.requiredVars?.join(', ')}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* SECTION 13: ADMIN PROFILE & SECURITY */}
        {activeSection === 'profile' && (
          <div className="space-y-6 max-w-2xl">
            <div>
              <h1 className="text-2xl font-bold text-white tracking-tight">Administrator Security Credentials</h1>
              <p className="text-xs text-slate-400 mt-1">Update your primary administrative email, profile name, and password.</p>
            </div>

            <form onSubmit={handleSaveAdminProfile} className="bg-slate-900 border border-amber-900/40 rounded-2xl p-6 space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Administrator Name</label>
                <input
                  type="text"
                  required
                  value={adminName}
                  onChange={(e) => setAdminName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Administrator Email</label>
                <input
                  type="email"
                  required
                  value={adminEmail}
                  onChange={(e) => setAdminEmail(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-xs text-white font-mono"
                />
              </div>

              <div className="pt-2 border-t border-slate-800 space-y-3">
                <div className="text-xs font-bold text-amber-300">Change Administrator Password</div>
                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1">Current Password (Required)</label>
                  <input
                    type="password"
                    value={adminCurrentPass}
                    onChange={(e) => setAdminCurrentPass(e.target.value)}
                    placeholder="Enter current password to verify"
                    className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1">New Password (min 8 characters)</label>
                  <input
                    type="password"
                    value={adminNewPass}
                    onChange={(e) => setAdminNewPass(e.target.value)}
                    placeholder="Leave empty if not changing"
                    className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-xs text-white"
                  />
                </div>
              </div>

              <button type="submit" className="px-4 py-2 bg-amber-500 text-slate-950 font-bold text-xs rounded-lg">
                Update Administrator Credentials
              </button>
            </form>
          </div>
        )}
      </main>

      {/* Inspected Deployment Build Log Modal */}
      {inspectedDep && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-white text-sm">Deployment Audit Logs: {inspectedDep.id}</h3>
              <button onClick={() => setInspectedDep(null)} className="text-slate-400 hover:text-white text-xs">
                Close
              </button>
            </div>
            <pre className="bg-slate-950 p-4 rounded-xl font-mono text-xs text-slate-300 max-h-96 overflow-y-auto whitespace-pre-wrap border border-slate-800">
              {inspectedDep.build_logs || 'No log details recorded.'}
            </pre>
          </div>
        </div>
      )}

      {/* Payment Action Modal (Approve / Reject with Note) */}
      {paymentActionModal && paymentActionModal.payment && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                {paymentActionModal.type === 'approve' ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                ) : (
                  <XCircle className="w-5 h-5 text-rose-400" />
                )}
                <h3 className="font-bold text-white text-sm">
                  {paymentActionModal.type === 'approve' ? 'Approve Customer Payment' : 'Reject Payment Submission'}
                </h3>
              </div>
              <button
                onClick={() => setPaymentActionModal(null)}
                className="text-slate-400 hover:text-white text-xs"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Payment Summary */}
            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1.5 text-xs font-mono">
              <div className="flex justify-between">
                <span className="text-slate-400 font-sans">Customer:</span>
                <span className="text-white font-sans font-semibold">
                  {paymentActionModal.payment.user_name} ({paymentActionModal.payment.user_email})
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400 font-sans">Plan Upgrade:</span>
                <span className="text-cyan-400 font-semibold">{paymentActionModal.payment.plan_name} ({paymentActionModal.payment.billing_interval})</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400 font-sans">Amount:</span>
                <span className="text-emerald-400 font-bold">{paymentActionModal.payment.currency} {paymentActionModal.payment.amount}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400 font-sans">Provider / Method:</span>
                <span className="text-white uppercase">{paymentActionModal.payment.payment_method}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400 font-sans">Transaction / Ref ID:</span>
                <span className="text-white font-bold select-all">{paymentActionModal.payment.transaction_id}</span>
              </div>
            </div>

            <form onSubmit={handleConfirmPaymentAction} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {paymentActionModal.type === 'approve'
                    ? 'Admin Note (Optional - visible to tenant & logged in audit history):'
                    : 'Rejection Reason (Required - explains issue to customer):'}
                </label>
                <textarea
                  rows={3}
                  required={paymentActionModal.type === 'reject'}
                  value={paymentActionModal.note}
                  onChange={(e) =>
                    setPaymentActionModal({
                      ...paymentActionModal,
                      note: e.target.value
                    })
                  }
                  placeholder={
                    paymentActionModal.type === 'approve'
                      ? 'e.g. Verified transaction on JazzCash/Bank portal.'
                      : 'e.g. Transaction ID was not found on receiving account statement. Please re-check.'
                  }
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-white"
                ></textarea>
              </div>

              {paymentActionModal.type === 'approve' ? (
                <p className="text-[11px] text-emerald-400/90 leading-relaxed bg-emerald-950/30 p-2 rounded border border-emerald-900/50">
                  Approving this payment will automatically upgrade the user account, raise their storage and domain quotas, record an audit event, and notify them immediately.
                </p>
              ) : (
                <p className="text-[11px] text-rose-400/90 leading-relaxed bg-rose-950/30 p-2 rounded border border-rose-900/50">
                  Rejecting will NOT activate the plan. The customer will be notified of the rejection reason so they can correct the reference ID or contact support.
                </p>
              )}

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setPaymentActionModal(null)}
                  className="px-3 py-1.5 text-slate-400 hover:text-white text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className={`px-4 py-2 text-white font-bold text-xs rounded-lg shadow-lg flex items-center gap-1.5 ${
                    paymentActionModal.type === 'approve'
                      ? 'bg-emerald-600 hover:bg-emerald-500'
                      : 'bg-rose-600 hover:bg-rose-500'
                  }`}
                >
                  {paymentActionModal.type === 'approve' ? (
                    <>
                      <Check className="w-4 h-4" />
                      <span>Confirm & Upgrade Plan</span>
                    </>
                  ) : (
                    <>
                      <X className="w-4 h-4" />
                      <span>Confirm Rejection</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Payment Receipt Screenshot Viewer Modal */}
      {selectedReceipt && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full p-6 space-y-4 shadow-2xl flex flex-col max-h-[90vh]">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Eye className="w-5 h-5 text-cyan-400" />
                <h3 className="font-bold text-white text-sm">Customer Payment Receipt / Proof of Transfer</h3>
              </div>
              <button
                onClick={() => setSelectedReceipt(null)}
                className="text-slate-400 hover:text-white text-xs p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-auto flex items-center justify-center p-2 bg-slate-950 rounded-xl border border-slate-800">
              {selectedReceipt.endsWith('.pdf') ? (
                <div className="text-center p-6 space-y-3">
                  <p className="text-xs text-slate-300">This receipt is a PDF document.</p>
                  <a
                    href={selectedReceipt}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold rounded-lg"
                  >
                    <ExternalLink className="w-4 h-4" />
                    Open PDF in New Window
                  </a>
                </div>
              ) : (
                <img
                  src={selectedReceipt}
                  alt="Payment Receipt"
                  className="max-h-[70vh] w-auto object-contain rounded"
                />
              )}
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-xs">
              <a
                href={selectedReceipt}
                target="_blank"
                rel="noopener noreferrer"
                className="text-cyan-400 hover:underline flex items-center gap-1"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                Open original file in new window
              </a>
              <button
                onClick={() => setSelectedReceipt(null)}
                className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Floating Toast Notification */}
      {toastMessage && (
        <div className={`fixed bottom-6 right-6 z-50 px-4 py-3 rounded-xl border shadow-2xl flex items-center gap-3 text-xs font-semibold transition-all ${
          toastMessage.type === 'success'
            ? 'bg-emerald-950 text-emerald-300 border-emerald-800'
            : 'bg-rose-950 text-rose-300 border-rose-800'
        }`}>
          {toastMessage.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
          ) : (
            <AlertTriangle className="w-4 h-4 text-rose-400 flex-shrink-0" />
          )}
          <span>{toastMessage.text}</span>
          <button
            onClick={() => setToastMessage(null)}
            className="text-slate-400 hover:text-white p-0.5 ml-2"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}
    </div>
  );
};
