import React, { useState } from 'react';
import { ChevronDown, ChevronUp, HelpCircle } from 'lucide-react';

interface FAQProps {
  onNavigate: (path: string) => void;
}

export const FAQ: React.FC<FAQProps> = ({ onNavigate }) => {
  const [openIdx, setOpenIdx] = useState<number | null>(0);

  const faqs = [
    {
      q: 'How does deployment on StrataFlux Cloud work?',
      a: 'Deploying is as simple as dragging and dropping a ZIP file containing your static website assets (HTML, CSS, JS, images). Our edge ingestion engine unpacks the archive, scans for security hazards, resolves your root index.html, and broadcasts the deployment across our Anycast edge nodes in seconds.'
    },
    {
      q: 'Can I host server-side applications (Node.js, Python, PHP)?',
      a: 'StrataFlux is dedicated to static websites, SPAs (Single Page Applications like React, Vue, Svelte), and JAMstack architectures. Server-side scripts (.php, .py, etc.) are strictly forbidden and quarantined. If your site requires backend APIs, you can connect external API endpoints, serverless functions, or headless CMS backends.'
    },
    {
      q: 'How do custom domains and SSL certificates work?',
      a: 'You can add any custom domain (e.g., example.com or app.example.com) to your project in the Domains tab. Simply add a CNAME record pointing to our Anycast edge domain. Our system automatically validates the DNS records and provisions an edge TLS 1.3 certificate.'
    },
    {
      q: 'What happens if I make a bad deployment? Can I rollback?',
      a: 'Yes! Every deployment creates an immutable, timestamped revision. If you push an unwanted change or encounter a bug, you can click "Rollback" on any prior deployment in your project history to immediately point your live URL back to that version with zero downtime.'
    },
    {
      q: 'How does your privacy-preserving analytics work?',
      a: 'Unlike third-party trackers that drop tracking cookies and invade visitor privacy, StrataFlux computes analytics server-side at the edge. We combine the visitor IP address with a daily salted secret and hash it using SHA-256. This lets us measure unique daily visitors without ever storing or sharing personal data.'
    },
    {
      q: 'Can I automate deployments from GitHub or CI/CD pipelines?',
      a: 'Yes. StrataFlux provides a REST API. You can generate an API Bearer token in your user settings and use standard cURL or GitHub Actions steps to upload your build artifacts automatically on every git push.'
    },
    {
      q: 'What is the maximum ZIP upload file size?',
      a: 'The Starter (Free) plan supports ZIP archives up to 50 MB per deployment. Pro and Business tiers support larger archives up to 250 MB. Contact support if your media assets require custom storage quotas.'
    }
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 space-y-12">
      <div className="text-center space-y-4 max-w-2xl mx-auto">
        <div className="text-cyan-400 font-semibold text-xs tracking-wider uppercase">Answers to Common Questions</div>
        <h1 className="text-4xl sm:text-5xl font-extrabold text-white tracking-tight">
          Frequently Asked Questions
        </h1>
        <p className="text-slate-400 text-lg">
          Everything you need to know about StrataFlux deployments, architecture, domains, and security.
        </p>
      </div>

      <div className="space-y-4">
        {faqs.map((item, i) => {
          const isOpen = openIdx === i;
          return (
            <div
              key={i}
              className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden transition-colors hover:border-slate-700"
            >
              <button
                onClick={() => setOpenIdx(isOpen ? null : i)}
                className="w-full text-left p-5 sm:p-6 flex items-center justify-between gap-4 focus:outline-none"
              >
                <span className="font-semibold text-white text-base sm:text-lg">{item.q}</span>
                {isOpen ? (
                  <ChevronUp className="w-5 h-5 text-cyan-400 flex-shrink-0" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-slate-400 flex-shrink-0" />
                )}
              </button>

              {isOpen && (
                <div className="px-5 sm:px-6 pb-6 text-sm text-slate-300 leading-relaxed border-t border-slate-800/60 pt-4">
                  {item.a}
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-8 text-center space-y-4">
        <h2 className="text-xl font-bold text-white">Have a specific question not covered here?</h2>
        <p className="text-sm text-slate-400 max-w-md mx-auto">
          Our team is available 24/7 on WhatsApp and email to assist you with custom architectural questions.
        </p>
        <button
          onClick={() => onNavigate('/contact-us')}
          className="px-6 py-2.5 bg-cyan-400 hover:bg-cyan-300 text-slate-950 text-sm font-semibold rounded-lg transition-colors"
        >
          Contact Support Team
        </button>
      </div>
    </div>
  );
};
