import React, { useState, useEffect } from 'react';
import { CheckCircle2, Clock, Activity, AlertCircle, RefreshCw } from 'lucide-react';

interface StatusProps {
  onNavigate: (path: string) => void;
}

export const Status: React.FC<StatusProps> = ({ onNavigate }) => {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const fetchStatus = () => {
    setLoading(true);
    fetch('/api/public/status')
      .then(res => res.json())
      .then(d => setData(d))
      .catch(() => {})
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchStatus();
  }, []);

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 space-y-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-8">
        <div>
          <div className="text-cyan-400 font-semibold text-xs tracking-wider uppercase">Live Platform Telemetry</div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mt-1">
            System Operational Status
          </h1>
        </div>
        <button
          onClick={fetchStatus}
          disabled={loading}
          className="self-start sm:self-auto flex items-center gap-2 px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-900 border border-slate-800 rounded-lg hover:bg-slate-800 transition-colors"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          Refresh Status
        </button>
      </div>

      {/* Main Status Badge Banner */}
      <div className="bg-emerald-950/30 border border-emerald-800/60 rounded-2xl p-6 flex items-center gap-4">
        <div className="w-12 h-12 rounded-xl bg-emerald-950 border border-emerald-800 flex items-center justify-center text-emerald-400 flex-shrink-0">
          <CheckCircle2 className="w-7 h-7" />
        </div>
        <div>
          <h2 className="text-lg font-bold text-white">All Systems Fully Operational</h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Global Anycast edge nodes, build pipelines, and DNS resolution are serving at 100% capacity.
          </p>
        </div>
      </div>

      {/* Systems Breakdown */}
      <div className="space-y-4">
        <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider">Subsystem Health</h3>
        <div className="bg-slate-900 border border-slate-800 rounded-xl divide-y divide-slate-800 overflow-hidden">
          {data?.systems?.map((sys: any, idx: number) => (
            <div key={idx} className="p-4 sm:px-6 flex items-center justify-between gap-4 text-xs sm:text-sm">
              <div className="flex items-center gap-3">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
                <span className="font-medium text-white">{sys.name}</span>
              </div>
              <div className="flex items-center gap-6 font-mono text-xs">
                <span className="text-slate-500 hidden sm:inline">{sys.latencyMs}ms latency</span>
                <span className="text-slate-400">{sys.uptime} uptime</span>
                <span className="text-emerald-400 font-semibold uppercase">{sys.status}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Past Incidents */}
      <div className="space-y-4">
        <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider">Recent Activity & Maintenance</h3>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-4">
          {data?.incidents?.map((inc: any) => (
            <div key={inc.id} className="space-y-1.5 border-b border-slate-800/80 pb-4 last:border-0 last:pb-0">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-white">{inc.title}</span>
                <span className="text-slate-500">{inc.date}</span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">{inc.description}</p>
              <div className="text-[11px] font-mono text-emerald-400 font-medium">Status: {inc.status}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
