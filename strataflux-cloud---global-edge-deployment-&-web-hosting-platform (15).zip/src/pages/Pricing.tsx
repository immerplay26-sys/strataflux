import React, { useState, useEffect } from 'react';
import { Check, Zap, Sparkles, Building2, HelpCircle, CreditCard, Wallet, Send, Smartphone, ShieldCheck } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Plan } from '../types';

interface PricingProps {
  onNavigate: (path: string) => void;
}

export const Pricing: React.FC<PricingProps> = ({ onNavigate }) => {
  const { user } = useAuth();
  const [isYearly, setIsYearly] = useState(false);
  const [plans, setPlans] = useState<Plan[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/billing/plans')
      .then(res => res.json())
      .then(data => {
        if (data.plans && data.plans.length > 0) {
          setPlans(data.plans);
        }
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const handlePlanAction = (planId: string) => {
    const targetInterval = isYearly ? 'yearly' : 'monthly';
    if (!user) {
      onNavigate(`/register?plan=${planId}&interval=${targetInterval}`);
      return;
    }
    onNavigate(`/dashboard/billing?plan=${planId}&interval=${targetInterval}`);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 space-y-16">
      <div className="text-center space-y-4 max-w-2xl mx-auto">
        <div className="text-cyan-400 font-semibold text-xs tracking-wider uppercase">Transparent Pricing</div>
        <h1 className="text-4xl sm:text-5xl font-extrabold text-white tracking-tight">
          Simple plans that scale with your traffic.
        </h1>
        <p className="text-slate-400 text-lg">
          No hidden fees or unexpected overage bills. Upgrade or downgrade anytime with a single click.
        </p>

        {/* Billing interval toggle */}
        <div className="pt-4 flex items-center justify-center gap-3">
          <span className={`text-sm ${!isYearly ? 'text-white font-semibold' : 'text-slate-400'}`}>Monthly billing</span>
          <button
            onClick={() => setIsYearly(!isYearly)}
            className="w-12 h-6 bg-slate-800 rounded-full p-1 transition-colors relative border border-slate-700"
          >
            <div
              className={`w-4 h-4 rounded-full bg-cyan-400 transition-transform ${
                isYearly ? 'translate-x-6' : 'translate-x-0'
              }`}
            ></div>
          </button>
          <span className={`text-sm flex items-center gap-1.5 ${isYearly ? 'text-white font-semibold' : 'text-slate-400'}`}>
            <span>Annual billing</span>
            <span className="text-[11px] bg-emerald-950 text-emerald-300 border border-emerald-800 px-1.5 py-0.5 rounded font-medium">Save 20%</span>
          </span>
        </div>
      </div>

      {/* Plan Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-stretch">
        {plans.map((p) => {
          const isPopular = p.id === 'pro';
          const price = isYearly ? Math.round(p.price_yearly / 12) : p.price_monthly;
          const isCurrentPlan = user?.plan_tier === p.id;

          return (
            <div
              key={p.id}
              className={`relative bg-slate-900 rounded-2xl p-8 flex flex-col justify-between border transition-all ${
                isPopular
                  ? 'border-cyan-500 shadow-xl shadow-cyan-950/50 bg-gradient-to-b from-slate-900 via-slate-900 to-cyan-950/20'
                  : 'border-slate-800 hover:border-slate-700'
              }`}
            >
              {isPopular && (
                <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-cyan-500 text-slate-950 text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-full">
                  Most Popular
                </div>
              )}

              <div className="space-y-6">
                <div>
                  <h3 className="text-xl font-bold text-white">{p.name}</h3>
                  <div className="mt-4 flex items-baseline gap-1">
                    <span className="text-4xl sm:text-5xl font-extrabold text-white">${price}</span>
                    <span className="text-slate-400 text-sm">/month</span>
                  </div>
                  {isYearly && p.price_yearly > 0 && (
                    <p className="text-xs text-slate-400 mt-1 font-mono">Billed annually (${p.price_yearly}/yr)</p>
                  )}
                </div>

                <div className="pt-4 border-t border-slate-800 space-y-3">
                  <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Plan Highlights</div>
                  <div className="grid grid-cols-2 gap-2 text-xs font-mono text-slate-300">
                    <div className="bg-slate-950 p-2 rounded border border-slate-800/60">
                      <div className="text-slate-500">Projects</div>
                      <div className="font-bold text-white">{p.max_projects} active</div>
                    </div>
                    <div className="bg-slate-950 p-2 rounded border border-slate-800/60">
                      <div className="text-slate-500">Custom Domains</div>
                      <div className="font-bold text-white">{p.max_custom_domains} domains</div>
                    </div>
                    <div className="bg-slate-950 p-2 rounded border border-slate-800/60">
                      <div className="text-slate-500">Storage</div>
                      <div className="font-bold text-white">{p.storage_limit_mb >= 1000 ? `${p.storage_limit_mb / 1000} GB` : `${p.storage_limit_mb} MB`}</div>
                    </div>
                    <div className="bg-slate-950 p-2 rounded border border-slate-800/60">
                      <div className="text-slate-500">Bandwidth</div>
                      <div className="font-bold text-white">{p.bandwidth_limit_gb} GB/mo</div>
                    </div>
                  </div>

                  <ul className="space-y-2.5 pt-4">
                    {p.features.map((f, i) => (
                      <li key={i} className="flex items-start gap-2.5 text-xs text-slate-300">
                        <Check className="w-4 h-4 text-cyan-400 flex-shrink-0 mt-0.5" />
                        <span>{f}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="pt-8">
                <button
                  onClick={() => handlePlanAction(p.id)}
                  disabled={isCurrentPlan}
                  className={`w-full py-3 px-4 rounded-xl text-sm font-semibold transition-all ${
                    isCurrentPlan
                      ? 'bg-slate-800 text-slate-400 cursor-default'
                      : isPopular
                      ? 'bg-cyan-400 hover:bg-cyan-300 text-slate-950 shadow-md'
                      : 'bg-slate-800 hover:bg-slate-700 text-white'
                  }`}
                >
                  {isCurrentPlan ? 'Current Active Tier' : p.price_monthly === 0 ? 'Deploy Free' : 'Select Plan'}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Feature Comparison Table */}
      <div className="pt-12 space-y-6">
        <h2 className="text-2xl font-bold text-white text-center">Comprehensive Tier Comparison</h2>
        <div className="overflow-x-auto border border-slate-800 rounded-xl bg-slate-900/60">
          <table className="w-full text-left text-sm text-slate-300">
            <thead className="bg-slate-950 text-xs uppercase font-semibold text-slate-400 border-b border-slate-800">
              <tr>
                <th className="py-4 px-6">Feature</th>
                <th className="py-4 px-6">Starter (Free)</th>
                <th className="py-4 px-6 text-cyan-400">Pro Developer</th>
                <th className="py-4 px-6">Enterprise Scale</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-xs sm:text-sm">
              <tr>
                <td className="py-3.5 px-6 font-medium text-white">ZIP & Folder Upload</td>
                <td className="py-3.5 px-6 text-emerald-400 font-semibold">Included</td>
                <td className="py-3.5 px-6 text-emerald-400 font-semibold">Included</td>
                <td className="py-3.5 px-6 text-emerald-400 font-semibold">Included</td>
              </tr>
              <tr>
                <td className="py-3.5 px-6 font-medium text-white">Automated Edge SSL Certificates</td>
                <td className="py-3.5 px-6 text-emerald-400 font-semibold">TLS 1.3</td>
                <td className="py-3.5 px-6 text-emerald-400 font-semibold">TLS 1.3 + Wildcard</td>
                <td className="py-3.5 px-6 text-emerald-400 font-semibold">Custom Certificates</td>
              </tr>
              <tr>
                <td className="py-3.5 px-6 font-medium text-white">Immutable Rollbacks</td>
                <td className="py-3.5 px-6">3 revisions</td>
                <td className="py-3.5 px-6 text-cyan-300 font-semibold">Unlimited</td>
                <td className="py-3.5 px-6 text-cyan-300 font-semibold">Unlimited</td>
              </tr>
              <tr>
                <td className="py-3.5 px-6 font-medium text-white">Analytics History Retention</td>
                <td className="py-3.5 px-6">7 days</td>
                <td className="py-3.5 px-6 text-cyan-300 font-semibold">90 days</td>
                <td className="py-3.5 px-6 text-cyan-300 font-semibold">365 days + Raw CSV</td>
              </tr>
              <tr>
                <td className="py-3.5 px-6 font-medium text-white">Support SLA</td>
                <td className="py-3.5 px-6">Ticket Support</td>
                <td className="py-3.5 px-6 text-cyan-300 font-semibold">Priority Email & Ticket</td>
                <td className="py-3.5 px-6 text-cyan-300 font-semibold">24/7 Dedicated WhatsApp & SLA</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* SUPPORTED PAYMENT METHODS SHOWCASE */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-8 space-y-6">
        <div className="text-center space-y-2 max-w-xl mx-auto">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-cyan-950 text-cyan-300 border border-cyan-800">
            <ShieldCheck className="w-4 h-4 text-cyan-400" />
            <span>Multi-Provider Global & Local Checkout</span>
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight">Flexible Payment Options for Every Developer</h2>
          <p className="text-xs text-slate-400">
            Select your preferred payment provider during checkout. We support major global card networks, international wallets, and direct local Pakistan mobile accounts.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 pt-2">
          {/* Stripe */}
          <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-2 hover:border-sky-500/50 transition-all">
            <div className="w-8 h-8 rounded-lg bg-sky-950/60 border border-sky-800/80 flex items-center justify-center text-sky-400">
              <CreditCard className="w-4 h-4" />
            </div>
            <div className="font-bold text-sm text-white">Stripe</div>
            <p className="text-[11px] text-slate-400 leading-snug">
              Visa, Mastercard, American Express, and Apple Pay with automated activation.
            </p>
          </div>

          {/* PayPal */}
          <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-2 hover:border-indigo-500/50 transition-all">
            <div className="w-8 h-8 rounded-lg bg-indigo-950/60 border border-indigo-800/80 flex items-center justify-center text-indigo-400">
              <Wallet className="w-4 h-4" />
            </div>
            <div className="font-bold text-sm text-white">PayPal</div>
            <p className="text-[11px] text-slate-400 leading-snug">
              Instant worldwide checkout using your PayPal balance or linked bank accounts.
            </p>
          </div>

          {/* Payoneer */}
          <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-2 hover:border-amber-500/50 transition-all">
            <div className="w-8 h-8 rounded-lg bg-amber-950/60 border border-amber-800/80 flex items-center justify-center text-amber-400">
              <Send className="w-4 h-4" />
            </div>
            <div className="font-bold text-sm text-white">Payoneer</div>
            <p className="text-[11px] text-slate-400 leading-snug">
              Global transfers and account-to-account payments with rapid reference verification.
            </p>
          </div>

          {/* JazzCash */}
          <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-2 hover:border-orange-500/50 transition-all">
            <div className="w-8 h-8 rounded-lg bg-orange-950/60 border border-orange-800/80 flex items-center justify-center text-orange-400">
              <Smartphone className="w-4 h-4" />
            </div>
            <div className="font-bold text-sm text-white">JazzCash</div>
            <p className="text-[11px] text-slate-400 leading-snug">
              Pakistan mobile wallet payment via JazzCash App or *786# with TID confirmation.
            </p>
          </div>

          {/* Easypaisa */}
          <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-2 hover:border-emerald-500/50 transition-all">
            <div className="w-8 h-8 rounded-lg bg-emerald-950/60 border border-emerald-800/80 flex items-center justify-center text-emerald-400">
              <Smartphone className="w-4 h-4" />
            </div>
            <div className="font-bold text-sm text-white">Easypaisa</div>
            <p className="text-[11px] text-slate-400 leading-snug">
              Pakistan mobile wallet payment via Easypaisa App or *786# with TRX confirmation.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
