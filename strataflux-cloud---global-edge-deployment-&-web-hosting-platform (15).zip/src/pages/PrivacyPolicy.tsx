import React from 'react';

interface PolicyProps {
  onNavigate: (path: string) => void;
}

export const PrivacyPolicy: React.FC<PolicyProps> = ({ onNavigate }) => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 space-y-10 text-slate-300">
      <div className="border-b border-slate-800 pb-6 space-y-2">
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white">Privacy Policy</h1>
        <p className="text-xs text-slate-500 font-mono">Effective Date: September 2026 &middot; Version 2.4</p>
      </div>

      <div className="prose prose-invert prose-sm max-w-none space-y-6 text-sm leading-relaxed">
        <section className="space-y-3">
          <h2 className="text-lg font-bold text-white">1. Information We Collect</h2>
          <p>
            When you register an account on StrataFlux Cloud, we collect your name, email address, password hash, and plan preferences. When you deploy static web packages, we store the website assets (HTML, CSS, JavaScript, media files) necessary to serve your website.
          </p>
        </section>

        <section className="space-y-3">
          <h2 className="text-lg font-bold text-white">2. Edge Website Analytics & Zero-Cookie Policy</h2>
          <p>
            StrataFlux generates edge traffic statistics for deployed websites without collecting personally identifiable information. We do not use third-party advertising cookies. Visitor IP addresses are cryptographically hashed using SHA-256 with a daily rotating salt before aggregation, preventing reverse identification and ensuring compliance with GDPR, ePrivacy, and CCPA standards.
          </p>
        </section>

        <section className="space-y-3">
          <h2 className="text-lg font-bold text-white">3. How We Use Information</h2>
          <p>
            We use your account information to authenticate you, provide billing and subscription receipts, dispatch transactional notifications regarding your deployments and domain verification status, and enforce our Acceptable Use Policy.
          </p>
        </section>

        <section className="space-y-3">
          <h2 className="text-lg font-bold text-white">4. Data Isolation & Security</h2>
          <p>
            All uploaded user website files are stored in isolated per-project sandbox partitions. Passwords are salted and hashed using bcrypt. Access to the underlying administrative systems requires multi-tier cryptographic credentials.
          </p>
        </section>

        <section className="space-y-3">
          <h2 className="text-lg font-bold text-white">5. Your Data Rights</h2>
          <p>
            You retain full ownership of all code, assets, and content you deploy. You may update your account details, export your project data, or delete your projects and account at any time via your user dashboard settings.
          </p>
        </section>

        <section className="space-y-3">
          <h2 className="text-lg font-bold text-white">6. Official Data Controller Contact</h2>
          <p>
            For privacy inquiries, GDPR data deletion requests, or data processing agreements:
          </p>
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 font-mono text-xs text-slate-300">
            <div>Email: muhammadofficial356@gmail.com</div>
            <div>WhatsApp: +923199389323</div>
            <div>Platform: StrataFlux Cloud Technologies</div>
          </div>
        </section>
      </div>
    </div>
  );
};
