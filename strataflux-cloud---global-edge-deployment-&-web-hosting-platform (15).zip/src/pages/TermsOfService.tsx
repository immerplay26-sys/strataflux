import React from 'react';

interface TermsProps {
  onNavigate: (path: string) => void;
}

export const TermsOfService: React.FC<TermsProps> = ({ onNavigate }) => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 space-y-10 text-slate-300">
      <div className="border-b border-slate-800 pb-6 space-y-2">
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white">Terms of Service</h1>
        <p className="text-xs text-slate-500 font-mono">Last Updated: September 2026</p>
      </div>

      <div className="space-y-6 text-sm leading-relaxed">
        <section className="space-y-2">
          <h2 className="text-lg font-bold text-white">1. Agreement to Terms</h2>
          <p>
            By accessing or using StrataFlux Cloud ("the Service"), you agree to be bound by these Terms of Service. If you do not agree with any part of these terms, you may not access or use the platform.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-lg font-bold text-white">2. Permitted Use & Account Security</h2>
          <p>
            You are responsible for maintaining the confidentiality of your account credentials and for all activities that occur under your account. You agree not to upload any malicious code, phishing portals, copyright-infringing assets, or server exploitation tools.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-lg font-bold text-white">3. Subscriptions & Billing</h2>
          <p>
            Subscription fees for paid tiers (Pro, Business) are billed in advance on a recurring monthly or annual basis. You may cancel your subscription at any time via your dashboard billing settings.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-lg font-bold text-white">4. Availability & SLA</h2>
          <p>
            While StrataFlux Cloud targets 99.99% uptime across its global edge network, the service is provided "as is" and "as available". We reserve the right to perform scheduled maintenance and take down abusive deployments.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-lg font-bold text-white">5. Termination</h2>
          <p>
            We may terminate or suspend access to your account immediately, without prior notice or liability, for any breach of these Terms or our Acceptable Use Policy.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-lg font-bold text-white">6. Contact</h2>
          <p>
            Questions regarding these Terms should be sent to: <span className="text-cyan-400 font-mono">muhammadofficial356@gmail.com</span>
          </p>
        </section>
      </div>
    </div>
  );
};
