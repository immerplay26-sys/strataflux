import React, { useState } from 'react';
import { UploadCloud, Zap, Shield, Globe, ArrowRight, CheckCircle2, Terminal, Layers, RefreshCw, BarChart3, Lock } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface HomeProps {
  onNavigate: (path: string) => void;
}

export const Home: React.FC<HomeProps> = ({ onNavigate }) => {
  const { user } = useAuth();
  const [demoState, setDemoState] = useState<'idle' | 'extracting' | 'routing' | 'live'>('idle');
  const [demoProgress, setDemoProgress] = useState(0);

  const runDemoDeployment = () => {
    setDemoState('extracting');
    setDemoProgress(20);

    setTimeout(() => {
      setDemoProgress(60);
      setDemoState('routing');
    }, 900);

    setTimeout(() => {
      setDemoProgress(100);
      setDemoState('live');
    }, 1800);
  };

  const resetDemo = () => {
    setDemoState('idle');
    setDemoProgress(0);
  };

  return (
    <div className="space-y-24 py-12 md:py-20 overflow-hidden">
      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-8">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/50 border border-cyan-800/50 text-cyan-300 text-xs font-medium">
          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse"></span>
          Next-Generation Edge Static Hosting Platform
        </div>

        <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight text-white max-w-4xl mx-auto leading-[1.1]">
          Deploy static websites globally in{' '}
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-300 to-blue-500">
            seconds.
          </span>
        </h1>

        <p className="text-lg sm:text-xl text-slate-400 max-w-2xl mx-auto leading-relaxed">
          Drag and drop your website ZIP archive. StrataFlux extracts assets, provisions Anycast edge routing, enforces zero-trust sandboxes, and delivers an instant live HTTPS URL.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-2">
          <button
            onClick={() => onNavigate(user ? '/dashboard' : '/register')}
            className="w-full sm:w-auto px-8 py-3.5 text-base font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-xl shadow-lg shadow-cyan-950/40 flex items-center justify-center gap-2 transition-all hover:scale-[1.02]"
          >
            <UploadCloud className="w-5 h-5" />
            {user ? 'Open Dashboard' : 'Start Free Deployment'}
          </button>
          <button
            onClick={() => onNavigate('/how-it-works')}
            className="w-full sm:w-auto px-8 py-3.5 text-base font-medium text-slate-300 hover:text-white bg-slate-900/80 hover:bg-slate-800 border border-slate-800 rounded-xl transition-colors flex items-center justify-center gap-2"
          >
            How It Works
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Interactive Deployment Simulator Card */}
        <div className="pt-8 max-w-3xl mx-auto">
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-2xl text-left relative overflow-hidden backdrop-blur-xl">
            <div className="flex items-center justify-between pb-6 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-rose-500/80"></div>
                <div className="w-3 h-3 rounded-full bg-amber-500/80"></div>
                <div className="w-3 h-3 rounded-full bg-emerald-500/80"></div>
                <span className="ml-2 text-xs font-mono text-slate-400">strataflux-edge-deployer</span>
              </div>
              <span className="text-xs font-mono text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/40">
                Anycast PoP: Singapore (SIN-01)
              </span>
            </div>

            {demoState === 'idle' ? (
              <div
                onClick={runDemoDeployment}
                className="mt-6 border-2 border-dashed border-slate-700/80 hover:border-cyan-500/60 rounded-xl p-8 sm:p-12 text-center cursor-pointer transition-all hover:bg-slate-800/30 group"
              >
                <div className="w-16 h-16 rounded-full bg-cyan-950/60 text-cyan-400 flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                  <UploadCloud className="w-8 h-8" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-1">Click to test instant ZIP deploy</h3>
                <p className="text-sm text-slate-400 max-w-sm mx-auto">
                  Simulate uploading <code className="text-cyan-300 font-mono">portfolio-site.zip</code> and watch our edge pipeline execute.
                </p>
                <div className="mt-4 inline-flex items-center gap-1.5 text-xs font-semibold text-cyan-400">
                  <span>Run Live Simulation</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </div>
              </div>
            ) : (
              <div className="mt-6 space-y-5">
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs font-mono">
                    <span className="text-slate-300">
                      {demoState === 'extracting' && 'Extracting archive & scanning sandboxes...'}
                      {demoState === 'routing' && 'Propagating edge routes across 240+ Anycast nodes...'}
                      {demoState === 'live' && 'Deployment published to global edge!'}
                    </span>
                    <span className="text-cyan-400">{demoProgress}%</span>
                  </div>
                  <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-cyan-500 to-blue-500 transition-all duration-500 ease-out"
                      style={{ width: `${demoProgress}%` }}
                    ></div>
                  </div>
                </div>

                <div className="bg-slate-950 rounded-lg p-4 font-mono text-xs text-slate-300 space-y-1.5 border border-slate-800/60">
                  <p className="text-emerald-400">[OK] Received package portfolio-site.zip (4.2 MB)</p>
                  <p className="text-slate-400">[INFO] Unpacked 48 assets: index.html, assets/bundle.js, styles.css, images/*</p>
                  <p className="text-slate-400">[INFO] Security audit passed: 0 server executable scripts detected</p>
                  {demoState !== 'extracting' && (
                    <p className="text-cyan-400">[EDGE] Anycast routing synchronized across US-East, EU-Central, AP-South</p>
                  )}
                  {demoState === 'live' && (
                    <p className="text-emerald-300 font-bold">[READY] Live URL active with TLS 1.3 encryption</p>
                  )}
                </div>

                {demoState === 'live' && (
                  <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-4 bg-emerald-950/20 border border-emerald-800/40 rounded-xl p-4">
                    <div className="flex items-center gap-3">
                      <CheckCircle2 className="w-6 h-6 text-emerald-400 flex-shrink-0" />
                      <div>
                        <div className="text-xs text-slate-400 font-mono">PUBLIC LIVE EDGE URL</div>
                        <a
                          href="#"
                          onClick={(e) => { e.preventDefault(); onNavigate(user ? '/dashboard' : '/register'); }}
                          className="text-sm font-semibold text-emerald-300 hover:underline font-mono"
                        >
                          https://portfolio-site.strataflux.app
                        </a>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => onNavigate(user ? '/dashboard' : '/register')}
                        className="px-4 py-2 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg transition-colors"
                      >
                        Deploy Your Own Site
                      </button>
                      <button
                        onClick={resetDemo}
                        className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
                        title="Reset simulation"
                      >
                        <RefreshCw className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Feature Grid Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        <div className="text-center space-y-4 max-w-2xl mx-auto">
          <h2 className="text-3xl sm:text-4xl font-bold text-white tracking-tight">
            Engineered for high-velocity web delivery.
          </h2>
          <p className="text-slate-400 text-base">
            No convoluted servers or fragile cloud setups. Everything needed for global static websites is automated.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-6 space-y-3 hover:border-slate-700 transition-colors">
            <div className="w-10 h-10 rounded-lg bg-cyan-950 border border-cyan-800/60 text-cyan-400 flex items-center justify-center">
              <Zap className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-semibold text-white">Instant ZIP & File Ingestion</h3>
            <p className="text-sm text-slate-400 leading-relaxed">
              Upload build archives directly from Vite, Next.js static exports, React, Vue, or pure HTML. Instant ZIP extraction with automatic entrypoint identification.
            </p>
          </div>

          <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-6 space-y-3 hover:border-slate-700 transition-colors">
            <div className="w-10 h-10 rounded-lg bg-sky-950 border border-sky-800/60 text-sky-400 flex items-center justify-center">
              <Globe className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-semibold text-white">Custom Domains & Auto SSL</h3>
            <p className="text-sm text-slate-400 leading-relaxed">
              Bring any custom domain name. StrataFlux verifies CNAME and TXT records, issues edge TLS certificates, and provides apex domain compatibility.
            </p>
          </div>

          <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-6 space-y-3 hover:border-slate-700 transition-colors">
            <div className="w-10 h-10 rounded-lg bg-indigo-950 border border-indigo-800/60 text-indigo-400 flex items-center justify-center">
              <Shield className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-semibold text-white">Zero-Trust Sandbox Isolation</h3>
            <p className="text-sm text-slate-400 leading-relaxed">
              Every project is quarantined in isolated object storage paths. Malicious executables, zip-slip attacks, and server scripts are blocked before propagation.
            </p>
          </div>

          <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-6 space-y-3 hover:border-slate-700 transition-colors">
            <div className="w-10 h-10 rounded-lg bg-amber-950 border border-amber-800/60 text-amber-400 flex items-center justify-center">
              <RefreshCw className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-semibold text-white">One-Click Rollbacks</h3>
            <p className="text-sm text-slate-400 leading-relaxed">
              Every deployment is an immutable snapshot. If a regression occurs, promote any historical release to production with zero downtime in milliseconds.
            </p>
          </div>

          <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-6 space-y-3 hover:border-slate-700 transition-colors">
            <div className="w-10 h-10 rounded-lg bg-emerald-950 border border-emerald-800/60 text-emerald-400 flex items-center justify-center">
              <BarChart3 className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-semibold text-white">High-Precision Analytics</h3>
            <p className="text-sm text-slate-400 leading-relaxed">
              Privacy-preserving edge metrics without bloated client-side trackers. Monitor unique visitors, page views, countries, devices, and bandwidth consumption.
            </p>
          </div>

          <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-6 space-y-3 hover:border-slate-700 transition-colors">
            <div className="w-10 h-10 rounded-lg bg-rose-950 border border-rose-800/60 text-rose-400 flex items-center justify-center">
              <Lock className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-semibold text-white">Dedicated Admin Governance</h3>
            <p className="text-sm text-slate-400 leading-relaxed">
              Comprehensive administrator console at <code className="text-rose-300 font-mono text-xs">/admin-login.html</code> for complete oversight of users, projects, security logs, and infrastructure.
            </p>
          </div>
        </div>
      </section>

      {/* CTA Banner */}
      <section className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-r from-cyan-950/80 via-slate-900 to-slate-950 border border-cyan-800/50 rounded-2xl p-8 sm:p-12 text-center space-y-6">
          <h2 className="text-2xl sm:text-4xl font-bold text-white">
            Ready to deploy your next website?
          </h2>
          <p className="text-slate-300 text-sm sm:text-base max-w-xl mx-auto">
            Get started on the free tier with 3 projects, custom domains, and automated edge SSL. No credit card required.
          </p>
          <div>
            <button
              onClick={() => onNavigate(user ? '/dashboard' : '/register')}
              className="px-8 py-3.5 text-base font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-xl shadow-lg transition-transform hover:scale-[1.02]"
            >
              {user ? 'Go to Dashboard' : 'Create Free Account'}
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
