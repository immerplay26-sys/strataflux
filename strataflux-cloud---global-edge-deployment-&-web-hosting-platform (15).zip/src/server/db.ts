import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import type { Pool } from 'pg';
import { config } from './config';
import { logger } from './logger';

export interface UserRecord {
  id: string;
  email: string;
  password_hash: string;
  name: string;
  role: 'user' | 'admin';
  status: 'active' | 'suspended' | 'banned';
  avatar_url?: string;
  email_verified: boolean;
  verification_token?: string;
  reset_token?: string;
  reset_token_expiry?: string;
  two_factor_enabled: boolean;
  failed_login_attempts: number;
  locked_until?: string;
  last_login_at?: string;
  last_login_ip?: string;
  plan_tier: 'free' | 'pro' | 'business';
  custom_domain_limit: number;
  storage_limit_bytes: number;
  bandwidth_limit_bytes: number;
  created_at: string;
  updated_at: string;
}

export interface SessionRecord {
  id: string;
  user_id: string;
  token_hash: string;
  ip_address?: string;
  user_agent?: string;
  expires_at: string;
  revoked_at?: string;
  created_at: string;
}

export interface ProjectRecord {
  id: string;
  user_id: string;
  name: string;
  subdomain: string;
  framework: string;
  spa_fallback: boolean;
  current_deployment_id?: string;
  status: 'ready' | 'deploying' | 'failed';
  storage_used_bytes: number;
  bandwidth_used_bytes: number;
  total_deployments: number;
  created_at: string;
  updated_at: string;
}

export interface DeploymentRecord {
  id: string;
  project_id: string;
  user_id: string;
  status: 'queued' | 'building' | 'deploying' | 'ready' | 'live' | 'failed' | 'cancelled';
  source_type: 'zip' | 'files' | 'git' | 'cli';
  file_count: number;
  total_size_bytes: number;
  url: string;
  branch?: string;
  commit_message?: string;
  build_logs?: string;
  error_message?: string;
  storage_path: string;
  storage_driver: 'local' | 'r2' | 's3';
  deployed_at?: string;
  created_at: string;
}

export interface DomainRecord {
  id: string;
  project_id: string;
  user_id: string;
  domain: string;
  verification_type: 'cname' | 'a';
  verification_token: string;
  is_verified: boolean;
  ssl_status: 'pending' | 'active' | 'failed';
  cloudflare_hostname_id?: string;
  dns_records?: {
    type: string;
    name: string;
    value: string;
  }[];
  verified_at?: string;
  created_at: string;
  updated_at: string;
}

export interface AnalyticsHit {
  id: string;
  project_id: string;
  deployment_id?: string;
  path: string;
  referrer?: string;
  ip_hash: string;
  country_code: string;
  country_name: string;
  device_type: 'desktop' | 'mobile' | 'tablet' | 'bot';
  browser: string;
  os: string;
  bytes_sent: number;
  status_code: number;
  created_at: string;
}

export interface SupportTicketRecord {
  id: string;
  user_id: string;
  user_email: string;
  user_name: string;
  subject: string;
  category: 'technical' | 'billing' | 'domain' | 'abuse' | 'general';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  status: 'open' | 'in_progress' | 'resolved' | 'closed';
  messages: {
    id: string;
    sender_id: string;
    sender_name: string;
    sender_role: 'user' | 'admin';
    content: string;
    created_at: string;
  }[];
  created_at: string;
  updated_at: string;
}

export interface ActivityLogRecord {
  id: string;
  actor_id?: string;
  actor_email?: string;
  actor_role?: string;
  action: string;
  resource_type: string;
  resource_id?: string;
  details?: Record<string, any>;
  ip_address?: string;
  created_at: string;
}

export interface PaymentRecord {
  id: string;
  user_id: string;
  user_email?: string;
  user_name?: string;
  plan_tier: string;
  plan_name: string;
  billing_interval: 'monthly' | 'yearly';
  amount: number;
  currency: string;
  provider: 'stripe' | 'paypal' | 'payoneer' | 'jazzcash' | 'easypaisa' | 'manual';
  payment_method: string;
  transaction_id: string;
  screenshot_path?: string;
  status: 'pending' | 'approved' | 'rejected' | 'completed' | 'failed';
  admin_note?: string;
  customer_note?: string;
  created_at: string;
  approved_at?: string;
  rejected_at?: string;
  approved_by?: string;
  raw_metadata?: Record<string, any>;
}

export interface DatabaseState {
  users: UserRecord[];
  sessions: SessionRecord[];
  projects: ProjectRecord[];
  deployments: DeploymentRecord[];
  domains: DomainRecord[];
  subscriptions: any[];
  payments: PaymentRecord[];
  analytics: AnalyticsHit[];
  support_tickets: SupportTicketRecord[];
  admin_settings: Record<string, any>;
  activity_logs: ActivityLogRecord[];
  notifications: any[];
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.resolve(DATA_DIR, 'strataflux.json');

class DatabaseManager {
  private state: DatabaseState = {
    users: [],
    sessions: [],
    projects: [],
    deployments: [],
    domains: [],
    subscriptions: [],
    payments: [],
    analytics: [],
    support_tickets: [],
    admin_settings: {},
    activity_logs: [],
    notifications: []
  };

  private pgPool: Pool | null = null;
  public isPostgres = false;
  private isInitialized = false;
  private kvNamespace: any = null;

  async init(options?: { env?: any }): Promise<void> {
    if (this.isInitialized) return;

    if (options?.env?.STRATAFLUX_KV) {
      this.kvNamespace = options.env.STRATAFLUX_KV;
      try {
        const stored = await this.kvNamespace.get('strataflux_db_state', 'json') as Record<string, any> | null;
        if (stored) {
          this.state = stored as DatabaseState;
        }
      } catch (e) {
        logger.warn('Failed reading state from Cloudflare KV:', e);
      }
    }

    try {
      if (typeof fs !== 'undefined' && fs.existsSync && fs.mkdirSync) {
        if (!fs.existsSync(DATA_DIR)) {
          fs.mkdirSync(DATA_DIR, { recursive: true });
        }
      }
    } catch {}

    if (config.databaseUrl) {
      try {
        logger.info('Attempting connection to PostgreSQL database cluster...');
        const pgModule = await import('pg');
        const PoolConstructor = (pgModule as any).default?.Pool || (pgModule as any).Pool;
        if (PoolConstructor) {
          this.pgPool = new PoolConstructor({
            connectionString: config.databaseUrl,
            ssl: config.isProduction ? { rejectUnauthorized: false } : undefined,
            max: 20,
            idleTimeoutMillis: 30000,
            connectionTimeoutMillis: 5000
          });

          await this.pgPool!.query('SELECT 1');
          this.isPostgres = true;
          logger.info('PostgreSQL connection established successfully.');
          await this.runPgMigrations();
        }
      } catch (err: any) {
        logger.warn('PostgreSQL connection failed, operating with local persistent relational storage:', { error: err.message });
        this.isPostgres = false;
      }
    }

    // Load persistent state file
    try {
      if (typeof fs !== 'undefined' && fs.existsSync && fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        this.state = {
          users: parsed.users || [],
          sessions: parsed.sessions || [],
          projects: parsed.projects || [],
          deployments: parsed.deployments || [],
          domains: parsed.domains || [],
          subscriptions: parsed.subscriptions || [],
          payments: parsed.payments || [],
          analytics: parsed.analytics || [],
          support_tickets: parsed.support_tickets || [],
          admin_settings: parsed.admin_settings || {},
          activity_logs: parsed.activity_logs || [],
          notifications: parsed.notifications || []
        };
      }
    } catch (e) {
      logger.error('Failed reading persistent database file, re-initializing fresh state', e);
    }

    await this.seedDefaults();
    this.isInitialized = true;
  }

  private persist(): void {
    if (this.kvNamespace && typeof this.kvNamespace.put === 'function') {
      try {
        this.kvNamespace.put('strataflux_db_state', JSON.stringify(this.state)).catch(() => {});
      } catch {}
    }

    try {
      if (typeof fs !== 'undefined' && fs.writeFileSync && fs.renameSync) {
        const tempFile = `${DB_FILE}.tmp`;
        fs.writeFileSync(tempFile, JSON.stringify(this.state, null, 2), 'utf-8');
        fs.renameSync(tempFile, DB_FILE);
      }
    } catch (e) {
      // In edge worker environment with read-only disk, state remains safely in memory
    }
  }

  private async runPgMigrations() {
    if (!this.pgPool) return;
    try {
      if (typeof fs !== 'undefined' && fs.existsSync) {
        const migrationPath = path.resolve(process.cwd(), 'migrations', '001_initial_schema.sql');
        if (fs.existsSync(migrationPath)) {
          const sql = fs.readFileSync(migrationPath, 'utf-8');
          await this.pgPool.query(sql);
          logger.info('PostgreSQL 001_initial_schema migrations verified.');
        }
      }
    } catch (err: any) {
      logger.warn('Skipped local migration file lookup in edge runtime:', err.message);
    }
  }

  private async seedDefaults() {
    const adminEmail = config.adminEmail.toLowerCase().trim();
    let existingAdmin: UserRecord | undefined;

    if (this.isPostgres && this.pgPool) {
      try {
        const res = await this.pgPool.query('SELECT * FROM users WHERE LOWER(email) = $1 OR role = $2 LIMIT 1', [adminEmail, 'admin']);
        if (res.rows.length > 0) existingAdmin = res.rows[0];
      } catch (e) {}
    } else {
      existingAdmin = this.state.users.find(u => u.email.toLowerCase() === adminEmail || u.role === 'admin');
    }

    if (!existingAdmin) {
      logger.info(`Bootstrapping initial administrator account (${adminEmail})...`);
      const salt = await bcrypt.genSalt(10);
      const hash = config.adminPasswordHash || await bcrypt.hash(config.adminInitialPassword, salt);
      
      const adminUser: UserRecord = {
        id: 'usr_admin_' + crypto.randomBytes(6).toString('hex'),
        email: adminEmail,
        password_hash: hash,
        name: 'Muhammad (Administrator)',
        role: 'admin',
        status: 'active',
        email_verified: true,
        two_factor_enabled: false,
        failed_login_attempts: 0,
        plan_tier: 'business',
        custom_domain_limit: 100,
        storage_limit_bytes: 100 * 1024 * 1024 * 1024,
        bandwidth_limit_bytes: 1000 * 1024 * 1024 * 1024,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };

      if (this.isPostgres && this.pgPool) {
        await this.pgPool.query(`
          INSERT INTO users (id, email, password_hash, name, role, status, email_verified, two_factor_enabled, failed_login_attempts, plan_tier, custom_domain_limit, storage_limit_bytes, bandwidth_limit_bytes)
          VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
        `, [
          adminUser.id, adminUser.email, adminUser.password_hash, adminUser.name,
          adminUser.role, adminUser.status, adminUser.email_verified, adminUser.two_factor_enabled,
          adminUser.failed_login_attempts, adminUser.plan_tier, adminUser.custom_domain_limit,
          adminUser.storage_limit_bytes, adminUser.bandwidth_limit_bytes
        ]);
      }

      this.state.users.push(adminUser);
      this.persist();
      logger.info(`Administrator account created successfully.`);
    }

    // Default Plans
    if (!this.state.admin_settings['plans']) {
      this.state.admin_settings['plans'] = [
        {
          id: 'free',
          name: 'Starter',
          price_monthly: 0,
          price_yearly: 0,
          max_projects: 3,
          max_custom_domains: 1,
          storage_limit_mb: 500,
          bandwidth_limit_gb: 10,
          analytics_retention_days: 7,
          features: [
            'Instant ZIP & File Upload',
            '3 Active Projects',
            '1 Custom Domain with Auto-SSL',
            '500 MB Isolated Object Storage',
            '10 GB Monthly Edge Bandwidth',
            '7-Day High-Precision Analytics',
            'Community & Ticket Support'
          ]
        },
        {
          id: 'pro',
          name: 'Pro Developer',
          price_monthly: 19,
          price_yearly: 190,
          max_projects: 20,
          max_custom_domains: 10,
          storage_limit_mb: 10000,
          bandwidth_limit_gb: 250,
          analytics_retention_days: 90,
          features: [
            'Unlimited Deployments',
            '20 Active Projects',
            '10 Custom Domains with Wildcard SSL',
            '10 GB High-Performance Storage',
            '250 GB Global Anycast Bandwidth',
            '90-Day Real-Time Analytics & Geo Stats',
            'Instant One-Click Rollbacks',
            'Priority Email & WhatsApp Support'
          ]
        },
        {
          id: 'business',
          name: 'Enterprise Scale',
          price_monthly: 49,
          price_yearly: 490,
          max_projects: 100,
          max_custom_domains: 50,
          storage_limit_mb: 100000,
          bandwidth_limit_gb: 1000,
          analytics_retention_days: 365,
          features: [
            'Unlimited Everything',
            '100 Active Projects',
            '50 Custom Domains + Apex Records',
            '100 GB Distributed Object Storage',
            '1 TB Global Edge CDN Bandwidth',
            '365-Day Raw Analytics & Export',
            'Dedicated Edge Cache Routing',
            '24/7 SLA & Dedicated WhatsApp Escalation'
          ]
        }
      ];
    }

    if (!this.state.admin_settings['website']) {
      this.state.admin_settings['website'] = {
        name: 'StrataFlux Cloud',
        tagline: 'Global High-Velocity Website Deployment Platform',
        contact_email: config.supportEmail,
        whatsapp: config.adminWhatsapp,
        support_hours: '24/7 Monitored Global Operations',
        hero_title: 'Deploy static websites to global edge infrastructure in seconds.',
        hero_subtitle: 'Drag and drop your website ZIP or build files. Receive an instant live HTTPS edge URL, custom domain automation, real-time analytics, and enterprise isolation.',
        announcement_text: '',
        announcement_active: false,
        maintenance_mode: false
      };
    }

    if (!this.state.admin_settings['seo']) {
      this.state.admin_settings['seo'] = {
        meta_title: 'StrataFlux Cloud – Global Edge Deployment & Web Hosting Platform',
        meta_description: 'Instant zero-configuration static website hosting. Deploy ZIP packages in seconds with automated SSL, custom domains, high-precision analytics, and global edge routing.',
        canonical_url: config.appUrl,
        og_image: '/og-card.png',
        robots_txt: `User-agent: *\nAllow: /\nDisallow: /admin\nDisallow: /admin-login\nDisallow: /admin-login.html\nDisallow: /api/\nSitemap: ${config.appUrl}/sitemap.xml`,
        google_site_verification: ''
      };
    }

    if (!this.state.admin_settings['payment_settings']) {
      this.state.admin_settings['payment_settings'] = {
        stripe: {
          enabled: config.stripeEnabled,
          publishable_key: config.stripePublishableKey || ''
        },
        paypal: {
          enabled: config.paypalEnabled,
          client_id: config.paypalClientId || '',
          mode: config.paypalMode || 'sandbox'
        },
        payoneer: {
          enabled: config.payoneerEnabled,
          account_name: config.payoneerAccountName,
          account_email: config.payoneerAccountEmail,
          instructions: config.payoneerInstructions
        },
        jazzcash: {
          enabled: config.jazzcashEnabled,
          account_name: config.jazzcashAccountName,
          account_number: config.jazzcashAccountNumber,
          instructions: config.jazzcashInstructions
        },
        easypaisa: {
          enabled: config.easypaisaEnabled,
          account_name: config.easypaisaAccountName,
          account_number: config.easypaisaAccountNumber,
          instructions: config.easypaisaInstructions
        }
      };
    }

    this.persist();
  }

  // ================= HEALTH CHECK =================
  async healthCheck() {
    let dbStatus = 'healthy';
    if (this.isPostgres && this.pgPool) {
      try {
        await this.pgPool.query('SELECT 1');
      } catch (e) {
        dbStatus = 'degraded';
      }
    }
    return {
      status: dbStatus === 'healthy' ? 'operational' : 'degraded',
      databaseEngine: this.isPostgres ? 'postgresql' : 'persistent_relational',
      databaseStatus: dbStatus,
      totalUsers: this.state.users.length,
      totalProjects: this.state.projects.length,
      totalDeployments: this.state.deployments.length
    };
  }

  // ================= USERS =================
  async findUserByEmail(email: string): Promise<UserRecord | null> {
    const norm = email.trim().toLowerCase();
    if (this.isPostgres && this.pgPool) {
      try {
        const res = await this.pgPool.query('SELECT * FROM users WHERE LOWER(email) = $1 LIMIT 1', [norm]);
        return res.rows[0] || null;
      } catch (e) {}
    }
    return this.state.users.find(u => u.email.toLowerCase() === norm) || null;
  }

  async findUserById(id: string): Promise<UserRecord | null> {
    if (this.isPostgres && this.pgPool) {
      try {
        const res = await this.pgPool.query('SELECT * FROM users WHERE id = $1 LIMIT 1', [id]);
        return res.rows[0] || null;
      } catch (e) {}
    }
    return this.state.users.find(u => u.id === id) || null;
  }

  async createUser(data: Omit<UserRecord, 'id' | 'created_at' | 'updated_at' | 'failed_login_attempts'>): Promise<UserRecord> {
    const user: UserRecord = {
      ...data,
      id: 'usr_' + crypto.randomBytes(8).toString('hex'),
      failed_login_attempts: 0,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    if (this.isPostgres && this.pgPool) {
      try {
        await this.pgPool.query(`
          INSERT INTO users (id, email, password_hash, name, role, status, email_verified, plan_tier, custom_domain_limit, storage_limit_bytes, bandwidth_limit_bytes)
          VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
        `, [
          user.id, user.email, user.password_hash, user.name, user.role,
          user.status, user.email_verified, user.plan_tier, user.custom_domain_limit,
          user.storage_limit_bytes, user.bandwidth_limit_bytes
        ]);
      } catch (e) {
        logger.error('PostgreSQL createUser error, writing to state', e);
      }
    }

    this.state.users.push(user);
    this.persist();
    return user;
  }

  async updateUser(id: string, updates: Partial<UserRecord>): Promise<UserRecord | null> {
    const idx = this.state.users.findIndex(u => u.id === id);
    if (idx === -1) return null;

    this.state.users[idx] = {
      ...this.state.users[idx],
      ...updates,
      updated_at: new Date().toISOString()
    };

    if (this.isPostgres && this.pgPool) {
      try {
        const fields = Object.keys(updates);
        if (fields.length > 0) {
          const setClause = fields.map((f, i) => `${f} = $${i + 2}`).join(', ');
          const values = fields.map(f => (updates as any)[f]);
          await this.pgPool.query(`UPDATE users SET ${setClause}, updated_at = NOW() WHERE id = $1`, [id, ...values]);
        }
      } catch (e) {
        logger.error('PostgreSQL updateUser error', e);
      }
    }

    this.persist();
    return this.state.users[idx];
  }

  async deleteUser(id: string): Promise<boolean> {
    const initialLen = this.state.users.length;
    this.state.users = this.state.users.filter(u => u.id !== id);
    this.state.sessions = this.state.sessions.filter(s => s.user_id !== id);
    this.state.projects = this.state.projects.filter(p => p.user_id !== id);
    this.state.deployments = this.state.deployments.filter(d => d.user_id !== id);
    this.state.domains = this.state.domains.filter(dm => dm.user_id !== id);
    this.state.support_tickets = this.state.support_tickets.filter(t => t.user_id !== id);

    if (this.isPostgres && this.pgPool) {
      try {
        await this.pgPool.query('DELETE FROM users WHERE id = $1', [id]);
      } catch (e) {}
    }

    this.persist();
    return this.state.users.length < initialLen;
  }

  async listUsers(search?: string): Promise<UserRecord[]> {
    let list = [...this.state.users];
    if (search) {
      const q = search.toLowerCase();
      list = list.filter(u => u.email.toLowerCase().includes(q) || u.name.toLowerCase().includes(q));
    }
    return list.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  }

  // ================= SESSIONS & LOCKOUT =================
  async recordFailedLogin(email: string): Promise<{ locked: boolean; lockedUntil?: string }> {
    const user = await this.findUserByEmail(email);
    if (!user) return { locked: false };

    const attempts = (user.failed_login_attempts || 0) + 1;
    const updates: Partial<UserRecord> = { failed_login_attempts: attempts };

    if (attempts >= config.maxLoginAttempts) {
      const lockTime = new Date(Date.now() + config.lockoutDurationMinutes * 60 * 1000).toISOString();
      updates.locked_until = lockTime;
      await this.updateUser(user.id, updates);
      return { locked: true, lockedUntil: lockTime };
    }

    await this.updateUser(user.id, updates);
    return { locked: false };
  }

  async resetFailedLogins(userId: string, ip?: string): Promise<void> {
    await this.updateUser(userId, {
      failed_login_attempts: 0,
      locked_until: undefined,
      last_login_at: new Date().toISOString(),
      last_login_ip: ip
    });
  }

  async createSession(userId: string, token: string, ip?: string, userAgent?: string): Promise<SessionRecord> {
    const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
    const session: SessionRecord = {
      id: 'ses_' + crypto.randomBytes(8).toString('hex'),
      user_id: userId,
      token_hash: tokenHash,
      ip_address: ip,
      user_agent: userAgent,
      expires_at: new Date(Date.now() + config.tokenExpiryDays * 24 * 60 * 60 * 1000).toISOString(),
      created_at: new Date().toISOString()
    };
    this.state.sessions.push(session);
    this.persist();
    return session;
  }

  async isSessionValid(token: string): Promise<boolean> {
    const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
    const session = this.state.sessions.find(s => s.token_hash === tokenHash);
    if (!session) return true; // Backward-compatible with non-session tokens
    if (session.revoked_at) return false;
    if (new Date() > new Date(session.expires_at)) return false;
    return true;
  }

  async revokeSession(token: string): Promise<void> {
    const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
    const session = this.state.sessions.find(s => s.token_hash === tokenHash);
    if (session) {
      session.revoked_at = new Date().toISOString();
      this.persist();
    }
  }

  // ================= PROJECTS =================
  async findProjectById(id: string): Promise<ProjectRecord | null> {
    return this.state.projects.find(p => p.id === id) || null;
  }

  async findProjectBySubdomain(subdomain: string): Promise<ProjectRecord | null> {
    const norm = subdomain.trim().toLowerCase();
    return this.state.projects.find(p => p.subdomain.toLowerCase() === norm) || null;
  }

  async listProjectsByUserId(userId: string): Promise<ProjectRecord[]> {
    return this.state.projects
      .filter(p => p.user_id === userId)
      .sort((a, b) => new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime());
  }

  async listAllProjects(): Promise<ProjectRecord[]> {
    return [...this.state.projects].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  }

  async createProject(data: Omit<ProjectRecord, 'id' | 'created_at' | 'updated_at' | 'storage_used_bytes' | 'bandwidth_used_bytes' | 'total_deployments'>): Promise<ProjectRecord> {
    const project: ProjectRecord = {
      ...data,
      id: 'prj_' + crypto.randomBytes(8).toString('hex'),
      spa_fallback: data.spa_fallback !== undefined ? data.spa_fallback : true,
      storage_used_bytes: 0,
      bandwidth_used_bytes: 0,
      total_deployments: 0,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    this.state.projects.push(project);
    this.persist();
    return project;
  }

  async updateProject(id: string, updates: Partial<ProjectRecord>): Promise<ProjectRecord | null> {
    const idx = this.state.projects.findIndex(p => p.id === id);
    if (idx === -1) return null;
    this.state.projects[idx] = {
      ...this.state.projects[idx],
      ...updates,
      updated_at: new Date().toISOString()
    };
    this.persist();
    return this.state.projects[idx];
  }

  async deleteProject(id: string): Promise<boolean> {
    const initialLen = this.state.projects.length;
    this.state.projects = this.state.projects.filter(p => p.id !== id);
    this.state.deployments = this.state.deployments.filter(d => d.project_id !== id);
    this.state.domains = this.state.domains.filter(dm => dm.project_id !== id);
    this.state.analytics = this.state.analytics.filter(a => a.project_id !== id);
    this.persist();
    return this.state.projects.length < initialLen;
  }

  // ================= DEPLOYMENTS =================
  async findDeploymentById(id: string): Promise<DeploymentRecord | null> {
    return this.state.deployments.find(d => d.id === id) || null;
  }

  async listDeploymentsByProjectId(projectId: string): Promise<DeploymentRecord[]> {
    return this.state.deployments
      .filter(d => d.project_id === projectId)
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  }

  async listAllDeployments(): Promise<DeploymentRecord[]> {
    return [...this.state.deployments].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  }

  async createDeployment(data: Omit<DeploymentRecord, 'id' | 'created_at'>): Promise<DeploymentRecord> {
    const deployment: DeploymentRecord = {
      ...data,
      id: 'dep_' + crypto.randomBytes(8).toString('hex'),
      created_at: new Date().toISOString()
    };
    this.state.deployments.push(deployment);

    const project = this.state.projects.find(p => p.id === data.project_id);
    if (project) {
      project.total_deployments += 1;
      project.storage_used_bytes = Math.max(project.storage_used_bytes, data.total_size_bytes);
      project.updated_at = new Date().toISOString();
    }

    this.persist();
    return deployment;
  }

  async updateDeployment(id: string, updates: Partial<DeploymentRecord>): Promise<DeploymentRecord | null> {
    const idx = this.state.deployments.findIndex(d => d.id === id);
    if (idx === -1) return null;
    this.state.deployments[idx] = {
      ...this.state.deployments[idx],
      ...updates
    };
    this.persist();
    return this.state.deployments[idx];
  }

  async deleteDeployment(id: string): Promise<boolean> {
    const initialLen = this.state.deployments.length;
    this.state.deployments = this.state.deployments.filter(d => d.id !== id);
    this.persist();
    return this.state.deployments.length < initialLen;
  }

  // ================= DOMAINS =================
  async findDomainById(id: string): Promise<DomainRecord | null> {
    return this.state.domains.find(dm => dm.id === id) || null;
  }

  async findDomainByName(domain: string): Promise<DomainRecord | null> {
    const norm = domain.trim().toLowerCase();
    return this.state.domains.find(dm => dm.domain.toLowerCase() === norm) || null;
  }

  async listDomainsByProjectId(projectId: string): Promise<DomainRecord[]> {
    return this.state.domains.filter(dm => dm.project_id === projectId);
  }

  async listDomainsByUserId(userId: string): Promise<DomainRecord[]> {
    return this.state.domains.filter(dm => dm.user_id === userId);
  }

  async listAllDomains(): Promise<DomainRecord[]> {
    return [...this.state.domains].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  }

  async createDomain(data: Omit<DomainRecord, 'id' | 'created_at' | 'updated_at'>): Promise<DomainRecord> {
    const domain: DomainRecord = {
      ...data,
      id: 'dom_' + crypto.randomBytes(8).toString('hex'),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    this.state.domains.push(domain);
    this.persist();
    return domain;
  }

  async updateDomain(id: string, updates: Partial<DomainRecord>): Promise<DomainRecord | null> {
    const idx = this.state.domains.findIndex(dm => dm.id === id);
    if (idx === -1) return null;
    this.state.domains[idx] = {
      ...this.state.domains[idx],
      ...updates,
      updated_at: new Date().toISOString()
    };
    this.persist();
    return this.state.domains[idx];
  }

  async deleteDomain(id: string): Promise<boolean> {
    const initialLen = this.state.domains.length;
    this.state.domains = this.state.domains.filter(dm => dm.id !== id);
    this.persist();
    return this.state.domains.length < initialLen;
  }

  // ================= ANALYTICS =================
  async recordHit(hit: Omit<AnalyticsHit, 'id' | 'created_at'>): Promise<void> {
    const record: AnalyticsHit = {
      ...hit,
      id: 'hit_' + crypto.randomBytes(6).toString('hex'),
      created_at: new Date().toISOString()
    };
    this.state.analytics.push(record);

    if (this.state.analytics.length > 30000) {
      this.state.analytics = this.state.analytics.slice(-25000);
    }

    const project = this.state.projects.find(p => p.id === hit.project_id);
    if (project) {
      project.bandwidth_used_bytes += hit.bytes_sent;
    }

    this.persist();
  }

  async getProjectAnalytics(projectId: string, days = 30) {
    const cutoff = new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString();
    const hits = this.state.analytics.filter(a => a.project_id === projectId && a.created_at >= cutoff);

    const totalViews = hits.length;
    const uniqueIps = new Set(hits.map(h => h.ip_hash)).size;
    const totalBytes = hits.reduce((acc, h) => acc + h.bytes_sent, 0);

    const dayMap: Record<string, { views: number; visitors: Set<string>; bytes: number }> = {};
    for (const h of hits) {
      const day = h.created_at.split('T')[0];
      if (!dayMap[day]) dayMap[day] = { views: 0, visitors: new Set(), bytes: 0 };
      dayMap[day].views++;
      dayMap[day].visitors.add(h.ip_hash);
      dayMap[day].bytes += h.bytes_sent;
    }

    const daily = Object.keys(dayMap).sort().map(day => ({
      date: day,
      views: dayMap[day].views,
      visitors: dayMap[day].visitors.size,
      bytes: dayMap[day].bytes
    }));

    const countryMap: Record<string, { name: string; count: number }> = {};
    for (const h of hits) {
      const code = h.country_code || 'US';
      const name = h.country_name || 'United States';
      if (!countryMap[code]) countryMap[code] = { name, count: 0 };
      countryMap[code].count++;
    }
    const countries = Object.entries(countryMap)
      .map(([code, data]) => ({ code, name: data.name, count: data.count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 10);

    const deviceMap: Record<string, number> = {};
    const browserMap: Record<string, number> = {};
    const pageMap: Record<string, number> = {};
    const referrerMap: Record<string, number> = {};

    for (const h of hits) {
      deviceMap[h.device_type] = (deviceMap[h.device_type] || 0) + 1;
      browserMap[h.browser] = (browserMap[h.browser] || 0) + 1;
      pageMap[h.path] = (pageMap[h.path] || 0) + 1;
      const ref = h.referrer ? new URL(h.referrer, 'http://localhost').hostname : 'Direct';
      referrerMap[ref] = (referrerMap[ref] || 0) + 1;
    }

    return {
      summary: {
        totalViews,
        uniqueVisitors: uniqueIps,
        totalBandwidthBytes: totalBytes,
        avgBandwidthPerView: totalViews ? Math.round(totalBytes / totalViews) : 0
      },
      daily,
      countries,
      devices: Object.entries(deviceMap).map(([name, count]) => ({ name, count })),
      browsers: Object.entries(browserMap).map(([name, count]) => ({ name, count })),
      popularPages: Object.entries(pageMap).map(([path, count]) => ({ path, count })).sort((a, b) => b.count - a.count).slice(0, 10),
      trafficSources: Object.entries(referrerMap).map(([source, count]) => ({ source, count })).sort((a, b) => b.count - a.count).slice(0, 10)
    };
  }

  async getGlobalAnalytics(days = 30) {
    const cutoff = new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString();
    const hits = this.state.analytics.filter(a => a.created_at >= cutoff);

    const totalViews = hits.length;
    const uniqueIps = new Set(hits.map(h => h.ip_hash)).size;
    const totalBytes = hits.reduce((acc, h) => acc + h.bytes_sent, 0);

    const dayMap: Record<string, { views: number; visitors: Set<string>; bytes: number }> = {};
    for (const h of hits) {
      const day = h.created_at.split('T')[0];
      if (!dayMap[day]) dayMap[day] = { views: 0, visitors: new Set(), bytes: 0 };
      dayMap[day].views++;
      dayMap[day].visitors.add(h.ip_hash);
      dayMap[day].bytes += h.bytes_sent;
    }

    const daily = Object.keys(dayMap).sort().map(day => ({
      date: day,
      views: dayMap[day].views,
      visitors: dayMap[day].visitors.size,
      bytes: dayMap[day].bytes
    }));

    return {
      totalViews,
      uniqueVisitors: uniqueIps,
      totalBytes,
      daily,
      totalProjects: this.state.projects.length,
      totalDeployments: this.state.deployments.length,
      totalUsers: this.state.users.length,
      successfulDeployments: this.state.deployments.filter(d => d.status === 'live' || d.status === 'ready').length,
      failedDeployments: this.state.deployments.filter(d => d.status === 'failed').length
    };
  }

  // ================= SUPPORT TICKETS =================
  async createTicket(data: Omit<SupportTicketRecord, 'id' | 'created_at' | 'updated_at' | 'messages'> & { initialMessage: string }): Promise<SupportTicketRecord> {
    const ticketId = 'tkt_' + crypto.randomBytes(6).toString('hex');
    const ticket: SupportTicketRecord = {
      id: ticketId,
      user_id: data.user_id,
      user_email: data.user_email,
      user_name: data.user_name,
      subject: data.subject,
      category: data.category,
      priority: data.priority,
      status: 'open',
      messages: [
        {
          id: 'msg_' + crypto.randomBytes(6).toString('hex'),
          sender_id: data.user_id,
          sender_name: data.user_name,
          sender_role: 'user',
          content: data.initialMessage,
          created_at: new Date().toISOString()
        }
      ],
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    this.state.support_tickets.push(ticket);
    this.persist();
    return ticket;
  }

  async listTicketsByUserId(userId: string): Promise<SupportTicketRecord[]> {
    return this.state.support_tickets
      .filter(t => t.user_id === userId)
      .sort((a, b) => new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime());
  }

  async listAllTickets(): Promise<SupportTicketRecord[]> {
    return [...this.state.support_tickets].sort((a, b) => new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime());
  }

  async getTicketById(id: string): Promise<SupportTicketRecord | null> {
    return this.state.support_tickets.find(t => t.id === id) || null;
  }

  async findTicketById(id: string): Promise<SupportTicketRecord | null> {
    return this.getTicketById(id);
  }

  async updateTicket(id: string, updates: Partial<SupportTicketRecord>): Promise<SupportTicketRecord | null> {
    const ticket = this.state.support_tickets.find(t => t.id === id);
    if (!ticket) return null;
    Object.assign(ticket, updates);
    ticket.updated_at = new Date().toISOString();
    this.persist();
    return ticket;
  }

  async addTicketMessage(ticketId: string, senderId: string, senderName: string, senderRole: 'user' | 'admin', content: string): Promise<SupportTicketRecord | null> {
    const ticket = this.state.support_tickets.find(t => t.id === ticketId);
    if (!ticket) return null;
    ticket.messages.push({
      id: 'msg_' + crypto.randomBytes(6).toString('hex'),
      sender_id: senderId,
      sender_name: senderName,
      sender_role: senderRole,
      content,
      created_at: new Date().toISOString()
    });
    if (senderRole === 'admin' && ticket.status === 'open') {
      ticket.status = 'in_progress';
    }
    ticket.updated_at = new Date().toISOString();
    this.persist();
    return ticket;
  }

  async updateTicketStatus(id: string, status: SupportTicketRecord['status']): Promise<SupportTicketRecord | null> {
    const ticket = this.state.support_tickets.find(t => t.id === id);
    if (!ticket) return null;
    ticket.status = status;
    ticket.updated_at = new Date().toISOString();
    this.persist();
    return ticket;
  }

  // ================= PAYMENTS =================
  async createPayment(data: Omit<PaymentRecord, 'id' | 'created_at'>): Promise<PaymentRecord> {
    const payment: PaymentRecord = {
      ...data,
      id: 'pay_' + crypto.randomBytes(8).toString('hex'),
      created_at: new Date().toISOString()
    };
    this.state.payments.unshift(payment);
    this.persist();
    return payment;
  }

  async findPaymentById(id: string): Promise<PaymentRecord | null> {
    return this.state.payments.find(p => p.id === id) || null;
  }

  async listPaymentsByUserId(userId: string): Promise<PaymentRecord[]> {
    return this.state.payments
      .filter(p => p.user_id === userId)
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  }

  async listAllPayments(): Promise<PaymentRecord[]> {
    return [...this.state.payments].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  }

  async updatePayment(id: string, updates: Partial<PaymentRecord>): Promise<PaymentRecord | null> {
    const idx = this.state.payments.findIndex(p => p.id === id);
    if (idx === -1) return null;
    this.state.payments[idx] = {
      ...this.state.payments[idx],
      ...updates
    };
    this.persist();
    return this.state.payments[idx];
  }

  async approvePayment(id: string, adminId: string, note?: string): Promise<{ payment: PaymentRecord; user: UserRecord } | null> {
    const payment = await this.findPaymentById(id);
    if (!payment) return null;

    const user = await this.findUserById(payment.user_id);
    if (!user) return null;

    const plans = await this.getSetting<any[]>('plans', []);
    const plan = plans.find(p => p.id === payment.plan_tier) || {
      id: payment.plan_tier,
      name: payment.plan_name,
      max_custom_domains: 5,
      storage_limit_mb: 10000,
      bandwidth_limit_gb: 250
    };

    payment.status = 'approved';
    payment.approved_at = new Date().toISOString();
    payment.approved_by = adminId;
    if (note) payment.admin_note = note;

    await this.updateUser(user.id, {
      plan_tier: plan.id as any,
      custom_domain_limit: plan.max_custom_domains || user.custom_domain_limit,
      storage_limit_bytes: (plan.storage_limit_mb || 10000) * 1024 * 1024,
      bandwidth_limit_bytes: (plan.bandwidth_limit_gb || 250) * 1024 * 1024 * 1024
    });

    await this.logActivity({
      actor_id: adminId,
      actor_role: 'admin',
      action: 'payment.approved',
      resource_type: 'payment',
      resource_id: payment.id,
      details: {
        userId: user.id,
        userEmail: user.email,
        amount: payment.amount,
        currency: payment.currency,
        provider: payment.provider,
        plan: payment.plan_tier,
        transactionId: payment.transaction_id
      }
    });

    await this.createNotification(
      user.id,
      'Payment Approved & Plan Activated',
      `Your payment of ${payment.currency.toUpperCase()} ${payment.amount} via ${payment.payment_method} has been approved! The ${payment.plan_name} plan is now active.`,
      'success'
    );

    this.persist();
    const updatedUser = (await this.findUserById(user.id))!;
    return { payment, user: updatedUser };
  }

  async rejectPayment(id: string, adminId: string, note?: string): Promise<PaymentRecord | null> {
    const payment = await this.findPaymentById(id);
    if (!payment) return null;

    payment.status = 'rejected';
    payment.rejected_at = new Date().toISOString();
    if (note) payment.admin_note = note;

    await this.logActivity({
      actor_id: adminId,
      actor_role: 'admin',
      action: 'payment.rejected',
      resource_type: 'payment',
      resource_id: payment.id,
      details: {
        userId: payment.user_id,
        amount: payment.amount,
        currency: payment.currency,
        provider: payment.provider,
        transactionId: payment.transaction_id,
        reason: note
      }
    });

    await this.createNotification(
      payment.user_id,
      'Payment Verification Issue',
      `Your manual payment submission (${payment.payment_method} - Ref: ${payment.transaction_id}) could not be verified.${note ? ' Reason: ' + note : ''} Please contact support or submit a new transaction ID.`,
      'error'
    );

    this.persist();
    return payment;
  }

  // ================= ADMIN SETTINGS =================
  async getSetting<T>(key: string, defaultValue?: T): Promise<T> {
    return (this.state.admin_settings[key] as T) ?? (defaultValue as T);
  }

  async setSetting(key: string, value: any): Promise<void> {
    this.state.admin_settings[key] = value;
    this.persist();
  }

  async getAllSettings(): Promise<Record<string, any>> {
    return { ...this.state.admin_settings };
  }

  // ================= ACTIVITY LOGS =================
  async logActivity(log: Omit<ActivityLogRecord, 'id' | 'created_at'>): Promise<void> {
    const entry: ActivityLogRecord = {
      ...log,
      id: 'log_' + crypto.randomBytes(6).toString('hex'),
      created_at: new Date().toISOString()
    };
    this.state.activity_logs.unshift(entry);
    if (this.state.activity_logs.length > 5000) {
      this.state.activity_logs = this.state.activity_logs.slice(0, 4000);
    }
    this.persist();
  }

  async listActivityLogs(limit = 100): Promise<ActivityLogRecord[]> {
    return this.state.activity_logs.slice(0, limit);
  }

  // ================= NOTIFICATIONS =================
  async createNotification(userId: string, title: string, message: string, type: 'info' | 'success' | 'warning' | 'error' = 'info', link?: string) {
    const notif = {
      id: 'notif_' + crypto.randomBytes(6).toString('hex'),
      user_id: userId,
      title,
      message,
      type,
      link,
      is_read: false,
      created_at: new Date().toISOString()
    };
    this.state.notifications.unshift(notif);
    this.persist();
    return notif;
  }

  async getNotifications(userId: string) {
    return this.state.notifications.filter(n => n.user_id === userId).slice(0, 50);
  }

  async markNotificationRead(id: string, userId: string) {
    const n = this.state.notifications.find(n => n.id === id && n.user_id === userId);
    if (n) {
      n.is_read = true;
      this.persist();
    }
  }

  // ================= EXPORT / BACKUP =================
  exportDatabaseJson(): string {
    const sanitized = JSON.parse(JSON.stringify(this.state));
    if (sanitized.users) {
      sanitized.users.forEach((u: any) => {
        delete u.password_hash;
        delete u.reset_token;
      });
    }
    return JSON.stringify(sanitized, null, 2);
  }
}

export const db = new DatabaseManager();
