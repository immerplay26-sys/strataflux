import { config } from './config';

export interface SendEmailOptions {
  to: string;
  subject: string;
  html: string;
  text?: string;
}

export class EmailService {
  async sendEmail(options: SendEmailOptions): Promise<{ success: boolean; id?: string }> {
    const { to, subject, html } = options;

    if (config.resendApiKey && config.resendApiKey.startsWith('re_')) {
      try {
        const response = await fetch('https://api.resend.com/emails', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${config.resendApiKey}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            from: config.emailFrom,
            to,
            subject,
            html
          })
        });

        if (response.ok) {
          const data = await response.json();
          console.log(`[EMAIL] Sent email via Resend to ${to}: ${subject} (ID: ${data.id})`);
          return { success: true, id: data.id };
        } else {
          const errText = await response.text();
          console.warn(`[EMAIL] Resend API error: ${errText}`);
        }
      } catch (e) {
        console.error(`[EMAIL] Failed calling email provider API:`, e);
      }
    }

    // Development & Fallback Logger: Transactional email simulation
    console.log(`[EMAIL DISPATCH] To: ${to} | Subject: "${subject}"`);
    return { success: true, id: 'sim_' + Date.now() };
  }

  async sendWelcomeEmail(to: string, name: string) {
    const html = `
      <div style="font-family: sans-serif; background: #090d16; color: #f8fafc; padding: 40px 20px;">
        <div style="max-width: 560px; margin: 0 auto; background: #0f172a; border: 1px solid #1e293b; border-radius: 12px; padding: 32px;">
          <h2 style="color: #38bdf8; margin-top: 0;">Welcome to StrataFlux Cloud, ${name}!</h2>
          <p style="color: #94a3b8; font-size: 15px; line-height: 1.6;">
            Your account has been provisioned on our high-performance global website deployment platform.
          </p>
          <p style="color: #94a3b8; font-size: 15px; line-height: 1.6;">
            You can now create projects, drag-and-drop website ZIP packages, configure custom domains with automated SSL, and monitor real-time traffic analytics.
          </p>
          <div style="margin: 28px 0;">
            <a href="${config.appUrl}/dashboard" style="display: inline-block; background: #0284c7; color: #ffffff; padding: 12px 24px; border-radius: 6px; font-weight: 600; text-decoration: none;">Go to Dashboard</a>
          </div>
          <hr style="border: none; border-top: 1px solid #1e293b; margin: 24px 0;" />
          <p style="color: #64748b; font-size: 13px;">Official Contact: ${config.supportEmail} | WhatsApp: ${config.adminWhatsapp}</p>
        </div>
      </div>
    `;
    return this.sendEmail({ to, subject: 'Welcome to StrataFlux Cloud', html });
  }

  async sendPasswordResetEmail(to: string, resetToken: string) {
    const resetUrl = `${config.appUrl}/reset-password?token=${resetToken}&email=${encodeURIComponent(to)}`;
    const html = `
      <div style="font-family: sans-serif; background: #090d16; color: #f8fafc; padding: 40px 20px;">
        <div style="max-width: 560px; margin: 0 auto; background: #0f172a; border: 1px solid #1e293b; border-radius: 12px; padding: 32px;">
          <h2 style="color: #38bdf8; margin-top: 0;">Reset Your Password</h2>
          <p style="color: #94a3b8; font-size: 15px; line-height: 1.6;">
            We received a request to reset your StrataFlux account password. Click the button below to choose a new password:
          </p>
          <div style="margin: 28px 0;">
            <a href="${resetUrl}" style="display: inline-block; background: #0284c7; color: #ffffff; padding: 12px 24px; border-radius: 6px; font-weight: 600; text-decoration: none;">Reset Password</a>
          </div>
          <p style="color: #64748b; font-size: 13px;">
            If you did not request this, please disregard this email. The link expires in 2 hours.
          </p>
        </div>
      </div>
    `;
    return this.sendEmail({ to, subject: 'StrataFlux Cloud - Password Reset Request', html });
  }

  async sendDeploymentNotification(to: string, projectName: string, liveUrl: string, status: 'live' | 'failed') {
    const isLive = status === 'live';
    const html = `
      <div style="font-family: sans-serif; background: #090d16; color: #f8fafc; padding: 40px 20px;">
        <div style="max-width: 560px; margin: 0 auto; background: #0f172a; border: 1px solid #1e293b; border-radius: 12px; padding: 32px;">
          <h2 style="color: ${isLive ? '#34d399' : '#f87171'}; margin-top: 0;">
            ${isLive ? 'Deployment is Live!' : 'Deployment Failed'}
          </h2>
          <p style="color: #94a3b8; font-size: 15px; line-height: 1.6;">
            Your project <strong>${projectName}</strong> has ${isLive ? 'successfully published to our global edge nodes.' : 'encountered a build/extraction issue.'}
          </p>
          ${isLive ? `
          <div style="margin: 28px 0;">
            <a href="${liveUrl}" style="display: inline-block; background: #10b981; color: #ffffff; padding: 12px 24px; border-radius: 6px; font-weight: 600; text-decoration: none;">Open Live Website</a>
          </div>` : ''}
          <p style="color: #64748b; font-size: 13px;">
            Visit your StrataFlux dashboard to view complete build logs and deployment history.
          </p>
        </div>
      </div>
    `;
    return this.sendEmail({ to, subject: `StrataFlux: ${projectName} Deployment ${isLive ? 'Published' : 'Alert'}`, html });
  }
}

export const emailService = new EmailService();
