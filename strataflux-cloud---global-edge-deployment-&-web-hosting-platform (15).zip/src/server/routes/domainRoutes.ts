import { Router, Request, Response } from 'express';
import crypto from 'crypto';
import { db } from '../db';
import { requireAuth } from '../auth';
import { dnsService } from '../dns';
import { config } from '../config';

const router = Router();

// List user's custom domains
router.get('/', requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user!;
    const domains = await db.listDomainsByUserId(user.id);

    const enhanced = await Promise.all(domains.map(async (d) => {
      const project = await db.findProjectById(d.project_id);
      return {
        ...d,
        projectName: project?.name || 'Unknown Project',
        projectSubdomain: project?.subdomain || ''
      };
    }));

    res.json({ domains: enhanced });
  } catch (err) {
    res.status(500).json({ error: 'Failed fetching domains.' });
  }
});

// Add custom domain
router.post('/', requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user!;
    const { projectId, domain } = req.body;

    if (!projectId || !domain) {
      res.status(400).json({ error: 'Project ID and domain are required.' });
      return;
    }

    const cleanDomain = domain.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, '');
    if (!cleanDomain.includes('.') || cleanDomain.length < 4) {
      res.status(400).json({ error: 'Please enter a valid fully qualified domain name (e.g., example.com or app.example.com).' });
      return;
    }

    const project = await db.findProjectById(projectId);
    if (!project || (project.user_id !== user.id && user.role !== 'admin')) {
      res.status(403).json({ error: 'Unauthorized project.' });
      return;
    }

    // Check if domain already registered
    const existing = await db.findDomainByName(cleanDomain);
    if (existing) {
      res.status(400).json({ error: `Domain "${cleanDomain}" is already connected to another project.` });
      return;
    }

    // Check domain limits based on plan
    const userDomains = await db.listDomainsByUserId(user.id);
    const plans = await db.getSetting<any[]>('plans', []);
    const currentPlan = plans.find(p => p.id === user.plan_tier) || { max_custom_domains: 1 };

    if (userDomains.length >= currentPlan.max_custom_domains) {
      res.status(403).json({
        error: `Custom domain limit reached (${currentPlan.max_custom_domains} max on ${user.plan_tier.toUpperCase()} tier). Upgrade your plan to connect more domains.`
      });
      return;
    }

    const verificationToken = crypto.randomBytes(16).toString('hex');
    const domainRecord = await db.createDomain({
      project_id: project.id,
      user_id: user.id,
      domain: cleanDomain,
      verification_type: 'cname',
      verification_token: verificationToken,
      is_verified: false,
      ssl_status: 'pending',
      dns_records: [
        {
          type: 'CNAME',
          name: cleanDomain.startsWith('www.') ? 'www' : '@',
          value: config.baseDeployDomain
        },
        {
          type: 'TXT',
          name: `_strataflux.${cleanDomain.replace(/^www\./, '')}`,
          value: `strataflux-verification=${verificationToken}`
        }
      ]
    });

    await db.logActivity({
      actor_id: user.id,
      actor_email: user.email,
      actor_role: user.role,
      action: 'domain.add',
      resource_type: 'domain',
      resource_id: domainRecord.id,
      details: { domain: cleanDomain, project: project.name },
      ip_address: req.ip
    });

    res.json({
      domain: {
        ...domainRecord,
        projectName: project.name,
        projectSubdomain: project.subdomain
      }
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed connecting domain.' });
  }
});

// Verify custom domain DNS
router.post('/:id/verify', requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user!;
    const domainRecord = await db.findDomainById(req.params.id);

    if (!domainRecord) {
      res.status(404).json({ error: 'Domain not found.' });
      return;
    }

    if (domainRecord.user_id !== user.id && user.role !== 'admin') {
      res.status(403).json({ error: 'Unauthorized.' });
      return;
    }

    const check = await dnsService.verifyCustomDomain(domainRecord.domain, domainRecord.verification_token);

    const updated = await db.updateDomain(domainRecord.id, {
      is_verified: check.verified,
      ssl_status: check.sslStatus,
      verified_at: check.verified ? new Date().toISOString() : undefined
    });

    if (check.verified) {
      await db.createNotification(
        user.id,
        'Domain Verified & SSL Active',
        `Your domain ${domainRecord.domain} has been verified and provisioned with Anycast SSL.`,
        'success'
      );
    }

    res.json({
      domain: updated,
      check
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed verifying domain DNS.' });
  }
});

// Delete custom domain
router.delete('/:id', requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user!;
    const domainRecord = await db.findDomainById(req.params.id);

    if (!domainRecord) {
      res.status(404).json({ error: 'Domain not found.' });
      return;
    }

    if (domainRecord.user_id !== user.id && user.role !== 'admin') {
      res.status(403).json({ error: 'Unauthorized.' });
      return;
    }

    await db.deleteDomain(domainRecord.id);

    await db.logActivity({
      actor_id: user.id,
      actor_email: user.email,
      actor_role: user.role,
      action: 'domain.delete',
      resource_type: 'domain',
      resource_id: domainRecord.id,
      details: { domain: domainRecord.domain },
      ip_address: req.ip
    });

    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Failed deleting domain.' });
  }
});

export default router;
