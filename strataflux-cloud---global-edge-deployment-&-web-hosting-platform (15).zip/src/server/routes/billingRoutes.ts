import { Router, Request, Response } from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { db, PaymentRecord } from '../db';
import { requireAuth } from '../auth';
import { config } from '../config';
import { storage } from '../storage';

const router = Router();

// Configure multer for payment screenshots
const upload = multer({
  dest: path.resolve(config.storageDir, 'tmp_payments'),
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB max receipt
  fileFilter: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const allowed = ['.png', '.jpg', '.jpeg', '.webp', '.pdf'];
    if (allowed.includes(ext)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid receipt file type. Please upload PNG, JPG, WEBP, or PDF.'));
    }
  }
});

// Ensure tmp directory exists
if (!fs.existsSync(path.resolve(config.storageDir, 'tmp_payments'))) {
  fs.mkdirSync(path.resolve(config.storageDir, 'tmp_payments'), { recursive: true });
}

// 1. Public: Get all subscription plans
router.get('/plans', async (req: Request, res: Response) => {
  try {
    const plans = await db.getSetting<any[]>('plans', []);
    res.json({ plans });
  } catch (err) {
    res.status(500).json({ error: 'Failed retrieving plans.' });
  }
});

// 2. Public / Authenticated: Get all currently enabled payment methods & instructions
router.get('/methods', async (req: Request, res: Response) => {
  try {
    const settings = await db.getSetting<any>('payment_settings', {});
    
    const stripeConfig = settings.stripe || {};
    const paypalConfig = settings.paypal || {};
    const payoneerConfig = settings.payoneer || {};
    const jazzcashConfig = settings.jazzcash || {};
    const easypaisaConfig = settings.easypaisa || {};

    const stripeEnabled = stripeConfig.enabled !== undefined ? Boolean(stripeConfig.enabled) : config.stripeEnabled;
    const paypalEnabled = paypalConfig.enabled !== undefined ? Boolean(paypalConfig.enabled) : config.paypalEnabled;
    const payoneerEnabled = payoneerConfig.enabled !== undefined ? Boolean(payoneerConfig.enabled) : config.payoneerEnabled;
    const jazzcashEnabled = jazzcashConfig.enabled !== undefined ? Boolean(jazzcashConfig.enabled) : config.jazzcashEnabled;
    const easypaisaEnabled = easypaisaConfig.enabled !== undefined ? Boolean(easypaisaConfig.enabled) : config.easypaisaEnabled;

    const methods = [
      {
        id: 'stripe',
        name: 'Credit / Debit Card (Stripe)',
        type: 'gateway',
        enabled: stripeEnabled,
        icon: 'CreditCard',
        description: 'Instant automated checkout with Visa, Mastercard, American Express, or Apple Pay.',
        publishableKey: stripeConfig.publishable_key || config.stripePublishableKey || '',
        currencies: ['usd', 'eur', 'gbp', 'cad', 'aud']
      },
      {
        id: 'paypal',
        name: 'PayPal',
        type: 'gateway',
        enabled: paypalEnabled,
        icon: 'Wallet',
        description: 'Pay securely using your PayPal balance or linked bank/card account.',
        clientId: paypalConfig.client_id || config.paypalClientId || '',
        mode: paypalConfig.mode || config.paypalMode || 'sandbox',
        currencies: ['usd', 'eur', 'gbp']
      },
      {
        id: 'payoneer',
        name: 'Payoneer Transfer',
        type: 'manual',
        enabled: payoneerEnabled,
        icon: 'Send',
        description: 'Direct global payment via Payoneer account balance or bank wire.',
        accountName: payoneerConfig.account_name || config.payoneerAccountName,
        accountEmail: payoneerConfig.account_email || config.payoneerAccountEmail,
        instructions: payoneerConfig.instructions || config.payoneerInstructions,
        currencies: ['usd', 'eur', 'gbp']
      },
      {
        id: 'jazzcash',
        name: 'JazzCash (Pakistan)',
        type: 'manual',
        enabled: jazzcashConfig.enabled,
        icon: 'Smartphone',
        description: 'Instant mobile account payment across Pakistan via JazzCash App or *786#.',
        accountName: jazzcashConfig.account_name || config.jazzcashAccountName,
        accountNumber: jazzcashConfig.account_number || config.jazzcashAccountNumber,
        instructions: jazzcashConfig.instructions || config.jazzcashInstructions,
        currencies: ['pkr', 'usd']
      },
      {
        id: 'easypaisa',
        name: 'Easypaisa (Pakistan)',
        type: 'manual',
        enabled: easypaisaEnabled,
        icon: 'Smartphone',
        description: 'Instant mobile wallet payment across Pakistan via Easypaisa App or *786#.',
        accountName: easypaisaConfig.account_name || config.easypaisaAccountName,
        accountNumber: easypaisaConfig.account_number || config.easypaisaAccountNumber,
        instructions: easypaisaConfig.instructions || config.easypaisaInstructions,
        currencies: ['pkr', 'usd']
      }
    ];

    // Ensure jazzcashEnabled uses the computed boolean
    methods[3].enabled = jazzcashEnabled;

    res.json({ methods });
  } catch (err) {
    res.status(500).json({ error: 'Failed loading payment methods.' });
  }
});

// 3. User: Get current billing & subscription details
router.get('/subscription', requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user!;
    const plans = await db.getSetting<any[]>('plans', []);
    const currentPlan = plans.find(p => p.id === user.plan_tier) || plans[0];

    const projects = await db.listProjectsByUserId(user.id);
    const domains = await db.listDomainsByUserId(user.id);

    const totalStorage = projects.reduce((acc, p) => acc + p.storage_used_bytes, 0);
    const totalBandwidth = projects.reduce((acc, p) => acc + p.bandwidth_used_bytes, 0);

    res.json({
      plan: currentPlan,
      usage: {
        projectsCount: projects.length,
        maxProjects: currentPlan?.max_projects || 3,
        customDomainsCount: domains.length,
        maxCustomDomains: currentPlan?.max_custom_domains || 1,
        storageBytesUsed: totalStorage,
        storageLimitBytes: (currentPlan?.storage_limit_mb || 500) * 1024 * 1024,
        bandwidthBytesUsed: totalBandwidth,
        bandwidthLimitBytes: (currentPlan?.bandwidth_limit_gb || 10) * 1024 * 1024 * 1024
      }
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed retrieving subscription details.' });
  }
});

// 4. User: List payment transaction history
router.get('/payments', requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user!;
    const payments = await db.listPaymentsByUserId(user.id);
    res.json({ payments });
  } catch (err) {
    res.status(500).json({ error: 'Failed retrieving payment history.' });
  }
});

// 5. Submit Manual Payment (Payoneer / JazzCash / Easypaisa)
router.post('/manual-payment', requireAuth, upload.single('screenshot'), async (req: Request, res: Response) => {
  let tempFilePath: string | null = null;
  try {
    const user = req.user!;
    const {
      planId,
      interval = 'monthly',
      provider,
      transactionId,
      amount,
      currency = 'USD',
      customerNote
    } = req.body;

    if (!planId || !provider || !transactionId) {
      res.status(400).json({ error: 'Plan, payment provider, and transaction/reference ID are required.' });
      return;
    }

    const validProviders = ['payoneer', 'jazzcash', 'easypaisa', 'manual'];
    if (!validProviders.includes(provider.toLowerCase())) {
      res.status(400).json({ error: 'Invalid manual payment provider specified.' });
      return;
    }

    const plans = await db.getSetting<any[]>('plans', []);
    const selectedPlan = plans.find(p => p.id === planId);
    if (!selectedPlan) {
      res.status(400).json({ error: 'Selected plan not found.' });
      return;
    }

    // Handle receipt screenshot
    let screenshotUrl = '';
    if (req.file) {
      tempFilePath = req.file.path;
      const buffer = fs.readFileSync(tempFilePath);
      screenshotUrl = await storage.savePaymentScreenshot(req.file.originalname, buffer);
      // Clean up tmp file
      fs.unlinkSync(tempFilePath);
      tempFilePath = null;
    }

    const numericAmount = parseFloat(amount) || (interval === 'yearly' ? selectedPlan.price_yearly : selectedPlan.price_monthly);

    // Create Payment Record with PENDING status
    const payment = await db.createPayment({
      user_id: user.id,
      user_email: user.email,
      user_name: user.name,
      plan_tier: selectedPlan.id,
      plan_name: selectedPlan.name,
      billing_interval: interval === 'yearly' ? 'yearly' : 'monthly',
      amount: numericAmount,
      currency: (currency || 'USD').toUpperCase(),
      provider: provider.toLowerCase() as any,
      payment_method: provider.toUpperCase(),
      transaction_id: transactionId.trim(),
      screenshot_path: screenshotUrl,
      status: 'pending',
      customer_note: customerNote ? customerNote.trim() : undefined
    });

    // Notify user
    await db.createNotification(
      user.id,
      'Payment Verification Submitted',
      `Your ${payment.payment_method} payment of ${payment.currency} ${payment.amount} (Ref: ${payment.transaction_id}) is under review. Our administrative team will verify and activate your ${selectedPlan.name} plan shortly.`,
      'info'
    );

    // Log Activity for Audit
    await db.logActivity({
      actor_id: user.id,
      actor_email: user.email,
      actor_role: user.role,
      action: 'payment.submitted',
      resource_type: 'payment',
      resource_id: payment.id,
      details: {
        provider,
        plan: selectedPlan.name,
        amount: payment.amount,
        currency: payment.currency,
        transactionId: payment.transaction_id
      },
      ip_address: req.ip
    });

    res.json({
      success: true,
      message: 'Payment reference submitted successfully for verification.',
      payment
    });
  } catch (err: any) {
    if (tempFilePath && fs.existsSync(tempFilePath)) {
      try { fs.unlinkSync(tempFilePath); } catch (e) {}
    }
    console.error('[MANUAL PAYMENT ERROR]', err);
    res.status(500).json({ error: err.message || 'Failed submitting manual payment verification.' });
  }
});

// 6. Automated Payment Gateway Checkout (Stripe / PayPal)
router.post('/create-checkout', requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user!;
    const { planId, interval = 'monthly', provider = 'stripe' } = req.body;

    const plans = await db.getSetting<any[]>('plans', []);
    const selectedPlan = plans.find(p => p.id === planId);
    if (!selectedPlan) {
      res.status(400).json({ error: 'Selected plan does not exist.' });
      return;
    }

    const price = interval === 'yearly' ? selectedPlan.price_yearly : selectedPlan.price_monthly;

    if (provider === 'stripe') {
      if (config.stripeSecretKey && config.stripeSecretKey.startsWith('sk_')) {
        // Real Stripe Session creation placeholder
        res.json({
          provider: 'stripe',
          checkoutUrl: `https://checkout.stripe.com/pay/cs_live_${Date.now()}`,
          message: 'Redirecting to secure Stripe Checkout.'
        });
        return;
      } else {
        res.status(400).json({
          error: 'Stripe live credentials are not yet configured in platform settings. Please select Payoneer, JazzCash, or Easypaisa, or contact platform administrator.'
        });
        return;
      }
    }

    if (provider === 'paypal') {
      if (config.paypalClientId && config.paypalClientSecret) {
        res.json({
          provider: 'paypal',
          approvalUrl: `https://www.paypal.com/checkoutnow?token=EC-${Date.now()}`,
          message: 'Redirecting to PayPal Checkout.'
        });
        return;
      } else {
        res.status(400).json({
          error: 'PayPal live credentials are not yet configured in platform settings. Please select Payoneer, JazzCash, or Easypaisa, or contact platform administrator.'
        });
        return;
      }
    }

    res.status(400).json({ error: 'Unsupported automated checkout provider.' });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Checkout initiation failed.' });
  }
});

// 7. Secure Payment Receipt Serving (for uploaded screenshots)
router.get('/receipts/:filename', async (req: Request, res: Response) => {
  try {
    const filename = path.basename(req.params.filename);
    const receiptPath = path.resolve(storage.getPaymentsDir(), filename);

    if (!fs.existsSync(receiptPath)) {
      res.status(404).send('Receipt not found.');
      return;
    }

    res.sendFile(receiptPath);
  } catch (err) {
    res.status(500).send('Error serving receipt.');
  }
});

// 8. Cancel subscription
router.post('/cancel', requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user!;
    const plans = await db.getSetting<any[]>('plans', []);
    const freePlan = plans.find(p => p.id === 'free') || { max_custom_domains: 1, storage_limit_mb: 500, bandwidth_limit_gb: 10 };

    await db.updateUser(user.id, {
      plan_tier: 'free',
      custom_domain_limit: freePlan.max_custom_domains,
      storage_limit_bytes: freePlan.storage_limit_mb * 1024 * 1024,
      bandwidth_limit_bytes: freePlan.bandwidth_limit_gb * 1024 * 1024 * 1024
    });

    await db.createNotification(
      user.id,
      'Subscription Cancelled',
      'Your account has reverted to the free Starter tier.',
      'info'
    );

    res.json({ success: true, message: 'Subscription cancelled. Reverted to Free tier.' });
  } catch (err) {
    res.status(500).json({ error: 'Failed cancelling subscription.' });
  }
});

// 9. Stripe Webhook Listener
router.post('/webhook/stripe', (req: Request, res: Response) => {
  const sig = req.headers['stripe-signature'];
  console.log('[STRIPE WEBHOOK] Received webhook event');
  res.json({ received: true });
});

// 10. PayPal Webhook Listener
router.post('/webhook/paypal', (req: Request, res: Response) => {
  console.log('[PAYPAL WEBHOOK] Received webhook event');
  res.json({ received: true });
});

export default router;
