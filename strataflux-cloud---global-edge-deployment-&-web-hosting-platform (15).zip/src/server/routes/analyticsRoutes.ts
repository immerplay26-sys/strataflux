import { Router, Request, Response } from 'express';
import { db } from '../db';
import { requireAuth, requireAdmin } from '../auth';

const router = Router();

// Project-level website analytics (strictly isolated to project owner or admin)
router.get('/project/:projectId', requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user!;
    const project = await db.findProjectById(req.params.projectId);

    if (!project) {
      res.status(404).json({ error: 'Project not found.' });
      return;
    }

    if (project.user_id !== user.id && user.role !== 'admin') {
      res.status(403).json({ error: 'Unauthorized access to website analytics.' });
      return;
    }

    const days = parseInt(req.query.days as string || '30', 10);
    const data = await db.getProjectAnalytics(project.id, days);

    res.json({
      project: {
        id: project.id,
        name: project.name,
        subdomain: project.subdomain
      },
      ...data
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed loading analytics.' });
  }
});

// User aggregate analytics across all their projects
router.get('/overview', requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user!;
    const projects = await db.listProjectsByUserId(user.id);
    const days = parseInt(req.query.days as string || '30', 10);

    let totalViews = 0;
    let totalBandwidth = 0;
    const projectBreakdown = [];

    for (const p of projects) {
      const pStats = await db.getProjectAnalytics(p.id, days);
      totalViews += pStats.summary.totalViews;
      totalBandwidth += pStats.summary.totalBandwidthBytes;
      projectBreakdown.push({
        id: p.id,
        name: p.name,
        subdomain: p.subdomain,
        views: pStats.summary.totalViews,
        visitors: pStats.summary.uniqueVisitors,
        bandwidth: pStats.summary.totalBandwidthBytes
      });
    }

    res.json({
      summary: {
        totalProjects: projects.length,
        totalViews,
        totalBandwidthBytes: totalBandwidth
      },
      projects: projectBreakdown
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed calculating overview analytics.' });
  }
});

// Platform-wide analytics (Admin only)
router.get('/admin', requireAdmin, async (req: Request, res: Response) => {
  try {
    const days = parseInt(req.query.days as string || '30', 10);
    const data = await db.getGlobalAnalytics(days);
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: 'Failed retrieving platform analytics.' });
  }
});

export default router;
