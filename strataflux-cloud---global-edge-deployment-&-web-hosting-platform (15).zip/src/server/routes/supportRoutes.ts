import { Router, Request, Response } from 'express';
import { db } from '../db';
import { requireAuth } from '../auth';

const router = Router();

// List user's support tickets
router.get('/tickets', requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user!;
    const tickets = await db.listTicketsByUserId(user.id);
    res.json({ tickets });
  } catch (err) {
    res.status(500).json({ error: 'Failed retrieving tickets.' });
  }
});

// Create new support ticket
router.post('/tickets', requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user!;
    const { subject, category = 'technical', priority = 'medium', message } = req.body;

    if (!subject || !message) {
      res.status(400).json({ error: 'Subject and message are required.' });
      return;
    }

    const ticket = await db.createTicket({
      user_id: user.id,
      user_email: user.email,
      user_name: user.name,
      subject: subject.trim(),
      category,
      priority,
      status: 'open',
      initialMessage: message.trim()
    });

    await db.logActivity({
      actor_id: user.id,
      actor_email: user.email,
      actor_role: user.role,
      action: 'ticket.created',
      resource_type: 'support_ticket',
      resource_id: ticket.id,
      details: { subject: ticket.subject, category: ticket.category },
      ip_address: req.ip
    });

    res.json({ ticket });
  } catch (err) {
    res.status(500).json({ error: 'Failed submitting support ticket.' });
  }
});

// Get ticket details and conversation
router.get('/tickets/:id', requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user!;
    const ticket = await db.getTicketById(req.params.id);

    if (!ticket) {
      res.status(404).json({ error: 'Ticket not found.' });
      return;
    }

    if (ticket.user_id !== user.id && user.role !== 'admin') {
      res.status(403).json({ error: 'Unauthorized.' });
      return;
    }

    res.json({ ticket });
  } catch (err) {
    res.status(500).json({ error: 'Failed retrieving ticket.' });
  }
});

// Reply to ticket
router.post('/tickets/:id/reply', requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user!;
    const { content } = req.body;

    if (!content || !content.trim()) {
      res.status(400).json({ error: 'Reply content cannot be empty.' });
      return;
    }

    const ticket = await db.getTicketById(req.params.id);
    if (!ticket) {
      res.status(404).json({ error: 'Ticket not found.' });
      return;
    }

    if (ticket.user_id !== user.id && user.role !== 'admin') {
      res.status(403).json({ error: 'Unauthorized.' });
      return;
    }

    const updated = await db.addTicketMessage(
      ticket.id,
      user.id,
      user.name,
      user.role === 'admin' ? 'admin' : 'user',
      content.trim()
    );

    res.json({ ticket: updated });
  } catch (err) {
    res.status(500).json({ error: 'Failed adding reply.' });
  }
});

export default router;
