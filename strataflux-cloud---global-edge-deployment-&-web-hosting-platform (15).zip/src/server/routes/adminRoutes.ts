import { Router, Request, Response } from 'express';
import os from 'os';
import { db } from '../db';
import { requireAdmin, hashPassword, comparePassword } from '../auth';
import { storage } from '../storage';
import { dnsService } from '../dns';
import { config, getServicesStatus } from '../config';

const router = Router();

// Apply requireAdmin to all routes in this router
router.use(requireAdmin);

// 1. Admin Overview
router.get('/overview', async (req: Request, res: Response) => {
  try {
    const users = await db.listUsers();
    const projects = await db.listAllProjects();
    const deployments = await db.listAllDeployments();
    const domains = await db.listAllDomains();
    const tickets = await db.listAllTickets();
    const activity = await db.listActivityLogs(10);
    const globalAnalytics = await db.getGlobalAnalytics(30);

    const totalStorage = projects.reduce((acc, p) => acc + (p.storage_used_bytes || 0), 0);
    const totalBandwidth = projects.reduce((acc, p) => acc + (p.bandwidth_used_bytes || 0), 0);

    res.json({
      metrics: {
        totalUsers: users.length,
        activeUsers: users.filter(u => u.status === 'active').length,
        totalProjects: projects.length,
        totalDeployments: deployments.length,
        successfulDeployments: deployments.filter(d => d.status === 'live').length,
        failedDeployments: deployments.filter(d => d.status === 'failed').length,
        totalDomains: domains.length,
        verifiedDomains: domains.filter(d => d.is_verified).length,
        openTickets: tickets.filter(t => t.status === 'open' || t.status === 'in_progress').length,
        totalStorageBytes: totalStorage,
        totalBandwidthBytes: totalBandwidth,
        totalViews30d: globalAnalytics.totalViews,
        uniqueVisitors30d: globalAnalytics.uniqueVisitors
      },
      recentActivity: activity,
      recentDeployments: deployments.slice(0, 8),
      recentUsers: users.slice(0, 8).map(u => ({
        id: u.id,
        email: u.email,
        name: u.name,
        role: u.role,
        status: u.status,
        plan_tier: u.plan_tier,
        created_at: u.created_at
      }))
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed loading admin overview.' });
  }
});

// 2. Users Management
router.get('/users', async (req: Request, res: Response) => {
  try {
    const search = req.query.search as string;
    const users = await db.listUsers(search);
    const safeUsers = users.map(u => ({
      id: u.id,
      email: u.email,
      name: u.name,
      role: u.role,
      status: u.status,
      plan_tier: u.plan_tier,
      created_at: u.created_at,
      updated_at: u.updated_at
    }));
    res.json({ users: safeUsers });
  } catch (err) {
    res.status(500).json({ error: 'Failed loading users.' });
  }
});

router.put('/users/:id', async (req: Request, res: Response) => {
  try {
    const { status, role, plan_tier } = req.body;
    const updates: any = {};
    if (status) updates.status = status;
    if (role) updates.role = role;
    if (plan_tier) updates.plan_tier = plan_tier;

    const user = await db.updateUser(req.params.id, updates);
    if (!user) {
      res.status(404).json({ error: 'User not found.' });
      return;
    }

    await db.logActivity({
      actor_id: req.user!.id,
      actor_email: req.user!.email,
      actor_role: 'admin',
      action: 'admin.user_update',
      resource_type: 'user',
      resource_id: user.id,
      details: updates,
      ip_address: req.ip
    });

    res.json({ user });
  } catch (err) {
    res.status(500).json({ error: 'Failed updating user.' });
  }
});

router.delete('/users/:id', async (req: Request, res: Response) => {
  try {
    if (req.params.id === req.user!.id) {
      res.status(400).json({ error: 'Cannot delete your own active administrator account.' });
      return;
    }

    await db.deleteUser(req.params.id);

    await db.logActivity({
      actor_id: req.user!.id,
      actor_email: req.user!.email,
      actor_role: 'admin',
      action: 'admin.user_delete',
      resource_type: 'user',
      resource_id: req.params.id,
      ip_address: req.ip
    });

    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Failed deleting user.' });
  }
});

// 3. Projects Management
router.get('/projects', async (req: Request, res: Response) => {
  try {
    const projects = await db.listAllProjects();
    const enhanced = await Promise.all(projects.map(async p => {
      const owner = await db.findUserById(p.user_id);
      return {
        ...p,
        ownerEmail: owner?.email || 'Deleted User',
        ownerName: owner?.name || 'Unknown'
      };
    }));
    res.json({ projects: enhanced });
  } catch (err) {
    res.status(500).json({ error: 'Failed loading projects.' });
  }
});

router.delete('/projects/:id', async (req: Request, res: Response) => {
  try {
    const project = await db.findProjectById(req.params.id);
    if (!project) {
      res.status(404).json({ error: 'Project not found.' });
      return;
    }

    const deployments = await db.listDeploymentsByProjectId(project.id);
    for (const d of deployments) {
      storage.deleteDeploymentFiles(d.id);
    }
    await db.deleteProject(project.id);

    await db.logActivity({
      actor_id: req.user!.id,
      actor_email: req.user!.email,
      actor_role: 'admin',
      action: 'admin.project_delete',
      resource_type: 'project',
      resource_id: project.id,
      details: { name: project.name, subdomain: project.subdomain },
      ip_address: req.ip
    });

    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Failed deleting project.' });
  }
});

// 4. Deployments Management
router.get('/deployments', async (req: Request, res: Response) => {
  try {
    const deployments = await db.listAllDeployments();
    const enhanced = await Promise.all(deployments.map(async d => {
      const project = await db.findProjectById(d.project_id);
      const user = await db.findUserById(d.user_id);
      return {
        ...d,
        projectName: project?.name || 'Unknown Project',
        projectSubdomain: project?.subdomain || '',
        userEmail: user?.email || 'Unknown User'
      };
    }));
    res.json({ deployments: enhanced });
  } catch (err) {
    res.status(500).json({ error: 'Failed loading deployments.' });
  }
});

router.delete('/deployments/:id', async (req: Request, res: Response) => {
  try {
    const deployment = await db.findDeploymentById(req.params.id);
    if (!deployment) {
      res.status(404).json({ error: 'Deployment not found.' });
      return;
    }

    storage.deleteDeploymentFiles(deployment.id);
    await db.deleteDeployment(deployment.id);

    await db.logActivity({
      actor_id: req.user!.id,
      actor_email: req.user!.email,
      actor_role: 'admin',
      action: 'admin.deployment_delete',
      resource_type: 'deployment',
      resource_id: deployment.id,
      ip_address: req.ip
    });

    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Failed deleting deployment.' });
  }
});

// 5. Domains Management
router.get('/domains', async (req: Request, res: Response) => {
  try {
    const domains = await db.listAllDomains();
    const enhanced = await Promise.all(domains.map(async d => {
      const project = await db.findProjectById(d.project_id);
      const user = await db.findUserById(d.user_id);
      return {
        ...d,
        projectName: project?.name || 'Unknown',
        projectSubdomain: project?.subdomain || '',
        userEmail: user?.email || 'Unknown'
      };
    }));
    res.json({ domains: enhanced });
  } catch (err) {
    res.status(500).json({ error: 'Failed loading domains.' });
  }
});

router.post('/domains/:id/force-verify', async (req: Request, res: Response) => {
  try {
    const domain = await db.findDomainById(req.params.id);
    if (!domain) {
      res.status(404).json({ error: 'Domain not found.' });
      return;
    }

    const updated = await db.updateDomain(domain.id, {
      is_verified: true,
      ssl_status: 'active',
      verified_at: new Date().toISOString()
    });

    res.json({ domain: updated });
  } catch (err) {
    res.status(500).json({ error: 'Failed force verifying domain.' });
  }
});

// 6. Plans & Pricing Management
router.get('/plans', async (req: Request, res: Response) => {
  try {
    const plans = await db.getSetting<any[]>('plans', []);
    res.json({ plans });
  } catch (err) {
    res.status(500).json({ error: 'Failed loading plans.' });
  }
});

router.put('/plans', async (req: Request, res: Response) => {
  try {
    const { plans } = req.body;
    if (!Array.isArray(plans)) {
      res.status(400).json({ error: 'Plans must be an array.' });
      return;
    }

    await db.setSetting('plans', plans);
    res.json({ success: true, plans });
  } catch (err) {
    res.status(500).json({ error: 'Failed updating plans.' });
  }
});

// 6b. Payment Verifications & Transactions Management
router.get('/payments', async (req: Request, res: Response) => {
  try {
    const status = req.query.status as string;
    let payments = await db.listAllPayments();
    if (status && status !== 'all') {
      payments = payments.filter(p => p.status === status);
    }

    const enhanced = await Promise.all(payments.map(async p => {
      const user = await db.findUserById(p.user_id);
      return {
        ...p,
        user_name: user?.name || p.user_name || 'User',
        user_email: user?.email || p.user_email || 'N/A'
      };
    }));

    res.json({ payments: enhanced });
  } catch (err) {
    res.status(500).json({ error: 'Failed loading payments.' });
  }
});

router.get('/payments/:id', async (req: Request, res: Response) => {
  try {
    const payment = await db.findPaymentById(req.params.id);
    if (!payment) {
      res.status(404).json({ error: 'Payment record not found.' });
      return;
    }
    const user = await db.findUserById(payment.user_id);
    res.json({
      payment: {
        ...payment,
        user_name: user?.name || payment.user_name,
        user_email: user?.email || payment.user_email
      }
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed retrieving payment details.' });
  }
});

router.post('/payments/:id/approve', async (req: Request, res: Response) => {
  try {
    const admin = req.user!;
    const { note } = req.body;
    const result = await db.approvePayment(req.params.id, admin.id, note);
    if (!result) {
      res.status(404).json({ error: 'Payment not found or already processed.' });
      return;
    }
    res.json({ success: true, payment: result.payment, user: result.user });
  } catch (err) {
    res.status(500).json({ error: 'Failed approving payment.' });
  }
});

router.post('/payments/:id/reject', async (req: Request, res: Response) => {
  try {
    const admin = req.user!;
    const { note } = req.body;
    const payment = await db.rejectPayment(req.params.id, admin.id, note);
    if (!payment) {
      res.status(404).json({ error: 'Payment not found.' });
      return;
    }
    res.json({ success: true, payment });
  } catch (err) {
    res.status(500).json({ error: 'Failed rejecting payment.' });
  }
});

// 6c. Payment Provider Settings
router.get('/payment-settings', async (req: Request, res: Response) => {
  try {
    const settings = await db.getSetting<any>('payment_settings', {});
    const safeSettings = {
      stripe: {
        enabled: settings.stripe?.enabled !== undefined ? Boolean(settings.stripe.enabled) : config.stripeEnabled,
        publishable_key: settings.stripe?.publishable_key || config.stripePublishableKey || '',
        isConfigured: Boolean(config.stripeSecretKey && config.stripeSecretKey.startsWith('sk_'))
      },
      paypal: {
        enabled: settings.paypal?.enabled !== undefined ? Boolean(settings.paypal.enabled) : config.paypalEnabled,
        client_id: settings.paypal?.client_id || config.paypalClientId || '',
        mode: settings.paypal?.mode || config.paypalMode || 'sandbox',
        isConfigured: Boolean(config.paypalClientId && config.paypalClientSecret)
      },
      payoneer: {
        enabled: settings.payoneer?.enabled !== undefined ? Boolean(settings.payoneer.enabled) : config.payoneerEnabled,
        account_name: settings.payoneer?.account_name || config.payoneerAccountName,
        account_email: settings.payoneer?.account_email || config.payoneerAccountEmail,
        instructions: settings.payoneer?.instructions || config.payoneerInstructions
      },
      jazzcash: {
        enabled: settings.jazzcash?.enabled !== undefined ? Boolean(settings.jazzcash.enabled) : config.jazzcashEnabled,
        account_name: settings.jazzcash?.account_name || config.jazzcashAccountName,
        account_number: settings.jazzcash?.account_number || config.jazzcashAccountNumber,
        instructions: settings.jazzcash?.instructions || config.jazzcashInstructions
      },
      easypaisa: {
        enabled: settings.easypaisa?.enabled !== undefined ? Boolean(settings.easypaisa.enabled) : config.easypaisaEnabled,
        account_name: settings.easypaisa?.account_name || config.easypaisaAccountName,
        account_number: settings.easypaisa?.account_number || config.easypaisaAccountNumber,
        instructions: settings.easypaisa?.instructions || config.easypaisaInstructions
      }
    };
    res.json({ settings: safeSettings });
  } catch (err) {
    res.status(500).json({ error: 'Failed loading payment settings.' });
  }
});

router.put('/payment-settings', async (req: Request, res: Response) => {
  try {
    const settings = req.body.settings;
    if (!settings) {
      res.status(400).json({ error: 'Settings object required.' });
      return;
    }
    await db.setSetting('payment_settings', settings);

    await db.logActivity({
      actor_id: req.user!.id,
      actor_role: 'admin',
      action: 'payment_settings.updated',
      resource_type: 'settings',
      details: { updatedKeys: Object.keys(settings) }
    });

    res.json({ success: true, settings });
  } catch (err) {
    res.status(500).json({ error: 'Failed saving payment settings.' });
  }
});

// 7. Support Tickets Management
router.get('/support', async (req: Request, res: Response) => {
  try {
    const tickets = await db.listAllTickets();
    res.json({ tickets });
  } catch (err) {
    res.status(500).json({ error: 'Failed loading tickets.' });
  }
});

router.put('/support/:id/status', async (req: Request, res: Response) => {
  try {
    const { status } = req.body;
    const ticket = await db.updateTicketStatus(req.params.id, status);
    res.json({ ticket });
  } catch (err) {
    res.status(500).json({ error: 'Failed updating ticket status.' });
  }
});

router.post('/support/:id/reply', async (req: Request, res: Response) => {
  try {
    const { content } = req.body;
    const admin = req.user!;
    const ticket = await db.addTicketMessage(
      req.params.id,
      admin.id,
      admin.name,
      'admin',
      content
    );
    res.json({ ticket });
  } catch (err) {
    res.status(500).json({ error: 'Failed replying to ticket.' });
  }
});

// 8. Website Settings & SEO
router.get('/settings', async (req: Request, res: Response) => {
  try {
    const all = await db.getAllSettings();
    res.json({ settings: all });
  } catch (err) {
    res.status(500).json({ error: 'Failed loading settings.' });
  }
});

router.put('/settings/:section', async (req: Request, res: Response) => {
  try {
    const section = req.params.section;
    const value = req.body;
    await db.setSetting(section, value);
    res.json({ success: true, section, value });
  } catch (err) {
    res.status(500).json({ error: 'Failed updating setting.' });
  }
});

// 9. Activity & Security Logs
router.get('/logs', async (req: Request, res: Response) => {
  try {
    const limit = parseInt(req.query.limit as string || '100', 10);
    const logs = await db.listActivityLogs(limit);
    res.json({ logs });
  } catch (err) {
    res.status(500).json({ error: 'Failed loading activity logs.' });
  }
});

// 10. System Health & Backups
router.get('/system-health', async (req: Request, res: Response) => {
  try {
    const memory = process.memoryUsage();
    const systemMemory = {
      total: os.totalmem(),
      free: os.freemem(),
      usagePercent: Math.round(((os.totalmem() - os.freemem()) / os.totalmem()) * 100)
    };

    res.json({
      uptimeSeconds: process.uptime(),
      nodeVersion: process.version,
      platform: process.platform,
      arch: process.arch,
      processMemory: {
        rssMb: Math.round(memory.rss / 1024 / 1024),
        heapUsedMb: Math.round(memory.heapUsed / 1024 / 1024),
        heapTotalMb: Math.round(memory.heapTotal / 1024 / 1024)
      },
      systemMemory,
      cpuLoad: os.loadavg(),
      status: 'operational',
      database: config.databaseUrl ? 'postgresql' : 'embedded_json',
      integrations: getServicesStatus()
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed retrieving system health.' });
  }
});

// 10b. External Services & Integrations Status
router.get('/integrations', async (req: Request, res: Response) => {
  try {
    res.json({
      integrations: getServicesStatus()
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed loading integration status.' });
  }
});

router.get('/backup/export', async (req: Request, res: Response) => {
  try {
    const backupJson = db.exportDatabaseJson();
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Content-Disposition', `attachment; filename=strataflux-backup-${new Date().toISOString().split('T')[0]}.json`);
    res.send(backupJson);
  } catch (err) {
    res.status(500).json({ error: 'Failed generating backup export.' });
  }
});

// 11. Admin Profile update
router.put('/profile', async (req: Request, res: Response) => {
  try {
    const admin = req.user!;
    const { name, email, currentPassword, newPassword } = req.body;

    const updates: any = {};
    if (name) updates.name = name.trim();
    if (email && email.toLowerCase() !== admin.email.toLowerCase()) {
      updates.email = email.toLowerCase().trim();
    }

    if (newPassword) {
      if (!currentPassword) {
        res.status(400).json({ error: 'Current password is required to change administrator password.' });
        return;
      }
      const match = await comparePassword(currentPassword, admin.password_hash);
      if (!match) {
        res.status(400).json({ error: 'Current password does not match.' });
        return;
      }
      if (newPassword.length < 8) {
        res.status(400).json({ error: 'New password must be at least 8 characters long.' });
        return;
      }
      updates.password_hash = await hashPassword(newPassword);
    }

    const updated = await db.updateUser(admin.id, updates);
    res.json({
      user: {
        id: updated!.id,
        email: updated!.email,
        name: updated!.name,
        role: updated!.role
      }
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed updating administrator profile.' });
  }
});

export default router;
