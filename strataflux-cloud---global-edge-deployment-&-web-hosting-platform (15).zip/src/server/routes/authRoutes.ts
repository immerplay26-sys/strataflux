import { Router, Request, Response } from 'express';
import crypto from 'crypto';
import { db } from '../db';
import { hashPassword, comparePassword, generateToken, requireAuth, rateLimiter } from '../auth';
import { emailService } from '../email';
import { config } from '../config';

const router = Router();

// Register new user
router.post('/register', rateLimiter(10, 60000), async (req: Request, res: Response) => {
  try {
    const { email, password, name } = req.body;
    if (!email || !password || !name) {
      res.status(400).json({ error: 'Please provide email, password, and name.' });
      return;
    }

    if (password.length < 8) {
      res.status(400).json({ error: 'Password must be at least 8 characters long.' });
      return;
    }

    const existing = await db.findUserByEmail(email);
    if (existing) {
      res.status(400).json({ error: 'An account with this email address already exists.' });
      return;
    }

    const password_hash = await hashPassword(password);
    const user = await db.createUser({
      email,
      name,
      password_hash,
      role: 'user',
      status: 'active',
      email_verified: false,
      two_factor_enabled: false,
      plan_tier: 'free',
      custom_domain_limit: 1,
      storage_limit_bytes: 500 * 1024 * 1024,
      bandwidth_limit_bytes: 10 * 1024 * 1024 * 1024
    });

    const token = generateToken(user);
    res.cookie('strataflux_token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      maxAge: config.tokenExpiryDays * 24 * 60 * 60 * 1000,
      sameSite: 'lax'
    });

    await db.logActivity({
      actor_id: user.id,
      actor_email: user.email,
      actor_role: 'user',
      action: 'user.registered',
      resource_type: 'user',
      resource_id: user.id,
      ip_address: req.ip
    });

    // Send welcome email in background
    emailService.sendWelcomeEmail(user.email, user.name).catch(() => {});

    res.json({
      token,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        plan_tier: user.plan_tier
      }
    });
  } catch (err: any) {
    console.error('[AUTH REGISTER ERROR]', err);
    res.status(500).json({ error: 'Registration failed. Please try again.' });
  }
});

// Login
router.post('/login', rateLimiter(20, 60000), async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      res.status(400).json({ error: 'Email and password are required.' });
      return;
    }

    const user = await db.findUserByEmail(email);
    if (!user) {
      res.status(401).json({ error: 'Invalid email or password.' });
      return;
    }

    if (user.status !== 'active') {
      res.status(403).json({ error: 'Account is suspended or banned. Please contact support.' });
      return;
    }

    const match = await comparePassword(password, user.password_hash);
    if (!match) {
      res.status(401).json({ error: 'Invalid email or password.' });
      return;
    }

    const token = generateToken(user);
    res.cookie('strataflux_token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      maxAge: config.tokenExpiryDays * 24 * 60 * 60 * 1000,
      sameSite: 'lax'
    });

    await db.logActivity({
      actor_id: user.id,
      actor_email: user.email,
      actor_role: user.role,
      action: 'user.login',
      resource_type: 'user',
      resource_id: user.id,
      ip_address: req.ip
    });

    res.json({
      token,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        plan_tier: user.plan_tier,
        two_factor_enabled: user.two_factor_enabled
      }
    });
  } catch (err) {
    console.error('[AUTH LOGIN ERROR]', err);
    res.status(500).json({ error: 'Login failed. Please try again.' });
  }
});

// Admin Dedicated Login
router.post('/admin-login', rateLimiter(10, 60000), async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      res.status(400).json({ error: 'Administrator email and password required.' });
      return;
    }

    const user = await db.findUserByEmail(email);
    if (!user || user.role !== 'admin') {
      res.status(401).json({ error: 'Unauthorized administrator credentials.' });
      return;
    }

    const match = await comparePassword(password, user.password_hash);
    if (!match) {
      res.status(401).json({ error: 'Unauthorized administrator credentials.' });
      return;
    }

    const token = generateToken(user);
    res.cookie('strataflux_token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      maxAge: config.tokenExpiryDays * 24 * 60 * 60 * 1000,
      sameSite: 'lax'
    });

    await db.logActivity({
      actor_id: user.id,
      actor_email: user.email,
      actor_role: 'admin',
      action: 'admin.login',
      resource_type: 'admin',
      resource_id: user.id,
      ip_address: req.ip
    });

    res.json({
      token,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        two_factor_enabled: user.two_factor_enabled
      }
    });
  } catch (err) {
    console.error('[ADMIN LOGIN ERROR]', err);
    res.status(500).json({ error: 'Administrator authentication failure.' });
  }
});

// Get current logged-in user profile
router.get('/me', requireAuth, (req: Request, res: Response) => {
  const user = req.user!;
  res.json({
    user: {
      id: user.id,
      email: user.email,
      name: user.name,
      role: user.role,
      status: user.status,
      avatar_url: user.avatar_url,
      plan_tier: user.plan_tier,
      custom_domain_limit: user.custom_domain_limit,
      storage_limit_bytes: user.storage_limit_bytes,
      bandwidth_limit_bytes: user.bandwidth_limit_bytes,
      two_factor_enabled: user.two_factor_enabled,
      created_at: user.created_at
    }
  });
});

// Update profile
router.put('/profile', requireAuth, async (req: Request, res: Response) => {
  try {
    const { name, email, avatar_url, two_factor_enabled } = req.body;
    const user = req.user!;

    const updates: Partial<typeof user> = {};
    if (name && typeof name === 'string') updates.name = name.trim();
    if (avatar_url !== undefined) updates.avatar_url = avatar_url;
    if (two_factor_enabled !== undefined) updates.two_factor_enabled = !!two_factor_enabled;

    if (email && email.toLowerCase() !== user.email.toLowerCase()) {
      const existing = await db.findUserByEmail(email);
      if (existing && existing.id !== user.id) {
        res.status(400).json({ error: 'This email is already in use by another account.' });
        return;
      }
      updates.email = email.toLowerCase().trim();
    }

    const updatedUser = await db.updateUser(user.id, updates);
    res.json({ user: updatedUser });
  } catch (err) {
    res.status(500).json({ error: 'Failed updating profile.' });
  }
});

// Change password
router.put('/change-password', requireAuth, async (req: Request, res: Response) => {
  try {
    const { currentPassword, newPassword } = req.body;
    const user = req.user!;

    if (!currentPassword || !newPassword) {
      res.status(400).json({ error: 'Current password and new password are required.' });
      return;
    }

    if (newPassword.length < 8) {
      res.status(400).json({ error: 'New password must be at least 8 characters long.' });
      return;
    }

    const validCurrent = await comparePassword(currentPassword, user.password_hash);
    if (!validCurrent) {
      res.status(400).json({ error: 'Current password is incorrect.' });
      return;
    }

    const newHash = await hashPassword(newPassword);
    await db.updateUser(user.id, { password_hash: newHash });

    await db.logActivity({
      actor_id: user.id,
      actor_email: user.email,
      actor_role: user.role,
      action: 'user.password_changed',
      resource_type: 'user',
      resource_id: user.id,
      ip_address: req.ip
    });

    res.json({ success: true, message: 'Password updated successfully.' });
  } catch (err) {
    res.status(500).json({ error: 'Failed changing password.' });
  }
});

// Forgot password
router.post('/forgot-password', rateLimiter(5, 60000), async (req: Request, res: Response) => {
  try {
    const { email } = req.body;
    if (!email) {
      res.status(400).json({ error: 'Email is required.' });
      return;
    }

    const user = await db.findUserByEmail(email);
    if (user) {
      const resetToken = crypto.randomBytes(32).toString('hex');
      const expiry = new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString(); // 2 hours
      await db.updateUser(user.id, {
        reset_token: resetToken,
        reset_token_expiry: expiry
      });

      await emailService.sendPasswordResetEmail(user.email, resetToken);
    }

    // Always respond with success to avoid leaking registered user emails
    res.json({ success: true, message: 'If that email address exists in our system, password reset instructions have been sent.' });
  } catch (err) {
    res.status(500).json({ error: 'Failed processing password reset.' });
  }
});

// Reset password with token
router.post('/reset-password', async (req: Request, res: Response) => {
  try {
    const { token, email, newPassword } = req.body;
    if (!token || !email || !newPassword) {
      res.status(400).json({ error: 'Token, email and new password are required.' });
      return;
    }

    if (newPassword.length < 8) {
      res.status(400).json({ error: 'Password must be at least 8 characters.' });
      return;
    }

    const user = await db.findUserByEmail(email);
    if (!user || user.reset_token !== token) {
      res.status(400).json({ error: 'Invalid or expired password reset link.' });
      return;
    }

    if (user.reset_token_expiry && new Date() > new Date(user.reset_token_expiry)) {
      res.status(400).json({ error: 'Password reset link has expired. Please request a new one.' });
      return;
    }

    const newHash = await hashPassword(newPassword);
    await db.updateUser(user.id, {
      password_hash: newHash,
      reset_token: undefined,
      reset_token_expiry: undefined
    });

    res.json({ success: true, message: 'Password has been reset successfully. You can now log in.' });
  } catch (err) {
    res.status(500).json({ error: 'Failed resetting password.' });
  }
});

// Logout
router.post('/logout', (req: Request, res: Response) => {
  res.clearCookie('strataflux_token');
  res.json({ success: true });
});

export default router;
