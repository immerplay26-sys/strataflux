import { Router, Request, Response } from 'express';
import { db } from '../db';
import { requireAuth } from '../auth';
import { storage } from '../storage';
import { config } from '../config';

const router = Router();

// List user's projects
router.get('/', requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user!;
    const projects = await db.listProjectsByUserId(user.id);
    
    // Attach current deployment summary to each project
    const enhanced = await Promise.all(projects.map(async (p) => {
      let currentDeployment = null;
      if (p.current_deployment_id) {
        currentDeployment = await db.findDeploymentById(p.current_deployment_id);
      }
      const domains = await db.listDomainsByProjectId(p.id);
      return {
        ...p,
        liveUrl: `${config.appUrl}/sites/${p.subdomain}/`,
        subdomainUrl: `https://${p.subdomain}.${config.baseDeployDomain}`,
        currentDeployment,
        customDomainsCount: domains.length
      };
    }));

    res.json({ projects: enhanced });
  } catch (err) {
    res.status(500).json({ error: 'Failed retrieving projects.' });
  }
});

// Check subdomain availability
router.get('/check-subdomain/:subdomain', requireAuth, async (req: Request, res: Response) => {
  try {
    const raw = req.params.subdomain.trim().toLowerCase();
    const clean = raw.replace(/[^a-z0-9-]/g, '').slice(0, 32);

    if (clean.length < 3) {
      res.json({ available: false, reason: 'Subdomain must be at least 3 characters.' });
      return;
    }

    const reserved = ['admin', 'api', 'app', 'cdn', 'dashboard', 'status', 'docs', 'billing', 'auth', 'mail', 'dns', 'edge', 'strataflux'];
    if (reserved.includes(clean)) {
      res.json({ available: false, reason: 'This subdomain is reserved by StrataFlux Cloud.' });
      return;
    }

    const existing = await db.findProjectBySubdomain(clean);
    res.json({ available: !existing, subdomain: clean });
  } catch (err) {
    res.status(500).json({ error: 'Failed checking subdomain.' });
  }
});

// Create project
router.post('/', requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user!;
    const { name, subdomain, framework = 'static' } = req.body;

    if (!name || !subdomain) {
      res.status(400).json({ error: 'Project name and subdomain are required.' });
      return;
    }

    const cleanSubdomain = subdomain.trim().toLowerCase().replace(/[^a-z0-9-]/g, '').slice(0, 32);
    if (cleanSubdomain.length < 3) {
      res.status(400).json({ error: 'Subdomain must be at least 3 alphanumeric characters.' });
      return;
    }

    const existing = await db.findProjectBySubdomain(cleanSubdomain);
    if (existing) {
      res.status(400).json({ error: `Subdomain "${cleanSubdomain}" is already claimed.` });
      return;
    }

    // Check project quota
    const userProjects = await db.listProjectsByUserId(user.id);
    const plans = await db.getSetting<any[]>('plans', []);
    const currentPlan = plans.find(p => p.id === user.plan_tier) || { max_projects: 3 };

    if (userProjects.length >= currentPlan.max_projects) {
      res.status(403).json({
        error: `Project limit reached (${currentPlan.max_projects} max on ${user.plan_tier.toUpperCase()} tier). Upgrade your plan to create more projects.`
      });
      return;
    }

    const project = await db.createProject({
      user_id: user.id,
      name: name.trim(),
      subdomain: cleanSubdomain,
      framework,
      spa_fallback: req.body.spa_fallback !== false,
      status: 'ready'
    });

    await db.logActivity({
      actor_id: user.id,
      actor_email: user.email,
      actor_role: user.role,
      action: 'project.create',
      resource_type: 'project',
      resource_id: project.id,
      details: { name: project.name, subdomain: project.subdomain },
      ip_address: req.ip
    });

    res.json({
      project: {
        ...project,
        liveUrl: `${config.appUrl}/sites/${project.subdomain}/`,
        subdomainUrl: `https://${project.subdomain}.${config.baseDeployDomain}`
      }
    });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed creating project.' });
  }
});

// Get single project
router.get('/:id', requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user!;
    const project = await db.findProjectById(req.params.id);

    if (!project) {
      res.status(404).json({ error: 'Project not found.' });
      return;
    }

    if (project.user_id !== user.id && user.role !== 'admin') {
      res.status(403).json({ error: 'Unauthorized access to project.' });
      return;
    }

    let currentDeployment = null;
    if (project.current_deployment_id) {
      currentDeployment = await db.findDeploymentById(project.current_deployment_id);
    }

    const deployments = await db.listDeploymentsByProjectId(project.id);
    const domains = await db.listDomainsByProjectId(project.id);

    res.json({
      project: {
        ...project,
        liveUrl: `${config.appUrl}/sites/${project.subdomain}/`,
        subdomainUrl: `https://${project.subdomain}.${config.baseDeployDomain}`,
        currentDeployment,
        deployments,
        domains
      }
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed fetching project.' });
  }
});

// Update project
router.put('/:id', requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user!;
    const project = await db.findProjectById(req.params.id);

    if (!project) {
      res.status(404).json({ error: 'Project not found.' });
      return;
    }

    if (project.user_id !== user.id && user.role !== 'admin') {
      res.status(403).json({ error: 'Unauthorized.' });
      return;
    }

    const { name, framework } = req.body;
    const updates: Partial<typeof project> = {};
    if (name) updates.name = name.trim();
    if (framework) updates.framework = framework;

    const updated = await db.updateProject(project.id, updates);
    res.json({ project: updated });
  } catch (err) {
    res.status(500).json({ error: 'Failed updating project.' });
  }
});

// Delete project
router.delete('/:id', requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user!;
    const project = await db.findProjectById(req.params.id);

    if (!project) {
      res.status(404).json({ error: 'Project not found.' });
      return;
    }

    if (project.user_id !== user.id && user.role !== 'admin') {
      res.status(403).json({ error: 'Unauthorized.' });
      return;
    }

    // Clean up all deployments storage
    const deployments = await db.listDeploymentsByProjectId(project.id);
    for (const d of deployments) {
      storage.deleteDeploymentFiles(d.id);
    }

    await db.deleteProject(project.id);

    await db.logActivity({
      actor_id: user.id,
      actor_email: user.email,
      actor_role: user.role,
      action: 'project.delete',
      resource_type: 'project',
      resource_id: project.id,
      details: { name: project.name, subdomain: project.subdomain },
      ip_address: req.ip
    });

    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Failed deleting project.' });
  }
});

export default router;
