import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import AdmZip from 'adm-zip';
import { config } from './config';

const DEPLOYMENTS_DIR = path.resolve(config.storageDir, 'deployments');
const PAYMENTS_DIR = path.resolve(config.storageDir, 'payments');

// Dangerous extensions forbidden in uploaded static websites
const DISALLOWED_EXTENSIONS = new Set([
  '.php', '.phtml', '.php3', '.php4', '.php5', '.phps',
  '.exe', '.com', '.bat', '.cmd', '.sh', '.bash', '.zsh',
  '.py', '.rb', '.cgi', '.pl', '.jsp', '.asp', '.aspx',
  '.dll', '.so', '.dylib', '.bin'
]);

export const MIME_TYPES: Record<string, string> = {
  '.html': 'text/html; charset=utf-8',
  '.htm': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.mjs': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.webp': 'image/webp',
  '.avif': 'image/avif',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
  '.eot': 'application/vnd.ms-fontobject',
  '.otf': 'font/otf',
  '.mp4': 'video/mp4',
  '.webm': 'video/webm',
  '.mp3': 'audio/mpeg',
  '.wav': 'audio/wav',
  '.pdf': 'application/pdf',
  '.xml': 'application/xml',
  '.txt': 'text/plain; charset=utf-8',
  '.wasm': 'application/wasm'
};

export interface ProcessedDeploymentFiles {
  fileCount: number;
  totalSizeBytes: number;
  hasIndexHtml: boolean;
  storagePath: string;
  files: { path: string; size: number }[];
}

export class StorageService {
  // In-memory cache for edge runtime when local disk is read-only
  private memoryFiles = new Map<string, { buffer: Buffer; contentType: string }>();

  constructor() {
    try {
      if (typeof fs !== 'undefined' && fs.existsSync && fs.mkdirSync) {
        if (!fs.existsSync(DEPLOYMENTS_DIR)) {
          fs.mkdirSync(DEPLOYMENTS_DIR, { recursive: true });
        }
        if (!fs.existsSync(PAYMENTS_DIR)) {
          fs.mkdirSync(PAYMENTS_DIR, { recursive: true });
        }
      }
    } catch {
      // In cloud worker or read-only disk environment, safely continue
    }
  }

  getDeploymentDir(deploymentId: string): string {
    return path.resolve(DEPLOYMENTS_DIR, deploymentId);
  }

  getPaymentsDir(): string {
    return PAYMENTS_DIR;
  }

  async savePaymentScreenshot(filename: string, buffer: Buffer | Uint8Array, r2Bucket?: any): Promise<string> {
    const ext = path.extname(filename).toLowerCase() || '.png';
    const safeName = `receipt_${Date.now()}_${crypto.randomBytes(4).toString('hex')}${ext}`;
    const key = `receipts/${safeName}`;
    const contentType = MIME_TYPES[ext] || 'image/png';
    const buf = Buffer.isBuffer(buffer) ? buffer : Buffer.from(buffer);

    // Save to Cloudflare R2 bucket if available
    if (r2Bucket && typeof r2Bucket.put === 'function') {
      try {
        await r2Bucket.put(key, buf, {
          httpMetadata: { contentType }
        });
        return `/api/billing/receipts/${safeName}`;
      } catch (err) {
        console.warn('[STORAGE] Failed writing to R2 bucket, falling back:', err);
      }
    }

    // Save to in-memory store
    this.memoryFiles.set(key, { buffer: buf, contentType });

    // Save to local disk if available
    try {
      if (typeof fs !== 'undefined' && fs.writeFileSync) {
        const target = path.resolve(PAYMENTS_DIR, safeName);
        fs.writeFileSync(target, buf);
      }
    } catch {}

    return `/api/billing/receipts/${safeName}`;
  }

  async getPaymentScreenshot(filename: string, r2Bucket?: any): Promise<{ content: Buffer | Uint8Array; contentType: string } | null> {
    const key = `receipts/${filename}`;
    const ext = path.extname(filename).toLowerCase();
    const defaultType = MIME_TYPES[ext] || 'image/png';

    // 1. Check Cloudflare R2 bucket
    if (r2Bucket && typeof r2Bucket.get === 'function') {
      try {
        const obj = await r2Bucket.get(key);
        if (obj) {
          const ab = await obj.arrayBuffer();
          return {
            content: Buffer.from(ab),
            contentType: obj.httpMetadata?.contentType || defaultType
          };
        }
      } catch (err) {
        console.warn('[STORAGE] Error reading from R2 bucket:', err);
      }
    }

    // 2. Check in-memory store
    if (this.memoryFiles.has(key)) {
      const item = this.memoryFiles.get(key)!;
      return { content: item.buffer, contentType: item.contentType };
    }

    // 3. Check local disk
    try {
      if (typeof fs !== 'undefined' && fs.existsSync) {
        const target = path.resolve(PAYMENTS_DIR, filename);
        if (fs.existsSync(target)) {
          return {
            content: fs.readFileSync(target),
            contentType: defaultType
          };
        }
      }
    } catch {}

    return null;
  }

  async processZipUpload(zipInput: string | Buffer | ArrayBuffer, deploymentId: string, r2Bucket?: any): Promise<ProcessedDeploymentFiles> {
    let zip: AdmZip;
    if (typeof zipInput === 'string') {
      zip = new AdmZip(zipInput);
    } else if (Buffer.isBuffer(zipInput)) {
      zip = new AdmZip(zipInput);
    } else {
      zip = new AdmZip(Buffer.from(zipInput as any));
    }

    const zipEntries = zip.getEntries();
    let totalSizeBytes = 0;
    let fileCount = 0;
    const fileList: { path: string; size: number }[] = [];

    // First pass: validate safety & determine common prefix folder if any
    let commonPrefix: string | null = null;
    const candidateFolders = new Set<string>();

    for (const entry of zipEntries) {
      if (entry.isDirectory) continue;

      const normName = entry.entryName.replace(/\\/g, '/');

      // Zip-slip security check
      if (normName.includes('..') || path.isAbsolute(normName)) {
        throw new Error('Security Error: Archive contains illegal relative path traversal sequences.');
      }

      // Check dangerous executable extension
      const ext = path.extname(normName).toLowerCase();
      if (DISALLOWED_EXTENSIONS.has(ext)) {
        throw new Error(`Security Error: Executable or server-side scripts (${ext}) are strictly forbidden on static edge hosting.`);
      }

      const parts = normName.split('/');
      if (parts.length > 1) {
        candidateFolders.add(parts[0]);
      }
    }

    if (candidateFolders.size === 1) {
      const singleFolder = Array.from(candidateFolders)[0];
      const allInside = zipEntries.every(e => e.entryName.replace(/\\/g, '/').startsWith(singleFolder + '/'));
      if (allInside) {
        commonPrefix = singleFolder + '/';
      }
    }

    // Second pass: extract files safely
    let targetDir = this.getDeploymentDir(deploymentId);
    let canWriteDisk = false;
    try {
      if (typeof fs !== 'undefined' && fs.existsSync && fs.mkdirSync) {
        if (!fs.existsSync(targetDir)) {
          fs.mkdirSync(targetDir, { recursive: true });
        }
        canWriteDisk = true;
      }
    } catch {
      canWriteDisk = false;
    }

    for (const entry of zipEntries) {
      if (entry.isDirectory) continue;

      let cleanPath = entry.entryName.replace(/\\/g, '/');
      if (commonPrefix && cleanPath.startsWith(commonPrefix)) {
        cleanPath = cleanPath.slice(commonPrefix.length);
      }

      if (!cleanPath) continue;

      const ext = path.extname(cleanPath).toLowerCase();
      const contentType = MIME_TYPES[ext] || 'application/octet-stream';
      const fileData = entry.getData();
      const size = fileData.length;

      // 1. Write to R2 if available
      if (r2Bucket && typeof r2Bucket.put === 'function') {
        try {
          await r2Bucket.put(`${deploymentId}/${cleanPath}`, fileData, {
            httpMetadata: { contentType }
          });
        } catch (e) {
          console.warn(`[STORAGE] Error writing ${cleanPath} to R2:`, e);
        }
      }

      // 2. Write to memory cache
      this.memoryFiles.set(`${deploymentId}/${cleanPath}`, {
        buffer: fileData,
        contentType
      });

      // 3. Write to local disk if supported
      if (canWriteDisk) {
        try {
          const destPath = path.resolve(targetDir, cleanPath);
          if (destPath.startsWith(targetDir)) {
            const destFolder = path.dirname(destPath);
            if (!fs.existsSync(destFolder)) {
              fs.mkdirSync(destFolder, { recursive: true });
            }
            fs.writeFileSync(destPath, fileData);
          }
        } catch {}
      }

      totalSizeBytes += size;
      fileCount++;
      fileList.push({ path: cleanPath, size });
    }

    // Check for index.html at root
    const hasIndexHtml = fileList.some(f => f.path === 'index.html' || f.path === './index.html');

    // If no index.html, generate a clean, modern preview page
    if (!hasIndexHtml) {
      const fallbackHtml = `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>StrataFlux Live Edge Deployment</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #090d16; color: #f1f5f9; margin: 0; padding: 40px 20px; display: flex; justify-content: center; }
    .card { background: #0f172a; border: 1px solid #1e293b; border-radius: 12px; padding: 32px; max-width: 640px; width: 100%; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.5); }
    h1 { color: #38bdf8; margin-top: 0; font-size: 24px; }
    p { color: #94a3b8; line-height: 1.6; }
    .badge { display: inline-block; padding: 4px 10px; background: rgba(56, 189, 248, 0.1); color: #38bdf8; border-radius: 6px; font-size: 13px; font-weight: 600; margin-bottom: 16px; }
    ul { list-style: none; padding: 0; margin: 20px 0 0; border-top: 1px solid #1e293b; }
    li { padding: 10px 0; border-bottom: 1px solid #1e293b; display: flex; justify-content: space-between; }
    a { color: #38bdf8; text-decoration: none; word-break: break-all; }
    a:hover { text-decoration: underline; }
    .size { color: #64748b; font-size: 13px; font-family: monospace; }
  </style>
</head>
<body>
  <div class="card">
    <div class="badge">StrataFlux Edge Active</div>
    <h1>Deployment Successful</h1>
    <p>Your files have been extracted and deployed to the global edge network. No root <code>index.html</code> was detected, so here is your package file manifest:</p>
    <ul>
      ${fileList.slice(0, 30).map(f => `<li><a href="./${encodeURIComponent(f.path)}">${f.path}</a><span class="size">${(f.size / 1024).toFixed(1)} KB</span></li>`).join('\n      ')}
    </ul>
  </div>
</body>
</html>`;
      const fallbackBuf = Buffer.from(fallbackHtml, 'utf-8');

      if (r2Bucket && typeof r2Bucket.put === 'function') {
        try {
          await r2Bucket.put(`${deploymentId}/index.html`, fallbackBuf, {
            httpMetadata: { contentType: 'text/html; charset=utf-8' }
          });
        } catch {}
      }

      this.memoryFiles.set(`${deploymentId}/index.html`, {
        buffer: fallbackBuf,
        contentType: 'text/html; charset=utf-8'
      });

      if (canWriteDisk) {
        try {
          fs.writeFileSync(path.resolve(targetDir, 'index.html'), fallbackHtml, 'utf-8');
        } catch {}
      }
    }

    return {
      fileCount,
      totalSizeBytes,
      hasIndexHtml: true,
      storagePath: `r2://${config.r2BucketName}/${deploymentId}`,
      files: fileList
    };
  }

  async processDirectFileUpload(files: { path: string; buffer: Buffer | Uint8Array }[], deploymentId: string, r2Bucket?: any): Promise<ProcessedDeploymentFiles> {
    let totalSizeBytes = 0;
    let fileCount = 0;
    const fileList: { path: string; size: number }[] = [];

    const targetDir = this.getDeploymentDir(deploymentId);
    let canWriteDisk = false;
    try {
      if (typeof fs !== 'undefined' && fs.existsSync && fs.mkdirSync) {
        if (!fs.existsSync(targetDir)) {
          fs.mkdirSync(targetDir, { recursive: true });
        }
        canWriteDisk = true;
      }
    } catch {}

    for (const file of files) {
      const cleanPath = file.path.replace(/\\/g, '/').replace(/^\/+/, '');
      if (cleanPath.includes('..')) {
        throw new Error('Security Error: Path contains invalid relative components.');
      }

      const ext = path.extname(cleanPath).toLowerCase();
      if (DISALLOWED_EXTENSIONS.has(ext)) {
        throw new Error(`Security Error: Script extension ${ext} not allowed.`);
      }

      const contentType = MIME_TYPES[ext] || 'application/octet-stream';
      const buf = Buffer.isBuffer(file.buffer) ? file.buffer : Buffer.from(file.buffer);
      const size = buf.length;

      // 1. R2
      if (r2Bucket && typeof r2Bucket.put === 'function') {
        try {
          await r2Bucket.put(`${deploymentId}/${cleanPath}`, buf, {
            httpMetadata: { contentType }
          });
        } catch {}
      }

      // 2. Memory
      this.memoryFiles.set(`${deploymentId}/${cleanPath}`, {
        buffer: buf,
        contentType
      });

      // 3. Disk
      if (canWriteDisk) {
        try {
          const destPath = path.resolve(targetDir, cleanPath);
          if (destPath.startsWith(targetDir)) {
            const destFolder = path.dirname(destPath);
            if (!fs.existsSync(destFolder)) {
              fs.mkdirSync(destFolder, { recursive: true });
            }
            fs.writeFileSync(destPath, buf);
          }
        } catch {}
      }

      totalSizeBytes += size;
      fileCount++;
      fileList.push({ path: cleanPath, size });
    }

    const hasIndexHtml = fileList.some(f => f.path === 'index.html');

    return {
      fileCount,
      totalSizeBytes,
      hasIndexHtml,
      storagePath: `r2://${config.r2BucketName}/${deploymentId}`,
      files: fileList
    };
  }

  async getDeploymentFile(deploymentId: string, filePath: string, r2Bucket?: any): Promise<{ content: Buffer | Uint8Array; contentType: string; size: number } | null> {
    let cleanPath = filePath.replace(/^\/+/, '');
    if (!cleanPath || cleanPath.endsWith('/')) {
      cleanPath += 'index.html';
    }

    const candidates = [
      cleanPath,
      `${cleanPath}/index.html`,
      'index.html',
      '404.html'
    ];

    for (const cand of candidates) {
      const key = `${deploymentId}/${cand}`;

      // 1. Check Cloudflare R2
      if (r2Bucket && typeof r2Bucket.get === 'function') {
        try {
          const obj = await r2Bucket.get(key);
          if (obj) {
            const ab = await obj.arrayBuffer();
            const ext = path.extname(cand).toLowerCase();
            const ct = obj.httpMetadata?.contentType || MIME_TYPES[ext] || 'application/octet-stream';
            return {
              content: Buffer.from(ab),
              contentType: ct,
              size: ab.byteLength
            };
          }
        } catch (e) {
          console.warn(`[STORAGE] Error reading ${key} from R2:`, e);
        }
      }

      // 2. Check memory files
      if (this.memoryFiles.has(key)) {
        const item = this.memoryFiles.get(key)!;
        return {
          content: item.buffer,
          contentType: item.contentType,
          size: item.buffer.length
        };
      }

      // 3. Check local disk
      try {
        if (typeof fs !== 'undefined' && fs.existsSync) {
          const diskTarget = path.resolve(this.getDeploymentDir(deploymentId), cand);
          if (diskTarget.startsWith(this.getDeploymentDir(deploymentId)) && fs.existsSync(diskTarget) && !fs.statSync(diskTarget).isDirectory()) {
            const content = fs.readFileSync(diskTarget);
            const ext = path.extname(diskTarget).toLowerCase();
            const ct = MIME_TYPES[ext] || 'application/octet-stream';
            return {
              content,
              contentType: ct,
              size: content.length
            };
          }
        }
      } catch {}
    }

    return null;
  }

  deleteDeploymentFiles(deploymentId: string, r2Bucket?: any): boolean {
    // Delete from memory
    for (const key of Array.from(this.memoryFiles.keys())) {
      if (key.startsWith(`${deploymentId}/`)) {
        this.memoryFiles.delete(key);
      }
    }

    // Delete from disk
    const targetDir = this.getDeploymentDir(deploymentId);
    try {
      if (typeof fs !== 'undefined' && fs.existsSync && fs.existsSync(targetDir)) {
        fs.rmSync(targetDir, { recursive: true, force: true });
      }
    } catch {}

    return true;
  }
}

export const storage = new StorageService();
