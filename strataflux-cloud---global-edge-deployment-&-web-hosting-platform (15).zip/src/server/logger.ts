// Structured logging service with automatic secret redaction
const SENSITIVE_KEYS = new Set([
  'password', 'password_hash', 'currentpassword', 'newpassword',
  'token', 'secret', 'auth_secret', 'authsecret', 'stripe_secret_key',
  'stripesecretkey', 'r2_secret_access_key', 'r2secretaccesskey',
  'cloudflare_api_token', 'cloudflareapitoken', 'resend_api_key', 'resendapikey',
  'authorization', 'cookie', 'set-cookie'
]);

function redact(obj: any, depth = 0): any {
  if (depth > 5) return '[Deep Object]';
  if (!obj || typeof obj !== 'object') return obj;

  if (Array.isArray(obj)) {
    return obj.map(item => redact(item, depth + 1));
  }

  const sanitized: Record<string, any> = {};
  for (const [key, val] of Object.entries(obj)) {
    const lowerKey = key.toLowerCase();
    if (SENSITIVE_KEYS.has(lowerKey) || lowerKey.includes('secret') || lowerKey.includes('password') || lowerKey.includes('token')) {
      sanitized[key] = '[REDACTED]';
    } else if (typeof val === 'object' && val !== null) {
      sanitized[key] = redact(val, depth + 1);
    } else {
      sanitized[key] = val;
    }
  }
  return sanitized;
}

export const logger = {
  info: (message: string, meta?: Record<string, any>) => {
    const timestamp = new Date().toISOString();
    if (meta) {
      console.log(`[INFO] [${timestamp}] ${message}`, JSON.stringify(redact(meta)));
    } else {
      console.log(`[INFO] [${timestamp}] ${message}`);
    }
  },
  warn: (message: string, meta?: Record<string, any>) => {
    const timestamp = new Date().toISOString();
    if (meta) {
      console.warn(`[WARN] [${timestamp}] ${message}`, JSON.stringify(redact(meta)));
    } else {
      console.warn(`[WARN] [${timestamp}] ${message}`);
    }
  },
  error: (message: string, err?: any, meta?: Record<string, any>) => {
    const timestamp = new Date().toISOString();
    const errorDetails = err instanceof Error ? { message: err.message, name: err.name } : err;
    console.error(`[ERROR] [${timestamp}] ${message}`, {
      error: errorDetails,
      meta: meta ? redact(meta) : undefined
    });
  }
};
