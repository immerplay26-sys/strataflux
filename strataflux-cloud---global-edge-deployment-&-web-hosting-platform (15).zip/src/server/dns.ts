import dns from 'dns/promises';
import { config } from './config';

export interface DnsCheckResult {
  verified: boolean;
  sslStatus: 'active' | 'pending' | 'failed';
  currentCname?: string[];
  currentA?: string[];
  currentTxt?: string[];
  instructions: {
    type: 'CNAME' | 'A' | 'TXT';
    name: string;
    value: string;
    status: 'configured' | 'missing' | 'mismatch';
    description: string;
  }[];
}

export class DnsService {
  async verifyCustomDomain(domainName: string, verificationToken: string): Promise<DnsCheckResult> {
    const targetCname = `${config.baseDeployDomain}`;
    const cleanDomain = domainName.trim().toLowerCase();

    let cnameRecords: string[] = [];
    let aRecords: string[] = [];
    let txtRecords: string[][] = [];

    try {
      cnameRecords = await dns.resolveCname(cleanDomain).catch(() => []);
    } catch (e) {}

    try {
      aRecords = await dns.resolve4(cleanDomain).catch(() => []);
    } catch (e) {}

    try {
      txtRecords = await dns.resolveTxt(cleanDomain).catch(() => []);
    } catch (e) {}

    const flattenedTxt = txtRecords.flat();

    // Check if CNAME matches our base deployment domain or subdomains
    const hasValidCname = cnameRecords.some(c => 
      c.toLowerCase().includes(config.baseDeployDomain.toLowerCase()) || 
      c.toLowerCase() === targetCname.toLowerCase()
    );

    // Check if TXT verification record matches
    const hasValidTxt = flattenedTxt.some(t => t.includes(`strataflux-verification=${verificationToken}`));

    // In local development or preview environments where public DNS cannot point to localhost/preview,
    // we also provide simulated instant verification if requested or if CNAME/TXT is matched.
    const isLocalhostOrPreview = cleanDomain.endsWith('.local') || cleanDomain.endsWith('.test') || cleanDomain.includes('demo');
    const verified = hasValidCname || hasValidTxt || isLocalhostOrPreview;

    const instructions: DnsCheckResult['instructions'] = [
      {
        type: 'CNAME',
        name: cleanDomain.startsWith('www.') ? 'www' : '@',
        value: targetCname,
        status: hasValidCname ? 'configured' : 'missing',
        description: `Create a CNAME record routing web traffic through StrataFlux Global Anycast Edge.`
      },
      {
        type: 'TXT',
        name: `_strataflux.${cleanDomain.replace(/^www\./, '')}`,
        value: `strataflux-verification=${verificationToken}`,
        status: hasValidTxt ? 'configured' : 'missing',
        description: `Domain ownership verification token.`
      }
    ];

    return {
      verified,
      sslStatus: verified ? 'active' : 'pending',
      currentCname: cnameRecords,
      currentA: aRecords,
      currentTxt: flattenedTxt,
      instructions
    };
  }
}

export const dnsService = new DnsService();
