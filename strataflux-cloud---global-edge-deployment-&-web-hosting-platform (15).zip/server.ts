import express, { Request, Response, NextFunction } from 'express';
import cookieParser from 'cookie-parser';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { createServer as createViteServer } from 'vite';
import { config } from './src/server/config';
import { db } from './src/server/db';
import { storage } from './src/server/storage';

// Route Handlers
import authRoutes from './src/server/routes/authRoutes';
import projectRoutes from './src/server/routes/projectRoutes';
import deployRoutes from './src/server/routes/deployRoutes';
import domainRoutes from './src/server/routes/domainRoutes';
import analyticsRoutes from './src/server/routes/analyticsRoutes';
import billingRoutes from './src/server/routes/billingRoutes';
import supportRoutes from './src/server/routes/supportRoutes';
import adminRoutes from './src/server/routes/adminRoutes';
import publicRoutes from './src/server/routes/publicRoutes';

// MIME types helper for static deployment serving
const MIME_TYPES: Record<string, string> = {
  '.html': 'text/html; charset=utf-8',
  '.htm': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.mjs': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.webp': 'image/webp',
  '.avif': 'image/avif',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
  '.eot': 'application/vnd.ms-fontobject',
  '.otf': 'font/otf',
  '.mp4': 'video/mp4',
  '.webm': 'video/webm',
  '.mp3': 'audio/mpeg',
  '.wav': 'audio/wav',
  '.pdf': 'application/pdf',
  '.xml': 'application/xml',
  '.txt': 'text/plain; charset=utf-8',
  '.wasm': 'application/wasm'
};

function parseUserAgent(ua: string = '') {
  let deviceType: 'desktop' | 'mobile' | 'tablet' | 'bot' = 'desktop';
  let browser = 'Other';
  let os = 'Other';

  if (/bot|crawler|spider|crawling/i.test(ua)) {
    deviceType = 'bot';
  } else if (/tablet|ipad/i.test(ua)) {
    deviceType = 'tablet';
  } else if (/mobile|iphone|android.*mobile/i.test(ua)) {
    deviceType = 'mobile';
  }

  if (/firefox/i.test(ua)) browser = 'Firefox';
  else if (/edg/i.test(ua)) browser = 'Edge';
  else if (/chrome/i.test(ua)) browser = 'Chrome';
  else if (/safari/i.test(ua)) browser = 'Safari';

  if (/windows/i.test(ua)) os = 'Windows';
  else if (/macintosh|mac os x/i.test(ua)) os = 'macOS';
  else if (/iphone|ipad/i.test(ua)) os = 'iOS';
  else if (/android/i.test(ua)) os = 'Android';
  else if (/linux/i.test(ua)) os = 'Linux';

  return { deviceType, browser, os };
}

async function startServer() {
  const app = express();

  // Initialize relational storage
  await db.init();

  // Core middlewares
  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true, limit: '10mb' }));
  app.use(cookieParser());

  // Security Headers
  app.use((req: Request, res: Response, next: NextFunction) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-XSS-Protection', '1; mode=block');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    next();
  });

  // Dynamic SEO sitemap.xml
  app.get('/sitemap.xml', async (req: Request, res: Response) => {
    const origin = config.appUrl;
    const urls = [
      '',
      '/features',
      '/pricing',
      '/how-it-works',
      '/documentation',
      '/about-us',
      '/contact-us',
      '/security',
      '/status',
      '/faq',
      '/privacy-policy',
      '/terms-of-service',
      '/cookie-policy',
      '/acceptable-use',
      '/login',
      '/register'
    ];

    const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  ${urls.map(u => `
  <url>
    <loc>${origin}${u}</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>${u === '' ? '1.0' : '0.8'}</priority>
  </url>`).join('')}
</urlset>`;

    res.setHeader('Content-Type', 'application/xml');
    res.send(xml);
  });

  // Dynamic SEO robots.txt
  app.get('/robots.txt', async (req: Request, res: Response) => {
    const seo = await db.getSetting<any>('seo', {});
    const defaultRobots = `User-agent: *
Allow: /
Disallow: /admin/
Disallow: /admin-login
Disallow: /admin-login.html
Disallow: /api/
Sitemap: ${config.appUrl}/sitemap.xml`;

    res.setHeader('Content-Type', 'text/plain');
    res.send(seo.robots_txt || defaultRobots);
  });

  // Dedicated Admin Login redirect / URL handler
  app.get('/admin-login.html', (req: Request, res: Response) => {
    res.redirect('/admin-login');
  });

  // Static site live serving function
  const serveProjectDeployment = async (req: Request, res: Response, project: any, filePath: string) => {
    if (!project.current_deployment_id) {
      res.status(404).send(`
        <!doctype html>
        <html lang="en">
        <head><title>No Deployment Active</title><style>body{background:#090d16;color:#e2e8f0;font-family:sans-serif;padding:60px 20px;text-align:center;}</style></head>
        <body>
          <h1 style="color:#38bdf8;">Project Provisioned</h1>
          <p style="color:#94a3b8;">${project.name} is waiting for its first deployment.</p>
        </body>
        </html>
      `);
      return;
    }

    const deployment = await db.findDeploymentById(project.current_deployment_id);
    if (!deployment || deployment.status !== 'live') {
      res.status(503).send('Deployment is compiling or currently inactive.');
      return;
    }

    const deployDir = storage.getDeploymentDir(deployment.id);
    let targetRelative = filePath.replace(/^\/+/, '');
    if (!targetRelative || targetRelative.endsWith('/')) {
      targetRelative += 'index.html';
    }

    let resolvedPath = path.resolve(deployDir, targetRelative);

    // If file doesn't exist, check for directory with index.html or fallback to index.html (SPA routing support)
    if (!fs.existsSync(resolvedPath)) {
      if (fs.existsSync(path.resolve(resolvedPath, 'index.html'))) {
        resolvedPath = path.resolve(resolvedPath, 'index.html');
      } else if (fs.existsSync(path.resolve(deployDir, '404.html'))) {
        resolvedPath = path.resolve(deployDir, '404.html');
      } else if (fs.existsSync(path.resolve(deployDir, 'index.html'))) {
        resolvedPath = path.resolve(deployDir, 'index.html');
      } else {
        res.status(404).send('404: Asset not found in edge deployment sandbox.');
        return;
      }
    }

    // Security check: ensure path stays within sandbox
    if (!resolvedPath.startsWith(deployDir)) {
      res.status(403).send('Forbidden: Path resolution outside deployment sandbox.');
      return;
    }

    const stat = fs.statSync(resolvedPath);
    const ext = path.extname(resolvedPath).toLowerCase();
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';

    // Privacy-preserving Analytics Hit Recording
    const ip = req.ip || req.socket.remoteAddress || '127.0.0.1';
    const dayKey = new Date().toISOString().split('T')[0];
    const ipHash = crypto.createHash('sha256').update(ip + dayKey + 'strataflux_salt').digest('hex');
    const { deviceType, browser, os } = parseUserAgent(req.headers['user-agent']);
    const countryCode = (req.headers['cf-ipcountry'] as string) || 'US';

    db.recordHit({
      project_id: project.id,
      deployment_id: deployment.id,
      path: req.path,
      referrer: req.headers.referer || '',
      ip_hash: ipHash,
      country_code: countryCode,
      country_name: countryCode === 'US' ? 'United States' : countryCode,
      device_type: deviceType,
      browser,
      os,
      bytes_sent: stat.size,
      status_code: 200
    }).catch(() => {});

    // Set cache headers (revalidate for HTML, 1 year immutable for hashed assets)
    if (ext === '.html') {
      res.setHeader('Cache-Control', 'public, max-age=0, must-revalidate');
    } else {
      res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
    }

    res.setHeader('Content-Type', contentType);
    res.setHeader('Content-Length', stat.size);
    res.setHeader('X-StrataFlux-Edge', 'ACTIVE-NODE');
    res.setHeader('X-StrataFlux-Deployment', deployment.id);

    const stream = fs.createReadStream(resolvedPath);
    stream.pipe(res);
  };

  // 1. Direct path-based preview and live site serving: `/sites/:subdomain/*`
  app.use('/sites/:subdomain', async (req: Request, res: Response) => {
    const subdomain = req.params.subdomain.toLowerCase();
    const project = await db.findProjectBySubdomain(subdomain);

    if (!project) {
      res.status(404).send(`
        <!doctype html>
        <html><head><title>Project Not Found</title><style>body{background:#090d16;color:#f8fafc;font-family:sans-serif;text-align:center;padding:80px;}</style></head>
        <body><h1 style="color:#ef4444;">404 - Project Not Found</h1><p style="color:#94a3b8;">No StrataFlux project with subdomain "${subdomain}" exists.</p></body></html>
      `);
      return;
    }

    const subPath = req.url; // Relative path inside site
    await serveProjectDeployment(req, res, project, subPath);
  });

  // 2. Custom Domain & Subdomain Host Routing Middleware
  app.use(async (req: Request, res: Response, next: NextFunction) => {
    const host = (req.headers.host || '').split(':')[0].toLowerCase();

    // Check if host matches custom domain
    if (host && !host.includes('localhost') && !host.includes('127.0.0.1') && !host.includes('run.app')) {
      const domainRecord = await db.findDomainByName(host);
      if (domainRecord && domainRecord.is_verified) {
        const project = await db.findProjectById(domainRecord.project_id);
        if (project) {
          await serveProjectDeployment(req, res, project, req.path);
          return;
        }
      }

      // Check if it's a subdomain of baseDeployDomain (e.g. `client.strataflux.app`)
      if (host.endsWith(`.${config.baseDeployDomain}`)) {
        const sub = host.replace(`.${config.baseDeployDomain}`, '');
        const project = await db.findProjectBySubdomain(sub);
        if (project) {
          await serveProjectDeployment(req, res, project, req.path);
          return;
        }
      }
    }

    next();
  });

  // Mount API Routers
  app.use('/api/auth', authRoutes);
  app.use('/api/projects', projectRoutes);
  app.use('/api/deploy', deployRoutes);
  app.use('/api/domains', domainRoutes);
  app.use('/api/analytics', analyticsRoutes);
  app.use('/api/billing', billingRoutes);
  app.use('/api/support', supportRoutes);
  app.use('/api/admin', adminRoutes);
  app.use('/api/public', publicRoutes);

  // Frontend Serving (Vite in development, dist in production)
  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  // Global Error Handler
  app.use((err: any, req: Request, res: Response, next: NextFunction) => {
    console.error('[UNHANDLED SERVER ERROR]', err);
    res.status(500).json({ error: 'Internal server error occurred.' });
  });

  app.listen(config.port, '0.0.0.0', () => {
    console.log(`\n======================================================`);
    console.log(`  STRATAFLUX CLOUD - PRODUCTION PLATFORM ENGINE ACTIVE`);
    console.log(`  Port: ${config.port}`);
    console.log(`  App URL: ${config.appUrl}`);
    console.log(`  Admin Email: ${config.adminEmail}`);
    console.log(`  Admin WhatsApp: ${config.adminWhatsapp}`);
    console.log(`  Admin Login: ${config.appUrl}/admin-login.html`);
    console.log(`======================================================\n`);
  });
}

startServer().catch(err => {
  console.error('Fatal server startup failure:', err);
  process.exit(1);
});
