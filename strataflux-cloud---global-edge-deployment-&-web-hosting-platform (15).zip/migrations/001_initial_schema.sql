-- =========================================================================
-- StrataFlux Cloud - Production Relational PostgreSQL Database Schema
-- Migration 001: Initial Schema
-- =========================================================================

-- Enable UUID extension if available
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. USERS TABLE
CREATE TABLE IF NOT EXISTS users (
    id VARCHAR(64) PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    name VARCHAR(255) NOT NULL,
    role VARCHAR(32) NOT NULL DEFAULT 'user', -- 'user' | 'admin'
    status VARCHAR(32) NOT NULL DEFAULT 'active', -- 'active' | 'suspended' | 'banned'
    avatar_url TEXT,
    email_verified BOOLEAN NOT NULL DEFAULT FALSE,
    verification_token VARCHAR(255),
    reset_token VARCHAR(255),
    reset_token_expiry TIMESTAMP WITH TIME ZONE,
    two_factor_enabled BOOLEAN NOT NULL DEFAULT FALSE,
    failed_login_attempts INT NOT NULL DEFAULT 0,
    locked_until TIMESTAMP WITH TIME ZONE,
    last_login_at TIMESTAMP WITH TIME ZONE,
    last_login_ip VARCHAR(64),
    plan_tier VARCHAR(32) NOT NULL DEFAULT 'free', -- 'free' | 'pro' | 'business'
    custom_domain_limit INT NOT NULL DEFAULT 1,
    storage_limit_bytes BIGINT NOT NULL DEFAULT 524288000, -- 500MB
    bandwidth_limit_bytes BIGINT NOT NULL DEFAULT 10737418240, -- 10GB
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);
CREATE INDEX IF NOT EXISTS idx_users_status ON users(status);

-- 2. PROJECTS TABLE
CREATE TABLE IF NOT EXISTS projects (
    id VARCHAR(64) PRIMARY KEY,
    user_id VARCHAR(64) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name VARCHAR(128) NOT NULL,
    subdomain VARCHAR(128) NOT NULL UNIQUE,
    framework VARCHAR(64) NOT NULL DEFAULT 'static', -- 'static' | 'react' | 'vue' | 'next' | 'astro' | 'svelte'
    spa_fallback BOOLEAN NOT NULL DEFAULT TRUE,
    current_deployment_id VARCHAR(64),
    status VARCHAR(32) NOT NULL DEFAULT 'ready', -- 'ready' | 'deploying' | 'failed'
    storage_used_bytes BIGINT NOT NULL DEFAULT 0,
    bandwidth_used_bytes BIGINT NOT NULL DEFAULT 0,
    total_deployments INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_projects_user_id ON projects(user_id);
CREATE INDEX IF NOT EXISTS idx_projects_subdomain ON projects(subdomain);

-- 3. DEPLOYMENTS TABLE
CREATE TABLE IF NOT EXISTS deployments (
    id VARCHAR(64) PRIMARY KEY,
    project_id VARCHAR(64) NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    user_id VARCHAR(64) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    status VARCHAR(32) NOT NULL DEFAULT 'queued', -- 'queued' | 'building' | 'deploying' | 'ready' | 'live' | 'failed' | 'cancelled'
    source_type VARCHAR(32) NOT NULL DEFAULT 'zip', -- 'zip' | 'files' | 'git' | 'cli'
    file_count INT NOT NULL DEFAULT 0,
    total_size_bytes BIGINT NOT NULL DEFAULT 0,
    url TEXT NOT NULL,
    branch VARCHAR(64) DEFAULT 'main',
    commit_message TEXT,
    build_logs TEXT,
    error_message TEXT,
    storage_path TEXT NOT NULL,
    storage_driver VARCHAR(32) NOT NULL DEFAULT 'local', -- 'local' | 'r2' | 's3'
    deployed_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_deployments_project_id ON deployments(project_id);
CREATE INDEX IF NOT EXISTS idx_deployments_user_id ON deployments(user_id);
CREATE INDEX IF NOT EXISTS idx_deployments_status ON deployments(status);
CREATE INDEX IF NOT EXISTS idx_deployments_created_at ON deployments(created_at DESC);

-- 4. DEPLOYMENT_FILES TABLE
CREATE TABLE IF NOT EXISTS deployment_files (
    id VARCHAR(64) PRIMARY KEY,
    deployment_id VARCHAR(64) NOT NULL REFERENCES deployments(id) ON DELETE CASCADE,
    project_id VARCHAR(64) NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    file_path TEXT NOT NULL,
    file_size BIGINT NOT NULL DEFAULT 0,
    content_type VARCHAR(128) NOT NULL DEFAULT 'text/plain',
    etag VARCHAR(64),
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_deployment_files_deployment ON deployment_files(deployment_id);
CREATE INDEX IF NOT EXISTS idx_deployment_files_path ON deployment_files(deployment_id, file_path);

-- 5. DOMAINS TABLE
CREATE TABLE IF NOT EXISTS domains (
    id VARCHAR(64) PRIMARY KEY,
    project_id VARCHAR(64) NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    user_id VARCHAR(64) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    domain VARCHAR(255) NOT NULL UNIQUE,
    verification_type VARCHAR(32) NOT NULL DEFAULT 'cname', -- 'cname' | 'a' | 'txt'
    verification_token VARCHAR(255) NOT NULL,
    is_verified BOOLEAN NOT NULL DEFAULT FALSE,
    ssl_status VARCHAR(32) NOT NULL DEFAULT 'pending', -- 'pending' | 'active' | 'failed'
    cloudflare_hostname_id VARCHAR(128),
    dns_records JSONB,
    verified_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_domains_project_id ON domains(project_id);
CREATE INDEX IF NOT EXISTS idx_domains_domain ON domains(domain);
CREATE INDEX IF NOT EXISTS idx_domains_verified ON domains(is_verified);

-- 6. SESSIONS TABLE
CREATE TABLE IF NOT EXISTS sessions (
    id VARCHAR(64) PRIMARY KEY,
    user_id VARCHAR(64) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash VARCHAR(64) NOT NULL UNIQUE,
    ip_address VARCHAR(64),
    user_agent TEXT,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    revoked_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_sessions_user_id ON sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_token_hash ON sessions(token_hash);
CREATE INDEX IF NOT EXISTS idx_sessions_expires_at ON sessions(expires_at);

-- 7. SUBSCRIPTIONS TABLE
CREATE TABLE IF NOT EXISTS subscriptions (
    id VARCHAR(64) PRIMARY KEY,
    user_id VARCHAR(64) NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
    plan_tier VARCHAR(32) NOT NULL DEFAULT 'free',
    status VARCHAR(32) NOT NULL DEFAULT 'active', -- 'active' | 'trialing' | 'past_due' | 'canceled'
    stripe_customer_id VARCHAR(128),
    stripe_subscription_id VARCHAR(128),
    current_period_start TIMESTAMP WITH TIME ZONE,
    current_period_end TIMESTAMP WITH TIME ZONE,
    cancel_at_period_end BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_subscriptions_user_id ON subscriptions(user_id);
CREATE INDEX IF NOT EXISTS idx_subscriptions_stripe ON subscriptions(stripe_subscription_id);

-- 8. PAYMENTS TABLE
CREATE TABLE IF NOT EXISTS payments (
    id VARCHAR(64) PRIMARY KEY,
    user_id VARCHAR(64) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    amount_cents INT NOT NULL,
    currency VARCHAR(16) NOT NULL DEFAULT 'usd',
    status VARCHAR(32) NOT NULL DEFAULT 'succeeded', -- 'succeeded' | 'pending' | 'failed'
    provider VARCHAR(32) NOT NULL DEFAULT 'stripe', -- 'stripe' | 'paddle' | 'paypal'
    provider_payment_id VARCHAR(128),
    receipt_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_payments_user_id ON payments(user_id);
CREATE INDEX IF NOT EXISTS idx_payments_created_at ON payments(created_at DESC);

-- 9. ANALYTICS TABLE
CREATE TABLE IF NOT EXISTS analytics (
    id VARCHAR(64) PRIMARY KEY,
    project_id VARCHAR(64) NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    deployment_id VARCHAR(64) REFERENCES deployments(id) ON DELETE SET NULL,
    path VARCHAR(512) NOT NULL DEFAULT '/',
    referrer TEXT,
    ip_hash VARCHAR(64) NOT NULL, -- SHA-256 hashed with salt for privacy compliance
    country_code VARCHAR(8) DEFAULT 'XX',
    country_name VARCHAR(64) DEFAULT 'Unknown',
    device_type VARCHAR(32) DEFAULT 'desktop', -- 'desktop' | 'mobile' | 'tablet' | 'bot'
    browser VARCHAR(64) DEFAULT 'Unknown',
    os VARCHAR(64) DEFAULT 'Unknown',
    bytes_sent BIGINT NOT NULL DEFAULT 0,
    status_code INT NOT NULL DEFAULT 200,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_analytics_project_created ON analytics(project_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_analytics_created ON analytics(created_at DESC);

-- 10. SUPPORT_TICKETS TABLE
CREATE TABLE IF NOT EXISTS support_tickets (
    id VARCHAR(64) PRIMARY KEY,
    user_id VARCHAR(64) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    user_email VARCHAR(255) NOT NULL,
    user_name VARCHAR(255) NOT NULL,
    subject VARCHAR(255) NOT NULL,
    category VARCHAR(64) NOT NULL DEFAULT 'technical', -- 'technical' | 'billing' | 'domain' | 'abuse' | 'general'
    priority VARCHAR(32) NOT NULL DEFAULT 'medium', -- 'low' | 'medium' | 'high' | 'urgent'
    status VARCHAR(32) NOT NULL DEFAULT 'open', -- 'open' | 'in_progress' | 'resolved' | 'closed'
    messages JSONB NOT NULL DEFAULT '[]',
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_tickets_user_id ON support_tickets(user_id);
CREATE INDEX IF NOT EXISTS idx_tickets_status ON support_tickets(status);

-- 11. ADMIN_SETTINGS TABLE
CREATE TABLE IF NOT EXISTS admin_settings (
    key VARCHAR(128) PRIMARY KEY,
    value JSONB NOT NULL,
    updated_by VARCHAR(64),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 12. ACTIVITY_LOGS TABLE
CREATE TABLE IF NOT EXISTS activity_logs (
    id VARCHAR(64) PRIMARY KEY,
    actor_id VARCHAR(64),
    actor_email VARCHAR(255),
    actor_role VARCHAR(32),
    action VARCHAR(128) NOT NULL, -- e.g. 'user.login', 'deployment.create', 'domain.verify'
    resource_type VARCHAR(64) NOT NULL, -- 'project' | 'deployment' | 'user' | 'domain' | 'system'
    resource_id VARCHAR(64),
    details JSONB,
    ip_address VARCHAR(64),
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_activity_logs_created ON activity_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_activity_logs_actor ON activity_logs(actor_id);

-- 13. NOTIFICATIONS TABLE
CREATE TABLE IF NOT EXISTS notifications (
    id VARCHAR(64) PRIMARY KEY,
    user_id VARCHAR(64) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    type VARCHAR(32) NOT NULL DEFAULT 'info', -- 'info' | 'success' | 'warning' | 'error'
    is_read BOOLEAN NOT NULL DEFAULT FALSE,
    link TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_notifications_user_unread ON notifications(user_id, is_read);
