# StrataFlux Cloud – Global Edge Deployment & Web Hosting Platform

StrataFlux Cloud is a production-grade, multi-tenant global website deployment platform inspired by modern edge infrastructure leaders (such as Vercel and Netlify), engineered with original branding, architecture, and technology.

---

## 1. Project Overview

StrataFlux enables developers, digital agencies, and enterprises to deploy static websites and Single Page Applications (SPAs) globally in seconds.

### Key Capabilities
- **Zero-Config Drag-and-Drop Deployment**: Ingests ZIP archives and directory assets. Automatically detects and unpacks root folders (such as `dist/` or `out/`).
- **Sandbox Security & Anti-Zip-Slip**: Strict server-side static isolation. Path traversal attacks and executable binaries (`.php`, `.exe`, `.sh`, `.py`) are automatically quarantined and rejected.
- **Dedicated Dual Routing Architecture**:
  - Direct path preview: `/sites/:subdomain/*`
  - Anycast wildcard subdomains: `https://<subdomain>.strataflux.app`
  - Host-header routing for connected custom domains.
- **Custom Domains with Automated SSL**: CNAME, TXT token verification, and Let's Encrypt / Cloudflare Edge TLS 1.3 automation.
- **Immutable Releases & Rollbacks**: Every build produces an immutable snapshot with logs, file counts, and instantaneous one-click rollback.
- **Privacy-Preserving Edge Analytics**: Server-side telemetry with daily salted SHA-256 IP hashing (GDPR/CCPA compliant, zero third-party cookies).
- **Separate Administrator Control Center**: Dedicated management portal at `/admin-login.html` and `/admin` with complete oversight of users, deployments, domains, plans, storage quotas, support tickets, and system health.
- **Monetization Engine**: Free, Pro, and Business tiers with configurable project, bandwidth, and storage limits, ready for Stripe Hosted Checkout.

---

## 2. Platform Architecture

```
                  +----------------------------------------------+
                  |              Client Browsers / DNS           |
                  +----------------------------------------------+
                                         |
                                         v
                  +----------------------------------------------+
                  |         StrataFlux Global Anycast Edge       |
                  |     (TLS Termination & Host Header Router)   |
                  +----------------------------------------------+
                                         |
            +----------------------------+----------------------------+
            |                                                         |
            v                                                         v
+------------------------+                                +------------------------+
|   Vite SPA Frontend    |                                |  Express Full-Stack    |
| (Marketing, Dashboard, |                                |  REST API Engine       |
|    Admin Console)      |                                |  (Auth, DNS, Build)    |
+------------------------+                                +------------------------+
            |                                                         |
            +----------------------------+----------------------------+
                                         |
                         +---------------+---------------+
                         |                               |
                         v                               v
             +-----------------------+       +-----------------------+
             | Relational Database   |       | Object Storage Engine |
             | (PostgreSQL / Pool +  |       | (Isolated sandboxes / |
             | Dual Engine Fallback) |       |   Cloudflare R2/S3)   |
             +-----------------------+       +-----------------------+
```

---

## 3. Folder Structure

```
├── .env.example                     # Production environment variable template
├── admin-login.html                 # Dedicated admin entrypoint
├── index.html                       # HTML5 entrypoint with SEO & Schema.org JSON-LD
├── metadata.json                    # AI Studio platform configuration
├── package.json                     # Node.js dependencies and scripts
├── server.ts                        # Production Express server & edge router
├── storage/                         # Local isolated deployments sandbox
│   ├── deployments/                 # Per-deployment extracted static files
│   └── tmp_uploads/                 # Multer temporary buffer
├── migrations/
│   └── 001_initial_schema.sql       # PostgreSQL DDL migrations & indexes
├── src/
│   ├── main.tsx                     # React client bootstrap
│   ├── App.tsx                      # Master SPA router & view orchestrator
│   ├── index.css                    # Tailwind CSS v4 directives
│   ├── types/                       # Shared TypeScript interfaces
│   ├── context/
│   │   └── AuthContext.tsx          # JWT authentication and user session state
│   ├── components/
│   │   ├── Logo.tsx                 # StrataFlux brand SVG identity
│   │   ├── Navbar.tsx               # Responsive header navigation
│   │   ├── Footer.tsx               # Official footer with contact & WhatsApp
│   │   └── NewProjectModal.tsx      # Project initialization wizard
│   ├── pages/                       # Public Marketing & Legal Pages
│   │   ├── Home.tsx                 # Hero, interactive deployment simulator
│   │   ├── Features.tsx             # Architectural feature breakdown
│   │   ├── Pricing.tsx              # Starter, Pro, Business tiers comparison
│   │   ├── HowItWorks.tsx           # 4-stage pipeline visualization
│   │   ├── Documentation.tsx        # Framework guides, REST API, CLI
│   │   ├── AboutUs.tsx              # Genuine company mission & contact
│   │   ├── ContactUs.tsx            # WhatsApp & interactive contact dispatch
│   │   ├── Security.tsx             # Defense-in-depth security model
│   │   ├── Status.tsx               # Live subsystem telemetry
│   │   ├── FAQ.tsx                  # Developer and business FAQs
│   │   ├── PrivacyPolicy.tsx        # GDPR/CCPA privacy statement
│   │   ├── TermsOfService.tsx       # Platform terms of service
│   │   ├── CookiePolicy.tsx         # Zero tracking cookie declaration
│   │   ├── AcceptableUse.tsx        # Strict anti-malware/phishing policy
│   │   ├── Login.tsx                # User authentication
│   │   ├── Register.tsx             # User registration
│   │   ├── ForgotPassword.tsx       # Password recovery trigger
│   │   ├── ResetPassword.tsx        # Token-based password reset
│   │   ├── AdminLogin.tsx           # Dedicated administrative gate
│   │   ├── NotFound.tsx             # 404 page
│   │   ├── dashboard/               # User Dashboard
│   │   │   ├── DashboardLayout.tsx  # Sidebar navigation & metrics
│   │   │   ├── DashboardOverview.tsx# 7-metric cards & quick deploy
│   │   │   ├── ProjectsList.tsx     # Project directory
│   │   │   ├── ProjectDetail.tsx    # Drag-and-drop ZIP deploy & history
│   │   │   ├── DeploymentsList.tsx  # Global deployment audit
│   │   │   ├── DomainsManager.tsx   # Custom domain DNS management
│   │   │   ├── AnalyticsView.tsx    # Visitor & bandwidth telemetry
│   │   │   ├── BillingView.tsx      # Plan upgrades & usage meters
│   │   │   ├── SupportTickets.tsx   # Threaded customer support
│   │   │   └── UserSettings.tsx     # Profile, API tokens, 2FA
│   │   └── admin/                   # Administrator Control System
│   │       └── AdminDashboard.tsx   # 16-section master administration console
│   └── server/                      # Server Modules
│       ├── config.ts                # Environment settings & defaults
│       ├── db.ts                    # PostgreSQL & persistent relational engine
│       ├── auth.ts                  # Bcrypt hashing, JWT tokens, rate limiting
│       ├── storage.ts               # Safe ZIP extraction & path guards
│       ├── dns.ts                   # DNS resolver (CNAME & TXT verification)
│       ├── email.ts                 # Transactional email service
│       └── routes/                  # Express REST API routes
│           ├── authRoutes.ts
│           ├── projectRoutes.ts
│           ├── deployRoutes.ts
│           ├── domainRoutes.ts
│           ├── analyticsRoutes.ts
│           ├── billingRoutes.ts
│           ├── supportRoutes.ts
│           ├── adminRoutes.ts
│           └── publicRoutes.ts
```

---

## 4. Administrator Setup

### Dedicated URL
Access the administrative portal at:
```
/admin-login.html
```

### Initial Administrator Credentials
- **Email**: `muhammadofficial356@gmail.com`
- **Initial Password**: Configured in `.env` via `ADMIN_INITIAL_PASSWORD` (default: `Admin_StrataFlux_2026!`).
- **Security Guarantee**: The password is salted and hashed using bcrypt on first boot. It is never stored or exposed in client JavaScript.

Admin capabilities include full management of:
- Users (Search, ban, delete, role assignment)
- Projects (Inspect storage, remove abusive apps)
- Deployments (Raw log viewer, purge)
- Custom Domains (Force verification, SSL status)
- Monetization (Dynamic pricing editor, tier limits)
- Support Desk (Direct threaded replies)
- Platform Announcements, SEO, and Website Settings

---

## 5. Official Platform Contact

- **WhatsApp Support**: `+923199389323`
- **Official Email**: `muhammadofficial356@gmail.com`
- **SLA**: Under 2-hour response for enterprise tickets.

---

## 6. Multi-Provider Payment Architecture & Setup Guide

StrataFlux Cloud provides a unified payment abstraction supporting multiple global and localized payment methods. Customers choose ONE method during checkout without being forced to use a single provider. All five providers coexist in the platform architecture:

1. **Stripe** (International Cards & Apple Pay)
2. **PayPal** (Global Wallet & Linked Accounts)
3. **Payoneer** (Global Account-to-Account Transfers & Bank Wire)
4. **JazzCash** (Pakistan Mobile Account & *786#)
5. **Easypaisa** (Pakistan Mobile Wallet & *786#)

### Payment Architecture Overview

- **Automated Gateways**: Stripe and PayPal operate in automated checkout mode when merchant credentials are configured.
- **Manual Payment Verification System**: For Payoneer, JazzCash, and Easypaisa (or whenever automated APIs are not yet configured), StrataFlux provides an automated manual payment workflow:
  1. Customer selects a plan and billing interval (monthly or annual).
  2. Customer selects their preferred payment method.
  3. System presents tailored payment instructions and beneficiary account details.
  4. Customer transfers the amount via their bank/app.
  5. Customer submits the transaction/reference ID (TID / TRX ID), amount, optional note, and optional screenshot/receipt.
  6. Payment status is set to **`PENDING`**.
  7. Administrator reviews the submission in the **Admin Control Center > Revenue & Subs** tab.
  8. Admin approves or rejects the payment:
     - **When Approved**: Automatically activates the plan, increases storage/custom domain/bandwidth limits, records an audit log entry, and delivers a success notification to the customer.
     - **When Rejected**: Plan is NOT activated, and the customer is notified with the administrator's rejection reason.

---

### Setup Instructions for All 5 Payment Methods

#### 1. Stripe Setup
Stripe enables instant credit/debit card processing with zero manual overhead.

1. Sign in to your [Stripe Dashboard](https://dashboard.stripe.com/).
2. Retrieve your **Publishable Key** and **Secret Key** from `Developers > API keys`.
3. Set up a Webhook endpoint pointing to `https://your-domain.com/api/billing/webhook/stripe`.
4. Configure in `.env`:
   ```env
   STRIPE_ENABLED=true
   STRIPE_PUBLISHABLE_KEY="pk_live_your_key_here"
   STRIPE_SECRET_KEY="sk_live_your_secret_here"
   STRIPE_WEBHOOK_SECRET="whsec_your_webhook_secret_here"
   ```
5. If Stripe keys are not yet configured, the system cleanly marks Stripe as "Not configured" without breaking the app.

---

#### 2. PayPal Setup
PayPal allows customers worldwide to pay using PayPal balance or linked bank accounts.

1. Sign in to the [PayPal Developer Dashboard](https://developer.paypal.com/).
2. Create an App under `REST API apps`.
3. Retrieve your **Client ID** and **Client Secret**.
4. Configure in `.env`:
   ```env
   PAYPAL_ENABLED=true
   PAYPAL_CLIENT_ID="your_paypal_client_id"
   PAYPAL_CLIENT_SECRET="your_paypal_client_secret"
   PAYPAL_MODE="sandbox" # or "live"
   ```

---

#### 3. Payoneer Setup (Manual Payment Mode)
Payoneer provides global receiving accounts for B2B and freelance clients worldwide.

1. Locate your Payoneer account email and registered business/individual name.
2. Configure in `.env` (or customize live in **Admin Dashboard > Revenue & Subs > Settings**):
   ```env
   PAYONEER_ENABLED=true
   PAYONEER_ACCOUNT_NAME="StrataFlux Global Technologies"
   PAYONEER_ACCOUNT_EMAIL_OR_ID="muhammadofficial356@gmail.com"
   PAYONEER_INSTRUCTIONS="Send payment via Payoneer to muhammadofficial356@gmail.com. Include your account email in payment reference. Then enter reference ID below."
   ```
3. When customers submit their transaction ID and receipt, verify the payment in your Payoneer Activity log, then approve it in the StrataFlux Admin Dashboard.

---

#### 4. JazzCash Setup (Pakistan Payment Mode)
JazzCash enables instant mobile account and wallet payments across Pakistan.

1. Configure your JazzCash receiving mobile account in `.env`:
   ```env
   JAZZCASH_ENABLED=true
   JAZZCASH_ACCOUNT_NAME="Muhammad Official"
   JAZZCASH_ACCOUNT_NUMBER="03199389323"
   JAZZCASH_INSTRUCTIONS="Send via JazzCash App or *786# to Mobile Account 03199389323 (Muhammad Official). Enter TID from 8558 below and attach receipt."
   ```
2. Customer makes payment via JazzCash App or USSD *786# and submits the 10-12 digit Transaction ID (TID) received via SMS from 8558.
3. Administrator verifies the SMS/portal confirmation and clicks **Approve** to activate the subscription immediately.

---

#### 5. Easypaisa Setup (Pakistan Payment Mode)
Easypaisa enables instant mobile wallet payments across Pakistan.

1. Configure your Easypaisa receiving mobile account in `.env`:
   ```env
   EASYPAISA_ENABLED=true
   EASYPAISA_ACCOUNT_NAME="Muhammad Official"
   EASYPAISA_ACCOUNT_NUMBER="03199389323"
   EASYPAISA_INSTRUCTIONS="Send via Easypaisa App or *786# to Mobile Account 03199389323 (Muhammad Official). Enter TRX ID from 3737 below and attach receipt."
   ```
2. Customer transfers the amount via Easypaisa App or *786# and enters the Transaction ID (TRX ID) received via SMS from 3737.
3. Administrator verifies the transaction and approves the plan upgrade.

---

### Admin Payment Provider Controls
Platform administrators can manage payment providers dynamically in **Admin Dashboard > Revenue & Subs > Payment Provider Settings**:
- Toggle any payment provider ON or OFF with a single click.
- Update beneficiary titles, mobile numbers, emails, and customer instructions without redeploying.
- Never exposes secret API keys in frontend responses or logs.

---

## 7. Production Deployment Instructions

### Option A: Cloudflare Workers Deployment (Recommended)

StrataFlux Cloud uses the official `@cloudflare/vite-plugin` and **Wrangler** architecture for global serverless deployment to Cloudflare Workers with Workers Static Assets.

#### 1. Cloudflare Workers Builds (GitHub Git Integration)
When connecting your GitHub repository to Cloudflare:
- **Project Type**: Workers (do **not** choose Pages or Static Upload)
- **Framework Preset**: None (or Custom)
- **Build Command**: `npm run build`
- **Deploy Command**: `npx wrangler deploy`
- **Root Directory**: `/` (leave empty / repository root)
- **Output Directory**: Leave default (handled automatically by `@cloudflare/vite-plugin` and `wrangler.jsonc`)

#### 2. CLI Deployment
1. **Build the Application**:
   ```bash
   npm run build
   ```
   This generates both the Cloudflare Worker bundle (`dist/strataflux_cloud`) and the React client assets (`dist/client`).

2. **Preview Locally with Miniflare**:
   ```bash
   npm run preview
   ```

3. **Deploy to Cloudflare**:
   ```bash
   npx wrangler deploy
   ```
   Or use the shortcut:
   ```bash
   npm run deploy
   ```

*Important Notice*: Cloudflare's browser "Upload and deploy" (ZIP drop) only accepts pre-bundled plain static files. Because StrataFlux Cloud is a React + Vite + TypeScript full-stack platform with a Cloudflare Worker backend and dynamic R2 object storage, deployment must proceed via **Cloudflare Workers Builds (GitHub)** or **Wrangler CLI (`npx wrangler deploy`)**.

---

### Option B: Node.js / Docker Container Server

1. **Install Dependencies**:
   ```bash
   npm install
   ```

2. **Configure Environment Variables**:
   ```bash
   cp .env.example .env
   ```

3. **Build the Frontend**:
   ```bash
   npm run build
   ```

4. **Start the Production Server**:
   ```bash
   npm start
   ```
The server will run on port `3000` (or `PORT` specified in `.env`) serving API routes, edge websites, and frontend assets.
